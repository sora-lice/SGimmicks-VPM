using System;
using System.Collections.Generic;
using System.IO;
using CastTimerGimmick;
using TMPro;
using UdonSharp;
using UdonSharpEditor;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.PackageManager;
using UnityEngine;
using UnityEngine.UI;
using VRC.SDK3.Components;
using VRC.SDKBase;
using VRC.Udon;

namespace SGimmicks.Editor
{
    public static class SGEditorFactory
    {
        private const string VpmPackageRoot = "Packages/com.ysasa.sgimmicks";
        public static readonly bool IsVpmPackage =
            AssetDatabase.IsValidFolder(VpmPackageRoot + "/SGimmicks");
        public static readonly string RootFolder = IsVpmPackage
            ? VpmPackageRoot + "/SGimmicks"
            : "Assets/SGimmicks";
        public static readonly string CastTimerRootFolder = IsVpmPackage
            ? VpmPackageRoot + "/CastTimerGimmick"
            : "Assets/CastTimerGimmick";
        public static readonly string GeneratedFolder = IsVpmPackage
            ? "Assets/SGimmicksGenerated"
            : RootFolder + "/Generated";
        public static readonly string PrefabFolder = RootFolder + "/Prefabs";
        public static readonly string SceneFolder = RootFolder + "/Scenes";
        public static readonly string CastTimerPrefabPath =
            CastTimerRootFolder + "/Prefabs/CastTimerGimmick.prefab";

        private static readonly Color PanelColor = new Color(0.035f, 0.055f, 0.08f, 0.96f);
        private static readonly Color ButtonColor = new Color(0.10f, 0.28f, 0.40f, 1f);
        private static readonly Color AccentColor = new Color(0.2f, 0.9f, 0.75f, 1f);
        private static readonly Color TextColor = new Color(0.93f, 0.97f, 1f, 1f);

        public static CastTimerManager CreateCastTimerGimmick()
        {
            GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(CastTimerPrefabPath);
            if (prefab == null)
                throw new InvalidOperationException(
                    "キャストタイマーPrefabが見つかりません: " + CastTimerPrefabPath);

            GameObject instance = PrefabUtility.InstantiatePrefab(prefab) as GameObject;
            if (instance == null)
                throw new InvalidOperationException("キャストタイマーPrefabを配置できませんでした。");
            Undo.RegisterCreatedObjectUndo(instance, "Create Cast Timer Gimmick");
            instance.name = "CastTimerGimmick";
            CastTimerManager manager = instance.GetComponent<CastTimerManager>();
            if (manager == null)
            {
                Undo.DestroyObjectImmediate(instance);
                throw new InvalidOperationException(
                    "キャストタイマーPrefabにCastTimerManagerがありません。");
            }

            Selection.activeGameObject = instance;
            EditorSceneManager.MarkSceneDirty(instance.scene);
            return manager;
        }

        public static SGTeleportInteract ConfigureTeleport(GameObject useObject, Transform destination,
            string interactionText, float proximity)
        {
            if (useObject == null) throw new ArgumentNullException(nameof(useObject));
            if (destination == null) throw new ArgumentNullException(nameof(destination));

            SGTeleportInteract component = useObject.GetComponent<SGTeleportInteract>();
            if (component == null)
            {
                component = AddUdonComponent<SGTeleportInteract>(useObject);
            }

            component.destination = destination;
            component.interactionPrompt = string.IsNullOrWhiteSpace(interactionText) ? "テレポート" : interactionText;

            if (useObject.GetComponent<Collider>() == null)
            {
                Undo.AddComponent<BoxCollider>(useObject);
            }

            UdonBehaviour backing = UdonSharpEditorUtility.GetBackingUdonBehaviour(component);
            if (backing != null)
            {
                backing.InteractionText = component.interactionPrompt;
                SerializedObject backingObject = new SerializedObject(backing);
                SerializedProperty proximityProperty = backingObject.FindProperty("proximity");
                if (proximityProperty != null)
                {
                    proximityProperty.floatValue = Mathf.Max(0f, proximity);
                    backingObject.ApplyModifiedPropertiesWithoutUndo();
                }
                EditorUtility.SetDirty(backing);
            }

            EditorUtility.SetDirty(component);
            Selection.activeGameObject = useObject;
            return component;
        }

        public static SGVipSpawnController ConfigureVipSpawn(SGVipSpawnController existingController,
            Transform vipSpawnPoint, IList<string> displayNames, bool useOnRespawn)
        {
            if (vipSpawnPoint == null) throw new ArgumentNullException(nameof(vipSpawnPoint));

            SGVipSpawnController controller = existingController;
            if (controller == null)
            {
                GameObject root = new GameObject("SGimmicks_VIPSpawn");
                Undo.RegisterCreatedObjectUndo(root, "Create VIP Spawn");
                controller = AddUdonComponent<SGVipSpawnController>(root);
            }

            List<string> cleanNames = new List<string>();
            if (displayNames != null)
            {
                foreach (string value in displayNames)
                {
                    string clean = value == null ? string.Empty : value.Trim();
                    if (!string.IsNullOrEmpty(clean) && !cleanNames.Contains(clean)) cleanNames.Add(clean);
                }
            }

            controller.vipSpawnPoint = vipSpawnPoint;
            controller.vipDisplayNames = cleanNames.ToArray();
            controller.useVipPointOnRespawn = useOnRespawn;
            EditorUtility.SetDirty(controller);
            Selection.activeGameObject = controller.gameObject;
            return controller;
        }

        public static bool IsRTabInstalled()
        {
            return FindType("Rasta.Tablet.TabletAppBehaviour", "TabletAppBehaviour") != null;
        }

        public static Transform FindRTabAppsRoot()
        {
            Transform[] transforms = Resources.FindObjectsOfTypeAll<Transform>();
            foreach (Transform candidate in transforms)
            {
                if (candidate == null || candidate.name != "Apps" || !candidate.gameObject.scene.IsValid()) continue;
                Transform parent = candidate.parent;
                while (parent != null)
                {
                    if (parent.name == "RTab") return candidate;
                    parent = parent.parent;
                }
            }
            return null;
        }

        public static SGRoomTeleportController ConfigureRoomTeleportRTab(Transform appsRoot,
            SGRoomTeleportController existingController, IList<string> roomCodes,
            IList<Transform> roomDestinations)
        {
            GameObject toggleObject = existingController == null
                ? null
                : existingController.globalToggleObject;
            string showCode = existingController == null
                ? string.Empty
                : existingController.globalShowCode;
            string hideCode = existingController == null
                ? string.Empty
                : existingController.globalHideCode;
            bool initiallyVisible = toggleObject != null && toggleObject.activeSelf;
            return ConfigureRoomTeleportRTab(appsRoot, existingController, roomCodes,
                roomDestinations, toggleObject, showCode, hideCode, initiallyVisible);
        }

        public static SGRoomTeleportController ConfigureRoomTeleportRTab(Transform appsRoot,
            SGRoomTeleportController existingController, IList<string> roomCodes,
            IList<Transform> roomDestinations, GameObject globalToggleObject,
            string globalShowCode, string globalHideCode, bool globalObjectInitiallyVisible)
        {
            Type rtabBehaviourType = FindType("Rasta.Tablet.TabletAppBehaviour", "TabletAppBehaviour");
            if (rtabBehaviourType == null)
                throw new InvalidOperationException(
                    "RTabのTabletAppBehaviourが見つかりません。RTabを先にインポートしてください。");

            if (appsRoot == null) appsRoot = FindRTabAppsRoot();
            if (appsRoot == null)
                throw new InvalidOperationException(
                    "RTab/Appsが見つかりません。HierarchyからAppsを指定してください。");

            ValidateRoomTeleportRoutes(roomCodes, roomDestinations,
                out string[] validatedCodes, out Transform[] validatedDestinations);
            ValidateGlobalToggleSettings(globalToggleObject, globalShowCode, globalHideCode,
                validatedCodes, out string validatedShowCode, out string validatedHideCode);

            if (globalToggleObject != null &&
                (globalToggleObject.transform == appsRoot ||
                 appsRoot.IsChildOf(globalToggleObject.transform)))
            {
                throw new ArgumentException(
                    "RTab本体やその親は表示切替対象にできません。別のパネル／オブジェクトを指定してください。");
            }

            GameObject appObject;
            SGRoomTeleportController controller = existingController;
            if (controller == null)
            {
                appObject = new GameObject("SGRoomTeleportApp", typeof(RectTransform), typeof(Image),
                    typeof(CanvasGroup));
                Undo.RegisterCreatedObjectUndo(appObject, "Create SG Room Teleport RTab App");
                Undo.SetTransformParent(appObject.transform, appsRoot, "Parent SG Room Teleport RTab App");
                controller = AddUdonComponent<SGRoomTeleportController>(appObject);
            }
            else
            {
                appObject = controller.gameObject;
                if (appObject.GetComponent<RectTransform>() == null)
                    throw new InvalidOperationException("既存の部屋番号アプリにはRectTransformが必要です。");
                if (appObject.transform.parent != appsRoot)
                    Undo.SetTransformParent(appObject.transform, appsRoot, "Reparent SG Room Teleport RTab App");
                if (appObject.GetComponent<Image>() == null) Undo.AddComponent<Image>(appObject);
                if (appObject.GetComponent<CanvasGroup>() == null) Undo.AddComponent<CanvasGroup>(appObject);
            }

            ConfigureRTabAppRoot(appObject);
            Component rtabComponent = appObject.GetComponent(rtabBehaviourType);
            if (rtabComponent == null)
            {
                if (typeof(UdonSharpBehaviour).IsAssignableFrom(rtabBehaviourType))
                    rtabComponent = appObject.AddUdonSharpComponent(rtabBehaviourType);
                else if (typeof(Component).IsAssignableFrom(rtabBehaviourType))
                    rtabComponent = Undo.AddComponent(appObject, rtabBehaviourType);
            }
            if (rtabComponent == null)
                throw new InvalidOperationException("TabletAppBehaviourを追加できませんでした。");

            SetRTabAppSettings(rtabComponent, GetOrCreateRTabIcon(),
                "部屋番号テレポート", "SGimmicks");

            if (globalToggleObject == appObject)
                throw new ArgumentException("部屋番号アプリ自身は表示切替対象にできません。");

            controller.roomCodes = validatedCodes;
            controller.roomDestinations = validatedDestinations;
            controller.sharedTabletPickup = appsRoot.GetComponentInParent<VRC_Pickup>();
            controller.globalToggleObject = globalToggleObject;
            controller.globalShowCode = validatedShowCode;
            controller.globalHideCode = validatedHideCode;
            UdonBehaviour controllerBacking =
                UdonSharpEditorUtility.GetBackingUdonBehaviour(controller);
            if (controllerBacking == null)
                throw new InvalidOperationException(
                    "部屋番号アプリのBacking UdonBehaviourを作成できませんでした。");
            controllerBacking.SyncMethod = Networking.SyncType.Manual;
            EditorUtility.SetDirty(controllerBacking);
            if (globalToggleObject != null)
            {
                Undo.RecordObject(globalToggleObject, "Set Global Toggle Initial State");
                globalToggleObject.SetActive(globalObjectInitiallyVisible);
                EditorUtility.SetDirty(globalToggleObject);
                if (globalToggleObject.scene.IsValid())
                    EditorSceneManager.MarkSceneDirty(globalToggleObject.scene);
            }
            CreateRoomTeleportAppUI(appObject.GetComponent<RectTransform>(), controller);
            // Adding UdonSharp components to a nested prefab can rewrite the UI transform.
            // Normalize it last so RTab receives a full-size app page instead of a collapsed rect.
            ConfigureRTabAppRoot(appObject);
            EditorUtility.SetDirty(controller);
            UdonSharpEditorUtility.CopyProxyToUdon(controller);
            UdonSharpBehaviour rtabUdon = rtabComponent as UdonSharpBehaviour;
            if (rtabUdon != null) UdonSharpEditorUtility.CopyProxyToUdon(rtabUdon);
            if (appObject.scene.IsValid()) EditorSceneManager.MarkSceneDirty(appObject.scene);
            Selection.activeGameObject = appObject;
            return controller;
        }

        public static SGRoomTeleportController CreateRoomTeleportAppTemplate(Transform[] destinations = null)
        {
            GameObject appObject = new GameObject("SGRoomTeleportApp", typeof(RectTransform), typeof(Image),
                typeof(CanvasGroup));
            ConfigureRTabAppRoot(appObject);
            SGRoomTeleportController controller = AddUdonComponent<SGRoomTeleportController>(appObject);
            controller.roomCodes = new[] { "0001" };
            controller.roomDestinations = destinations ?? new Transform[1];
            CreateRoomTeleportAppUI(appObject.GetComponent<RectTransform>(), controller);
            UdonSharpEditorUtility.CopyProxyToUdon(controller);
            return controller;
        }

        private static void ValidateRoomTeleportRoutes(IList<string> roomCodes,
            IList<Transform> roomDestinations, out string[] validatedCodes,
            out Transform[] validatedDestinations)
        {
            if (roomCodes == null || roomDestinations == null || roomCodes.Count == 0 ||
                roomCodes.Count != roomDestinations.Count)
                throw new ArgumentException("部屋番号とテレポート先を同じ数だけ設定してください。");

            List<string> codes = new List<string>();
            List<Transform> destinations = new List<Transform>();
            for (int i = 0; i < roomCodes.Count; i++)
            {
                string code = roomCodes[i] == null ? "" : roomCodes[i].Trim();
                if (!IsFourDigitCode(code))
                    throw new ArgumentException("部屋番号 " + (i + 1) + " は半角数字4桁で入力してください。");
                if (codes.Contains(code))
                    throw new ArgumentException("部屋番号 " + code + " が重複しています。");
                if (roomDestinations[i] == null)
                    throw new ArgumentException("部屋番号 " + code + " のテレポート先が未設定です。");
                codes.Add(code);
                destinations.Add(roomDestinations[i]);
            }
            validatedCodes = codes.ToArray();
            validatedDestinations = destinations.ToArray();
        }

        private static void ValidateGlobalToggleSettings(GameObject target, string showCode,
            string hideCode, IList<string> roomCodes, out string validatedShowCode,
            out string validatedHideCode)
        {
            validatedShowCode = showCode == null ? string.Empty : showCode.Trim();
            validatedHideCode = hideCode == null ? string.Empty : hideCode.Trim();
            if (target == null) return;

            if (!IsFourDigitCode(validatedShowCode))
                throw new ArgumentException("グローバル表示番号は半角数字4桁で入力してください。");
            if (!IsFourDigitCode(validatedHideCode))
                throw new ArgumentException("グローバル非表示番号は半角数字4桁で入力してください。");
            if (validatedShowCode == validatedHideCode)
                throw new ArgumentException("表示番号と非表示番号には別の4桁を指定してください。");

            for (int i = 0; i < roomCodes.Count; i++)
            {
                if (roomCodes[i] == validatedShowCode || roomCodes[i] == validatedHideCode)
                    throw new ArgumentException(
                        "グローバル表示切替番号は、テレポート用の部屋番号と重複できません。");
            }
        }

        private static bool IsFourDigitCode(string code)
        {
            if (code == null || code.Length != 4) return false;
            for (int i = 0; i < code.Length; i++)
            {
                if (code[i] < '0' || code[i] > '9') return false;
            }
            return true;
        }

        private static void ConfigureRTabAppRoot(GameObject appObject)
        {
            RectTransform rect = appObject.GetComponent<RectTransform>();
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = Vector2.zero;
            rect.sizeDelta = Vector2.zero;
            rect.localPosition = Vector3.zero;
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
            rect.localScale = Vector3.one;
            rect.localRotation = Quaternion.identity;

            Image image = appObject.GetComponent<Image>();
            image.color = new Color(0.025f, 0.045f, 0.07f, 1f);
            CanvasGroup canvasGroup = appObject.GetComponent<CanvasGroup>();
            canvasGroup.alpha = 1f;
            canvasGroup.interactable = true;
            canvasGroup.blocksRaycasts = true;
            canvasGroup.ignoreParentGroups = false;
        }

        private static void CreateRoomTeleportAppUI(RectTransform parent,
            SGRoomTeleportController controller)
        {
            Transform previous = parent.Find("RoomTeleportUI");
            if (previous != null) Undo.DestroyObjectImmediate(previous.gameObject);

            GameObject uiObject = new GameObject("RoomTeleportUI", typeof(RectTransform));
            uiObject.transform.SetParent(parent, false);
            RectTransform ui = uiObject.GetComponent<RectTransform>();
            ui.anchorMin = Vector2.zero;
            ui.anchorMax = Vector2.one;
            ui.offsetMin = Vector2.zero;
            ui.offsetMax = Vector2.zero;

            CreateTabletText(ui, "Title", "ROOM ACCESS", new Vector2(0.08f, 0.88f),
                new Vector2(0.92f, 0.98f), 52, AccentColor);
            CreateTabletButton(ui, "SwitchUser", "利用開始／ユーザー切替",
                new Vector2(0.12f, 0.78f), new Vector2(0.88f, 0.87f), controller,
                "BeginOrSwitchUser", new Color(0.10f, 0.38f, 0.46f, 1f), 38);
            controller.inputDisplayText = CreateTabletText(ui, "InputDisplay", "－－－－",
                new Vector2(0.16f, 0.66f), new Vector2(0.84f, 0.76f), 64, TextColor);
            controller.statusText = CreateTabletText(ui, "Status", "利用開始を押してください",
                new Vector2(0.08f, 0.58f), new Vector2(0.92f, 0.65f), 32, AccentColor);

            string[] labels = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "C", "0", "E" };
            string[] events =
            {
                "Press1", "Press2", "Press3", "Press4", "Press5", "Press6",
                "Press7", "Press8", "Press9", "ClearInput", "Press0", "EnterCode"
            };
            for (int i = 0; i < labels.Length; i++)
            {
                int row = i / 3;
                int column = i % 3;
                float left = 0.12f + column * 0.27f;
                float right = left + 0.22f;
                float top = 0.55f - row * 0.13f;
                float bottom = top - 0.105f;
                Color color = ButtonColor;
                if (labels[i] == "C") color = new Color(0.60f, 0.16f, 0.18f, 1f);
                if (labels[i] == "E") color = new Color(0.08f, 0.52f, 0.32f, 1f);
                CreateTabletButton(ui, "Key_" + labels[i], labels[i],
                    new Vector2(left, bottom), new Vector2(right, top), controller,
                    events[i], color, 48);
            }
        }

        private static Text CreateTabletText(RectTransform parent, string name, string value,
            Vector2 anchorMin, Vector2 anchorMax, int fontSize, Color color)
        {
            GameObject textObject = new GameObject(name, typeof(RectTransform), typeof(Text), typeof(Outline));
            textObject.transform.SetParent(parent, false);
            RectTransform rect = textObject.GetComponent<RectTransform>();
            rect.anchorMin = anchorMin;
            rect.anchorMax = anchorMax;
            rect.offsetMin = new Vector2(4f, 4f);
            rect.offsetMax = new Vector2(-4f, -4f);
            Text text = textObject.GetComponent<Text>();
            Font japaneseFont = AssetDatabase.LoadAssetAtPath<Font>(
                RootFolder + "/Fonts/NotoSansJP-Regular.ttf");
            text.font = japaneseFont != null
                ? japaneseFont
                : Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            text.text = value;
            text.fontSize = fontSize;
            text.fontStyle = FontStyle.Bold;
            text.resizeTextForBestFit = true;
            text.resizeTextMinSize = Mathf.Min(22, fontSize);
            text.resizeTextMaxSize = fontSize;
            text.alignment = TextAnchor.MiddleCenter;
            text.color = color;
            text.raycastTarget = false;
            Outline outline = textObject.GetComponent<Outline>();
            outline.effectColor = new Color(0f, 0f, 0f, 0.85f);
            outline.effectDistance = new Vector2(1.2f, -1.2f);
            return text;
        }

        private static Button CreateTabletButton(RectTransform parent, string name, string label,
            Vector2 anchorMin, Vector2 anchorMax, UdonSharpBehaviour receiver, string eventName,
            Color color, int fontSize)
        {
            GameObject buttonObject = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Button));
            buttonObject.transform.SetParent(parent, false);
            RectTransform rect = buttonObject.GetComponent<RectTransform>();
            rect.anchorMin = anchorMin;
            rect.anchorMax = anchorMax;
            rect.offsetMin = new Vector2(4f, 4f);
            rect.offsetMax = new Vector2(-4f, -4f);
            Image image = buttonObject.GetComponent<Image>();
            image.color = color;
            Button button = buttonObject.GetComponent<Button>();
            ColorBlock colors = button.colors;
            colors.normalColor = color;
            colors.highlightedColor = Color.Lerp(color, Color.white, 0.18f);
            colors.pressedColor = AccentColor;
            button.colors = colors;
            CreateTabletText(rect, "Label", label, Vector2.zero, Vector2.one, fontSize, TextColor);
            WireUdonEvent(button, receiver, eventName);
            return button;
        }

        private static Type FindType(string fullName, string fallbackName)
        {
            foreach (System.Reflection.Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                Type type = assembly.GetType(fullName, false);
                if (type != null) return type;
            }
            foreach (System.Reflection.Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                Type[] types;
                try { types = assembly.GetTypes(); }
                catch (System.Reflection.ReflectionTypeLoadException exception) { types = exception.Types; }
                if (types == null) continue;
                foreach (Type type in types)
                {
                    if (type != null && type.Name == fallbackName) return type;
                }
            }
            return null;
        }

        private static void SetRTabAppSettings(Component component, Texture2D icon,
            string appName, string credit)
        {
            SerializedObject serialized = new SerializedObject(component);
            SerializedProperty iterator = serialized.GetIterator();
            while (iterator.NextVisible(true))
            {
                string key = (iterator.name + iterator.displayName).Replace(" ", "").ToLowerInvariant();
                if (key.Contains("appicon") && iterator.propertyType == SerializedPropertyType.ObjectReference)
                    iterator.objectReferenceValue = icon;
                else if (key.Contains("appname") && iterator.propertyType == SerializedPropertyType.String)
                    iterator.stringValue = appName;
                else if (key.Contains("credit") && iterator.propertyType == SerializedPropertyType.String)
                    iterator.stringValue = credit;
            }
            serialized.ApplyModifiedPropertiesWithoutUndo();
            EditorUtility.SetDirty(component);
        }

        private static Texture2D GetOrCreateRTabIcon()
        {
            EnsureAssetFolders();
            string iconPath = GeneratedFolder + "/SGRoomTeleportIcon.asset";
            Texture2D icon = AssetDatabase.LoadAssetAtPath<Texture2D>(iconPath);
            if (icon != null) return icon;
            icon = new Texture2D(64, 64, TextureFormat.RGBA32, false)
            {
                name = "SGRoomTeleportIcon",
                filterMode = FilterMode.Bilinear,
                wrapMode = TextureWrapMode.Clamp
            };
            Color32 dark = new Color32(7, 17, 27, 255);
            Color32 cyan = new Color32(51, 230, 191, 255);
            Color32[] pixels = new Color32[64 * 64];
            for (int i = 0; i < pixels.Length; i++) pixels[i] = dark;
            for (int y = 8; y < 56; y++)
            {
                for (int x = 8; x < 56; x++)
                {
                    bool border = x < 11 || x > 52 || y < 11 || y > 52;
                    bool key = x >= 17 && x <= 26 && ((y >= 18 && y <= 27) || (y >= 36 && y <= 45)) ||
                               x >= 37 && x <= 46 && ((y >= 18 && y <= 27) || (y >= 36 && y <= 45));
                    if (border || key) pixels[y * 64 + x] = cyan;
                }
            }
            icon.SetPixels32(pixels);
            icon.Apply(false, false);
            AssetDatabase.CreateAsset(icon, iconPath);
            AssetDatabase.SaveAssets();
            return icon;
        }

        public static SGSurveillanceController CreateDefaultSurveillanceSystem(bool registerUndo = true,
            int panelFontSize = 40)
        {
            EnsureAssetFolders();
            GameObject root = new GameObject("SGimmicks_SurveillanceSystem");
            if (registerUndo) Undo.RegisterCreatedObjectUndo(root, "Create Surveillance System");

            Vector3[] positions =
            {
                new Vector3(-3f, 2.6f, 3f), new Vector3(3f, 2.6f, 3f),
                new Vector3(-3f, 2.6f, -3f), new Vector3(3f, 2.6f, -3f)
            };
            Vector3[] rotations =
            {
                new Vector3(12f, 35f, 0f), new Vector3(12f, 145f, 0f),
                new Vector3(12f, -35f, 0f), new Vector3(12f, -145f, 0f)
            };
            Camera[] cameras = new Camera[4];
            string[] labels = new string[4];
            for (int i = 0; i < cameras.Length; i++)
            {
                GameObject cameraObject = new GameObject("SurveillanceCamera_" + (i + 1).ToString("00"));
                cameraObject.transform.SetParent(root.transform, false);
                cameraObject.transform.localPosition = positions[i];
                cameraObject.transform.localRotation = Quaternion.Euler(rotations[i]);
                Camera cameraComponent = cameraObject.AddComponent<Camera>();
                cameraComponent.fieldOfView = 60f;
                cameraComponent.nearClipPlane = 0.05f;
                cameraComponent.enabled = false;
                cameras[i] = cameraComponent;
                labels[i] = "カメラ " + (i + 1).ToString("00");
            }

            SGSurveillanceController controller = ConfigureSurveillance(root, null,
                cameras, labels, null, panelFontSize);
            Selection.activeGameObject = root;
            return controller;
        }

        public static SGSurveillanceController ConfigureSurveillance(GameObject controllerRoot,
            Renderer monitorRenderer, Camera[] cameras, string[] cameraLabels, RenderTexture renderTexture = null,
            int panelFontSize = 40)
        {
            if (cameras == null || cameras.Length == 0) throw new ArgumentException("At least one camera is required.");
            for (int i = 0; i < cameras.Length; i++)
            {
                if (cameras[i] == null) throw new ArgumentException("Camera " + (i + 1) + " is not assigned.");
            }

            EnsureAssetFolders();
            if (controllerRoot == null)
            {
                controllerRoot = new GameObject("SGimmicks_SurveillanceSystem");
                Undo.RegisterCreatedObjectUndo(controllerRoot, "Create Surveillance System");
                if (monitorRenderer != null) controllerRoot.transform.position = monitorRenderer.transform.position;
            }

            SGSurveillanceController controller = controllerRoot.GetComponent<SGSurveillanceController>();
            if (controller == null) controller = AddUdonComponent<SGSurveillanceController>(controllerRoot);
            controller.surveillanceCameras = cameras;
            controller.cameraLabels = BuildCameraLabels(cameras, cameraLabels);
            controller.operationPanelFontSize = Mathf.Clamp(panelFontSize, 28, 52);
            BuildMonitorWall(controller, monitorRenderer, cameras, controller.cameraLabels, renderTexture);

            Transform previousPanel = controllerRoot.transform.Find("OperationPanel");
            if (previousPanel != null)
            {
                Undo.DestroyObjectImmediate(previousPanel.gameObject);
            }
            CreateOperationPanel(controllerRoot.transform, controller, controller.operationPanelFontSize);
            PositionOperationPanel(controller);

            EditorUtility.SetDirty(controller);
            UdonSharpEditorUtility.CopyProxyToUdon(controller);
            return controller;
        }

        public static void RefreshOperationPanel(SGSurveillanceController controller, int panelFontSize)
        {
            if (controller == null) throw new ArgumentNullException(nameof(controller));
            controller.operationPanelFontSize = Mathf.Clamp(panelFontSize, 28, 52);
            Transform previousPanel = controller.transform.Find("OperationPanel");
            if (previousPanel != null) Undo.DestroyObjectImmediate(previousPanel.gameObject);
            CreateOperationPanel(controller.transform, controller, controller.operationPanelFontSize);
            PositionOperationPanel(controller);
            EditorUtility.SetDirty(controller);
            UdonSharpEditorUtility.CopyProxyToUdon(controller);
            if (controller.gameObject.scene.IsValid())
                EditorSceneManager.MarkSceneDirty(controller.gameObject.scene);
        }

        public static SGForceTeleportController ConfigureForceTeleport(
            SGForceTeleportController existingController, IList<Transform> requestedDestinations,
            IList<string> requestedLabels, int accessMode, IList<string> authorizedDisplayNames,
            float blurDuration)
        {
            if (requestedDestinations == null || requestedDestinations.Count == 0)
                throw new ArgumentException("テレポート先を1個以上設定してください。");

            List<Transform> destinations = new List<Transform>();
            List<string> labels = new List<string>();
            for (int i = 0; i < requestedDestinations.Count; i++)
            {
                Transform destination = requestedDestinations[i];
                if (destination == null)
                    throw new ArgumentException("移動先 " + (i + 1) + " が未設定です。");
                destinations.Add(destination);
                string label = requestedLabels != null && i < requestedLabels.Count
                    ? requestedLabels[i]
                    : string.Empty;
                labels.Add(string.IsNullOrWhiteSpace(label)
                    ? "移動先 " + (i + 1).ToString("00")
                    : label.Trim());
            }

            List<string> cleanAuthorizedNames = new List<string>();
            if (authorizedDisplayNames != null)
            {
                foreach (string value in authorizedDisplayNames)
                {
                    string clean = value == null ? string.Empty : value.Trim();
                    if (!string.IsNullOrEmpty(clean) && !cleanAuthorizedNames.Contains(clean))
                        cleanAuthorizedNames.Add(clean);
                }
            }
            int validatedAccessMode = Mathf.Clamp(accessMode, 0, 2);
            if (validatedAccessMode == 2 && cleanAuthorizedNames.Count == 0)
                throw new ArgumentException("表示名による制限を使う場合は、許可する表示名を1人以上設定してください。");

            EnsureAssetFolders();
            SGForceTeleportController controller = existingController;
            if (controller == null)
            {
                GameObject root = new GameObject("SGimmicks_ForceTeleport");
                Undo.RegisterCreatedObjectUndo(root, "Create Force Teleport");
                controller = AddUdonComponent<SGForceTeleportController>(root);
            }

            controller.destinations = destinations.ToArray();
            controller.destinationLabels = labels.ToArray();
            controller.accessMode = validatedAccessMode;
            controller.authorizedDisplayNames = cleanAuthorizedNames.ToArray();
            controller.blurDuration = Mathf.Clamp(blurDuration, 0.5f, 5f);

            UdonBehaviour backing = UdonSharpEditorUtility.GetBackingUdonBehaviour(controller);
            if (backing == null)
                throw new InvalidOperationException("強制テレポートのBacking UdonBehaviourを作成できませんでした。");
            backing.SyncMethod = Networking.SyncType.Manual;
            EditorUtility.SetDirty(backing);

            Transform previousPanel = controller.transform.Find("ForceTeleportPanel");
            if (previousPanel != null) Undo.DestroyObjectImmediate(previousPanel.gameObject);
            Transform previousOverlay = controller.transform.Find("LocalBlurOverlay");
            if (previousOverlay != null) Undo.DestroyObjectImmediate(previousOverlay.gameObject);
            CreateForceTeleportPanel(controller.transform, controller);
            CreateForceTeleportBlurOverlay(controller.transform, controller);

            EditorUtility.SetDirty(controller);
            UdonSharpEditorUtility.CopyProxyToUdon(controller);
            if (controller.gameObject.scene.IsValid())
                EditorSceneManager.MarkSceneDirty(controller.gameObject.scene);
            Selection.activeGameObject = controller.gameObject;
            return controller;
        }

        private static void CreateForceTeleportPanel(Transform parent,
            SGForceTeleportController controller)
        {
            const int titleSize = 48;
            const int sectionSize = 35;
            const int rowSize = 32;
            const int smallSize = 30;

            GameObject panelObject = new GameObject("ForceTeleportPanel", typeof(RectTransform),
                typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster), typeof(VRCUiShape));
            panelObject.transform.SetParent(parent, false);
            RectTransform panelRect = panelObject.GetComponent<RectTransform>();
            panelRect.sizeDelta = new Vector2(1180f, 1040f);
            panelRect.localScale = Vector3.one * 0.001f;
            panelRect.localPosition = new Vector3(0f, 1.45f, 0f);
            panelRect.localRotation = Quaternion.identity;

            Canvas canvas = panelObject.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.WorldSpace;
            canvas.sortingOrder = 30;
            panelObject.GetComponent<CanvasScaler>().dynamicPixelsPerUnit = 100f;
            panelObject.AddComponent<Image>().color = PanelColor;

            CreateText(panelRect, "Title", "SGimmicks 強制テレポート", new Vector2(0f, -18f),
                new Vector2(1110f, 58f), titleSize, TextAnchor.MiddleCenter, AccentColor);
            CreateText(panelRect, "Help",
                "左で複数人を選択 → ▶ の人の移動先を右で指定 → 同時テレポート",
                new Vector2(0f, -78f), new Vector2(1110f, 48f), smallSize,
                TextAnchor.MiddleCenter, TextColor);

            CreateText(panelRect, "PlayerHeader", "実行対象プレイヤー", new Vector2(-280f, -135f),
                new Vector2(555f, 48f), sectionSize, TextAnchor.MiddleCenter, AccentColor);
            CreateText(panelRect, "DestinationHeader", "移動先", new Vector2(330f, -135f),
                new Vector2(430f, 48f), sectionSize, TextAnchor.MiddleCenter, AccentColor);

            const int rowCount = 8;
            controller.playersPerPage = rowCount;
            controller.destinationsPerPage = rowCount;
            controller.playerRowTexts = new Text[rowCount];
            controller.playerSelectionIndicators = new GameObject[rowCount];
            controller.destinationButtonTexts = new Text[rowCount];
            controller.destinationSelectionIndicators = new GameObject[rowCount];
            for (int i = 0; i < rowCount; i++)
            {
                float y = -190f - i * 64f;
                Button playerButton = CreateButton(panelRect, "PlayerSlot_" + i, "---",
                    new Vector2(-280f, y), new Vector2(555f, 52f), controller,
                    "TogglePlayerSlot" + i, rowSize);
                controller.playerRowTexts[i] = playerButton.GetComponentInChildren<Text>();
                controller.playerSelectionIndicators[i] =
                    CreateSelectionIndicator(playerButton.transform, "Selected", 12f, true);

                Button destinationButton = CreateButton(panelRect, "DestinationSlot_" + i,
                    "移動先 " + (i + 1).ToString("00"), new Vector2(330f, y),
                    new Vector2(430f, 52f), controller, "AssignDestinationSlot" + i, rowSize);
                controller.destinationButtonTexts[i] = destinationButton.GetComponentInChildren<Text>();
                controller.destinationSelectionIndicators[i] =
                    CreateSelectionIndicator(destinationButton.transform, "Assigned", 350f);
            }

            controller.playerPageText = CreateText(panelRect, "PlayerPage", "1 / 1",
                new Vector2(-280f, -716f), new Vector2(120f, 42f), smallSize,
                TextAnchor.MiddleCenter, TextColor);
            CreateButton(panelRect, "PreviousPlayerPage", "＜ 前", new Vector2(-485f, -716f),
                new Vector2(170f, 44f), controller, "PreviousPlayerPage", smallSize);
            CreateButton(panelRect, "NextPlayerPage", "次 ＞", new Vector2(-75f, -716f),
                new Vector2(170f, 44f), controller, "NextPlayerPage", smallSize);

            controller.destinationPageText = CreateText(panelRect, "DestinationPage", "1 / 1",
                new Vector2(330f, -716f), new Vector2(120f, 42f), smallSize,
                TextAnchor.MiddleCenter, TextColor);
            CreateButton(panelRect, "PreviousDestinationPage", "＜ 前", new Vector2(180f, -716f),
                new Vector2(130f, 44f), controller, "PreviousDestinationPage", smallSize);
            CreateButton(panelRect, "NextDestinationPage", "次 ＞", new Vector2(480f, -716f),
                new Vector2(130f, 44f), controller, "NextDestinationPage", smallSize);

            controller.focusedPlayerText = CreateText(panelRect, "FocusedPlayer",
                "左側でプレイヤーを選択してください", new Vector2(0f, -770f),
                new Vector2(1090f, 44f), sectionSize, TextAnchor.MiddleCenter, AccentColor);
            controller.selectionSummaryText = CreateText(panelRect, "SelectionSummary",
                "実行対象 0人 ／ 移動先設定済 0人", new Vector2(0f, -816f),
                new Vector2(1090f, 42f), smallSize, TextAnchor.MiddleCenter, TextColor);

            CreateButton(panelRect, "RefreshPlayers", "一覧更新", new Vector2(-450f, -866f),
                new Vector2(220f, 52f), controller, "RefreshPlayers", sectionSize);
            CreateButton(panelRect, "ClearSelection", "選択解除", new Vector2(-210f, -866f),
                new Vector2(220f, 52f), controller, "ClearSelection", sectionSize);
            Button blurButton = CreateButton(panelRect, "ToggleBlur", "ぼかし演出：ON",
                new Vector2(70f, -866f), new Vector2(280f, 52f), controller,
                "ToggleBlurOption", sectionSize);
            controller.blurOptionText = blurButton.GetComponentInChildren<Text>();
            CreateButton(panelRect, "ExecuteTeleport", "同時テレポート",
                new Vector2(390f, -866f), new Vector2(330f, 52f), controller,
                "ExecuteTeleport", sectionSize);

            controller.statusText = CreateText(panelRect, "Status",
                "プレイヤーを選択してください", new Vector2(0f, -934f),
                new Vector2(1100f, 58f), smallSize, TextAnchor.MiddleCenter, TextColor);
        }

        private static void CreateForceTeleportBlurOverlay(Transform parent,
            SGForceTeleportController controller)
        {
            string materialPath = GeneratedFolder + "/SGForceTeleportBlur.mat";
            string shaderPath = RootFolder + "/Shaders/SGFrostedVision.shader";
            Shader shader = AssetDatabase.LoadAssetAtPath<Shader>(shaderPath);
            if (shader == null) shader = Shader.Find("SGimmicks/FrostedVision");
            if (shader == null)
                throw new InvalidOperationException("視界ぼかし用Shaderが見つかりません: " + shaderPath);

            Material material = AssetDatabase.LoadAssetAtPath<Material>(materialPath);
            if (material == null)
            {
                material = new Material(shader) { name = "SGForceTeleportBlur" };
                AssetDatabase.CreateAsset(material, materialPath);
            }
            else if (material.shader != shader)
            {
                material.shader = shader;
            }
            material.SetFloat("_BlurSize", 5f);
            material.SetFloat("_Fade", 0f);
            material.SetColor("_Tint", new Color(0.72f, 0.84f, 0.95f, 0.16f));
            EditorUtility.SetDirty(material);

            GameObject overlay = GameObject.CreatePrimitive(PrimitiveType.Quad);
            overlay.name = "LocalBlurOverlay";
            overlay.transform.SetParent(parent, false);
            overlay.transform.localPosition = new Vector3(0f, 1.6f, 0.08f);
            overlay.transform.localRotation = Quaternion.identity;
            overlay.transform.localScale = new Vector3(0.42f, 0.25f, 1f);
            Collider collider = overlay.GetComponent<Collider>();
            if (collider != null) UnityEngine.Object.DestroyImmediate(collider);
            MeshRenderer renderer = overlay.GetComponent<MeshRenderer>();
            renderer.sharedMaterial = material;
            renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            renderer.receiveShadows = false;
            renderer.lightProbeUsage = UnityEngine.Rendering.LightProbeUsage.Off;
            renderer.reflectionProbeUsage = UnityEngine.Rendering.ReflectionProbeUsage.Off;
            controller.blurOverlayRenderer = renderer;
            overlay.SetActive(false);
            AssetDatabase.SaveAssets();
        }

        public static SGIntercomController ConfigureIntercom(SGIntercomController existingController,
            int slotCount, float doubleTapWindow)
        {
            slotCount = Mathf.Clamp(slotCount, 2, 80);
            SGIntercomController controller = existingController;
            if (controller == null)
            {
                GameObject root = new GameObject("SGimmicks_Intercom");
                Undo.RegisterCreatedObjectUndo(root, "Create SG Intercom");
                controller = AddUdonComponent<SGIntercomController>(root);
            }

            controller.doubleTapWindow = Mathf.Clamp(doubleTapWindow, 0.2f, 0.8f);
            controller.intercomVoiceNear = 1000000f;
            controller.intercomVoiceFar = 1000000f;
            controller.isolatedVoiceNear = 0f;
            controller.isolatedVoiceFar = 0f;
            controller.normalVoiceNear = 0f;
            controller.normalVoiceFar = 25f;

            Transform previousSlots = controller.transform.Find("IntercomSlots");
            if (previousSlots != null) Undo.DestroyObjectImmediate(previousSlots.gameObject);
            Transform previousPanel = controller.transform.Find("IntercomPanel");
            if (previousPanel != null) Undo.DestroyObjectImmediate(previousPanel.gameObject);

            GameObject slotsRoot = new GameObject("IntercomSlots");
            slotsRoot.transform.SetParent(controller.transform, false);
            controller.slots = new SGIntercomSlot[slotCount];
            for (int i = 0; i < slotCount; i++)
            {
                GameObject slotObject = new GameObject("Slot_" + (i + 1).ToString("00"));
                slotObject.transform.SetParent(slotsRoot.transform, false);
                SGIntercomSlot slot = AddUdonComponent<SGIntercomSlot>(slotObject);
                slot.controller = controller;
                slot.playerId = -1;
                slot.joined = false;
                slot.transmitting = false;
                UdonBehaviour backing = UdonSharpEditorUtility.GetBackingUdonBehaviour(slot);
                if (backing == null)
                    throw new InvalidOperationException("内線スロットのBacking UdonBehaviourを作成できませんでした。");
                backing.SyncMethod = Networking.SyncType.Manual;
                EditorUtility.SetDirty(backing);
                controller.slots[i] = slot;
            }

            CreateIntercomPanel(controller.transform, controller);
            EditorUtility.SetDirty(controller);
            UdonSharpEditorUtility.CopyProxyToUdon(controller);
            for (int i = 0; i < controller.slots.Length; i++)
            {
                EditorUtility.SetDirty(controller.slots[i]);
                UdonSharpEditorUtility.CopyProxyToUdon(controller.slots[i]);
            }
            if (controller.gameObject.scene.IsValid())
                EditorSceneManager.MarkSceneDirty(controller.gameObject.scene);
            Selection.activeGameObject = controller.gameObject;
            return controller;
        }

        private static void CreateIntercomPanel(Transform parent, SGIntercomController controller)
        {
            GameObject panelObject = new GameObject("IntercomPanel", typeof(RectTransform),
                typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster), typeof(VRCUiShape));
            panelObject.transform.SetParent(parent, false);
            RectTransform panelRect = panelObject.GetComponent<RectTransform>();
            panelRect.sizeDelta = new Vector2(760f, 560f);
            panelRect.localScale = Vector3.one * 0.001f;
            panelRect.localPosition = new Vector3(0f, 1.45f, 0f);
            panelRect.localRotation = Quaternion.identity;
            Canvas canvas = panelObject.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.WorldSpace;
            canvas.sortingOrder = 30;
            panelObject.GetComponent<CanvasScaler>().dynamicPixelsPerUnit = 100f;
            panelObject.AddComponent<Image>().color = PanelColor;

            CreateText(panelRect, "Title", "SGimmicks 内線", new Vector2(0f, -24f),
                new Vector2(700f, 64f), 48, TextAnchor.MiddleCenter, AccentColor);
            controller.participantCountText = CreateText(panelRect, "ParticipantCount", "参加者：0人",
                new Vector2(0f, -100f), new Vector2(680f, 52f), 38,
                TextAnchor.MiddleCenter, TextColor);
            Button membershipButton = CreateButton(panelRect, "ToggleParticipation", "内線に参加",
                new Vector2(0f, -175f), new Vector2(580f, 72f), controller,
                "ToggleParticipation", 40);
            controller.membershipButtonText = membershipButton.GetComponentInChildren<Text>();

            CreateText(panelRect, "Instructions",
                "1. 内線に参加\n2. 右トリガーを素早く2回押して接続\n3. 接続後は右トリガー長押しで参加者全員へ送話",
                new Vector2(0f, -270f), new Vector2(680f, 150f), 34,
                TextAnchor.MiddleCenter, TextColor);
            controller.statusText = CreateText(panelRect, "Status", "内線に参加してください",
                new Vector2(0f, -425f), new Vector2(680f, 58f), 34,
                TextAnchor.MiddleCenter, AccentColor);
            controller.transmitIndicator = CreateText(panelRect, "TransmitIndicator", "● 送話中",
                new Vector2(0f, -490f), new Vector2(680f, 48f), 36,
                TextAnchor.MiddleCenter, new Color(1f, 0.32f, 0.26f, 1f)).gameObject;
            controller.transmitIndicator.SetActive(false);
        }

        public static SGTheaterLightController ConfigureTheaterLights(GameObject boardObject,
            SGTheaterLightController existingController, IList<Light> requestedLights,
            float dimmedMultiplier, float transitionDuration, AudioClip dimmingClip,
            float audioVolume, float audioMaxDistance)
        {
            if (boardObject == null && existingController != null)
                boardObject = existingController.gameObject;
            if (boardObject == null) throw new ArgumentNullException(nameof(boardObject));
            if (requestedLights == null || requestedLights.Count == 0)
                throw new ArgumentException("暗くするLightを1個以上指定してください。");

            List<Light> lights = new List<Light>();
            List<float> intensities = new List<float>();
            for (int i = 0; i < requestedLights.Count; i++)
            {
                Light target = requestedLights[i];
                if (target == null)
                    throw new ArgumentException("対象ライト " + (i + 1) + " が未設定です。");
                lights.Add(target);
                intensities.Add(target.intensity);
            }

            SGTheaterLightController controller = existingController;
            if (controller == null || controller.gameObject != boardObject)
            {
                controller = boardObject.GetComponent<SGTheaterLightController>();
                if (controller == null) controller = AddUdonComponent<SGTheaterLightController>(boardObject);
            }
            if (boardObject.GetComponent<Collider>() == null) Undo.AddComponent<BoxCollider>(boardObject);

            controller.targetLights = lights.ToArray();
            controller.brightIntensities = intensities.ToArray();
            controller.dimmedIntensityMultiplier = Mathf.Clamp01(dimmedMultiplier);
            controller.transitionDuration = Mathf.Clamp(transitionDuration, 0.1f, 20f);

            AudioSource audioSource = boardObject.GetComponent<AudioSource>();
            if (audioSource == null) audioSource = Undo.AddComponent<AudioSource>(boardObject);
            audioSource.playOnAwake = false;
            audioSource.loop = false;
            audioSource.spatialBlend = 1f;
            audioSource.volume = Mathf.Clamp01(audioVolume);
            audioSource.minDistance = 1f;
            audioSource.maxDistance = Mathf.Max(1f, audioMaxDistance);
            audioSource.rolloffMode = AudioRolloffMode.Linear;
            audioSource.clip = dimmingClip;
            controller.dimmingAudioSource = audioSource;

            UdonBehaviour backing = UdonSharpEditorUtility.GetBackingUdonBehaviour(controller);
            if (backing == null)
                throw new InvalidOperationException("映画館照明のBacking UdonBehaviourを作成できませんでした。");
            backing.SyncMethod = Networking.SyncType.Manual;
            backing.InteractionText = "館内照明を切り替える";
            EditorUtility.SetDirty(backing);
            EditorUtility.SetDirty(controller);
            EditorUtility.SetDirty(audioSource);
            UdonSharpEditorUtility.CopyProxyToUdon(controller);
            if (boardObject.scene.IsValid()) EditorSceneManager.MarkSceneDirty(boardObject.scene);
            Selection.activeGameObject = boardObject;
            return controller;
        }

        public static SGConcertLightingController CreateDefaultConcertLighting()
        {
            GameObject root = new GameObject("SGConcertLighting");
            Undo.RegisterCreatedObjectUndo(root, "Create SGimmicks concert lighting");

            GameObject boardVisual = GameObject.CreatePrimitive(PrimitiveType.Cube);
            Undo.RegisterCreatedObjectUndo(boardVisual, "Create concert lighting board");
            boardVisual.name = "OperationBoardVisual";
            boardVisual.transform.SetParent(root.transform, false);
            boardVisual.transform.localPosition = new Vector3(0f, 1.2f, 0f);
            boardVisual.transform.localScale = new Vector3(1.2f, 0.7f, 0.12f);
            Collider boardVisualCollider = boardVisual.GetComponent<Collider>();
            if (boardVisualCollider != null) Undo.DestroyObjectImmediate(boardVisualCollider);

            GameObject ceiling = new GameObject("CeilingLightPoint");
            Undo.RegisterCreatedObjectUndo(ceiling, "Create ceiling light point");
            ceiling.transform.SetParent(root.transform, false);
            ceiling.transform.localPosition = new Vector3(0f, 5f, 4f);

            GameObject stageTarget = new GameObject("StageTargetPoint");
            Undo.RegisterCreatedObjectUndo(stageTarget, "Create stage target point");
            stageTarget.transform.SetParent(root.transform, false);
            stageTarget.transform.localPosition = new Vector3(0f, 0.9f, 4f);

            GameObject darknessVolume = new GameObject("DarknessVolume");
            Undo.RegisterCreatedObjectUndo(darknessVolume, "Create concert darkness volume");
            darknessVolume.transform.SetParent(root.transform, false);
            darknessVolume.transform.localPosition = new Vector3(0f, 2.5f, 4f);
            BoxCollider volumeCollider = Undo.AddComponent<BoxCollider>(darknessVolume);
            volumeCollider.isTrigger = true;
            volumeCollider.size = new Vector3(12f, 5f, 12f);

            SGConcertLightingController controller = ConfigureConcertLighting(root, null,
                ceiling.transform, stageTarget.transform, volumeCollider, 0.5f, 38f, 0.08f,
                0.18f, 3f, new Color(1f, 0.88f, 0.68f, 1f), 4f, 0.16f,
                null, 1f, 25f);
            Selection.activeGameObject = root;
            return controller;
        }

        public static SGConcertLightingController ConfigureConcertLighting(GameObject boardObject,
            SGConcertLightingController existingController, Transform ceilingPoint,
            Transform stageTarget, BoxCollider darknessVolume, float darknessBoundsPadding,
            float coneAngle,
            float audienceBrightness, float edgeSoftness, float transitionDuration,
            Color lightColor, float lightIntensity, float beamOpacity, AudioClip startClip,
            float audioVolume, float audioMaxDistance)
        {
            if (boardObject == null && existingController != null)
                boardObject = existingController.gameObject;
            if (boardObject == null) throw new ArgumentNullException(nameof(boardObject));
            if (ceilingPoint == null) throw new ArgumentNullException(nameof(ceilingPoint));
            if (stageTarget == null) throw new ArgumentNullException(nameof(stageTarget));
            if (darknessVolume == null) throw new ArgumentNullException(nameof(darknessVolume));

            EnsureAssetFolders();
            SGConcertLightingController controller = existingController;
            if (controller == null || controller.gameObject != boardObject)
            {
                controller = boardObject.GetComponent<SGConcertLightingController>();
                if (controller == null)
                    controller = AddUdonComponent<SGConcertLightingController>(boardObject);
            }
            BoxCollider obsoleteUseCollider = boardObject.GetComponent<BoxCollider>();
            if (obsoleteUseCollider != null && boardObject.name.StartsWith("SGConcertLighting"))
                Undo.DestroyObjectImmediate(obsoleteUseCollider);

            Transform generatedRoot = boardObject.transform.Find("ConcertLightingGenerated");
            if (generatedRoot == null)
            {
                GameObject generatedObject = new GameObject("ConcertLightingGenerated");
                Undo.RegisterCreatedObjectUndo(generatedObject, "Create concert lighting output");
                generatedObject.transform.SetParent(boardObject.transform, false);
                generatedRoot = generatedObject.transform;
            }

            Material darknessMaterial = GetOrCreateConcertDarknessMaterial();
            Material beamMaterial = GetOrCreateConcertBeamMaterial();
            Mesh beamMesh = GetOrCreateConcertBeamMesh();

            Transform projectorTransform = generatedRoot.Find("AudienceDarknessProjector");
            if (projectorTransform == null)
            {
                GameObject projectorObject = new GameObject("AudienceDarknessProjector");
                Undo.RegisterCreatedObjectUndo(projectorObject, "Create audience darkness projector");
                projectorObject.transform.SetParent(generatedRoot, false);
                projectorTransform = projectorObject.transform;
            }
            Projector projector = projectorTransform.GetComponent<Projector>();
            if (projector == null) projector = Undo.AddComponent<Projector>(projectorTransform.gameObject);
            ConfigureConcertProjector(projector, darknessVolume, darknessBoundsPadding,
                darknessMaterial);

            Transform spotTransform = generatedRoot.Find("StageSpotLight");
            if (spotTransform == null)
            {
                GameObject spotObject = new GameObject("StageSpotLight");
                Undo.RegisterCreatedObjectUndo(spotObject, "Create concert stage spotlight");
                spotObject.transform.SetParent(generatedRoot, false);
                spotTransform = spotObject.transform;
            }
            Light spotLight = spotTransform.GetComponent<Light>();
            bool createdSpotLight = spotLight == null;
            if (createdSpotLight) spotLight = Undo.AddComponent<Light>(spotTransform.gameObject);
            spotLight.type = LightType.Spot;
            spotLight.color = lightColor;
            spotLight.intensity = 0f;
            spotLight.range = Vector3.Distance(ceilingPoint.position, stageTarget.position) + 0.8f;
            spotLight.spotAngle = Mathf.Clamp(coneAngle, 5f, 100f);
            if (createdSpotLight)
            {
                spotLight.renderMode = LightRenderMode.ForcePixel;
                spotLight.shadows = LightShadows.Soft;
            }
            spotLight.enabled = false;

            Transform beamTransform = generatedRoot.Find("VisibleLightCone");
            if (beamTransform == null)
            {
                GameObject beamObject = new GameObject("VisibleLightCone");
                Undo.RegisterCreatedObjectUndo(beamObject, "Create visible concert light cone");
                beamObject.transform.SetParent(generatedRoot, false);
                beamTransform = beamObject.transform;
            }
            MeshFilter beamFilter = beamTransform.GetComponent<MeshFilter>();
            if (beamFilter == null) beamFilter = Undo.AddComponent<MeshFilter>(beamTransform.gameObject);
            MeshRenderer beamRenderer = beamTransform.GetComponent<MeshRenderer>();
            if (beamRenderer == null) beamRenderer = Undo.AddComponent<MeshRenderer>(beamTransform.gameObject);
            beamFilter.sharedMesh = beamMesh;
            beamRenderer.sharedMaterial = beamMaterial;
            beamRenderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            beamRenderer.receiveShadows = false;

            controller.ceilingLightPoint = ceilingPoint;
            controller.stageTargetPoint = stageTarget;
            controller.coneAngle = Mathf.Clamp(coneAngle, 5f, 100f);
            controller.stageSpotLight = spotLight;
            controller.stageBrightIntensity = Mathf.Max(0f, lightIntensity);
            controller.stageLightColor = lightColor;
            controller.darknessVolume = darknessVolume;
            controller.darknessBoundsPadding = Mathf.Max(0f, darknessBoundsPadding);
            controller.darknessMaterial = darknessMaterial;
            controller.audienceBrightness = Mathf.Clamp01(audienceBrightness);
            controller.coneEdgeSoftness = Mathf.Clamp(edgeSoftness, 0.01f, 1f);
            controller.beamTransform = beamTransform;
            controller.beamMaterial = beamMaterial;
            controller.beamOpacity = Mathf.Clamp01(beamOpacity);
            controller.transitionDuration = Mathf.Clamp(transitionDuration, 0.1f, 20f);
            PositionConcertCone(controller);

            AudioSource audioSource = boardObject.GetComponent<AudioSource>();
            bool createdAudioSource = audioSource == null;
            if (createdAudioSource) audioSource = Undo.AddComponent<AudioSource>(boardObject);
            audioSource.playOnAwake = false;
            audioSource.loop = false;
            audioSource.spatialBlend = 1f;
            audioSource.volume = Mathf.Clamp01(audioVolume);
            if (createdAudioSource)
            {
                audioSource.minDistance = 1f;
                audioSource.rolloffMode = AudioRolloffMode.Linear;
            }
            audioSource.maxDistance = Mathf.Max(1f, audioMaxDistance);
            audioSource.clip = startClip;
            controller.startAudioSource = audioSource;

            CreateConcertStatusPanel(boardObject.transform, controller);
            UdonBehaviour backing = UdonSharpEditorUtility.GetBackingUdonBehaviour(controller);
            if (backing == null)
                throw new InvalidOperationException("コンサート照明のBacking UdonBehaviourを作成できませんでした。");
            backing.SyncMethod = Networking.SyncType.Manual;
            backing.InteractionText = string.Empty;

            EditorUtility.SetDirty(backing);
            EditorUtility.SetDirty(controller);
            EditorUtility.SetDirty(projector);
            EditorUtility.SetDirty(spotLight);
            EditorUtility.SetDirty(beamRenderer);
            EditorUtility.SetDirty(audioSource);
            UdonSharpEditorUtility.CopyProxyToUdon(controller);
            if (boardObject.scene.IsValid()) EditorSceneManager.MarkSceneDirty(boardObject.scene);
            Selection.activeGameObject = boardObject;
            return controller;
        }

        private static void PositionConcertCone(SGConcertLightingController controller)
        {
            Vector3 origin = controller.ceilingLightPoint.position;
            Vector3 offset = controller.stageTargetPoint.position - origin;
            float distance = offset.magnitude;
            if (distance < 0.01f) return;
            Vector3 direction = offset / distance;
            Vector3 rotationUp = Mathf.Abs(Vector3.Dot(direction, Vector3.up)) > 0.98f
                ? Vector3.forward
                : Vector3.up;
            Quaternion rotation = Quaternion.LookRotation(direction, rotationUp);
            float range = distance + controller.rangePadding;
            float radius = Mathf.Tan(controller.coneAngle * 0.5f * Mathf.Deg2Rad) * range;

            controller.stageSpotLight.transform.position = origin;
            controller.stageSpotLight.transform.rotation = rotation;
            controller.stageSpotLight.range = range;
            controller.stageSpotLight.spotAngle = controller.coneAngle;
            controller.beamTransform.position = origin;
            controller.beamTransform.rotation = rotation;
            controller.beamTransform.localScale = new Vector3(radius, radius, range);
        }

        private static void ConfigureConcertProjector(Projector projector, BoxCollider volume,
            float boundsPadding, Material darknessMaterial)
        {
            Transform volumeTransform = volume.transform;
            Vector3 lossy = volumeTransform.lossyScale;
            float padding = Mathf.Max(0f, boundsPadding);
            Vector3 size = new Vector3(
                Mathf.Abs(volume.size.x * lossy.x) + padding * 2f,
                Mathf.Abs(volume.size.y * lossy.y) + padding * 2f,
                Mathf.Abs(volume.size.z * lossy.z) + padding * 2f);
            Vector3 center = volumeTransform.TransformPoint(volume.center);
            projector.transform.position = center + volumeTransform.up * (size.y * 0.5f);
            projector.transform.rotation = Quaternion.LookRotation(-volumeTransform.up,
                volumeTransform.forward);
            projector.orthographic = true;
            projector.orthographicSize = Mathf.Max(0.1f, size.z * 0.5f);
            projector.aspectRatio = Mathf.Max(0.01f, size.x / Mathf.Max(0.01f, size.z));
            projector.nearClipPlane = 0.01f;
            projector.farClipPlane = Mathf.Max(0.1f, size.y + 0.05f);
            projector.ignoreLayers = 0;
            projector.material = darknessMaterial;
            projector.enabled = true;

            darknessMaterial.SetVector("_VolumeCenter",
                new Vector4(center.x, center.y, center.z, 1f));
            Vector3 axisX = volumeTransform.right;
            Vector3 axisY = volumeTransform.up;
            Vector3 axisZ = volumeTransform.forward;
            darknessMaterial.SetVector("_VolumeAxisX",
                new Vector4(axisX.x, axisX.y, axisX.z, 0f));
            darknessMaterial.SetVector("_VolumeAxisY",
                new Vector4(axisY.x, axisY.y, axisY.z, 0f));
            darknessMaterial.SetVector("_VolumeAxisZ",
                new Vector4(axisZ.x, axisZ.y, axisZ.z, 0f));
            darknessMaterial.SetVector("_VolumeHalfSize",
                new Vector4(size.x * 0.5f, size.y * 0.5f, size.z * 0.5f, 0f));
            EditorUtility.SetDirty(darknessMaterial);
        }

        private static void CreateConcertStatusPanel(Transform parent,
            SGConcertLightingController controller)
        {
            Transform previous = parent.Find("ConcertLightingPanel");
            if (previous != null)
            {
                Button existingButton = previous.Find("ToggleConcertLighting")?.GetComponent<Button>();
                Text existingStatus = previous.Find("Status")?.GetComponent<Text>();
                if (previous.GetComponent<Canvas>() != null &&
                    previous.GetComponent<VRCUiShape>() != null &&
                    existingButton != null && existingStatus != null &&
                    existingButton.onClick.GetPersistentEventCount() > 0 &&
                    existingButton.onClick.GetPersistentTarget(0) != null)
                {
                    // Keep the complete existing panel so user-adjusted placement, scale and
                    // child layout are never lost when only the darkness volume is refreshed.
                    controller.statusText = existingStatus;
                    return;
                }
            }

            bool preservePlacement = previous != null;
            Vector3 previousLocalPosition = preservePlacement ? previous.localPosition : Vector3.zero;
            Quaternion previousLocalRotation = preservePlacement ? previous.localRotation : Quaternion.identity;
            Vector3 previousLocalScale = preservePlacement ? previous.localScale : Vector3.one;
            Vector2 previousSize = preservePlacement && previous is RectTransform previousRect
                ? previousRect.sizeDelta
                : Vector2.zero;
            if (previous != null) Undo.DestroyObjectImmediate(previous.gameObject);
            GameObject panelObject = new GameObject("ConcertLightingPanel", typeof(RectTransform),
                typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster), typeof(VRCUiShape),
                typeof(Image));
            Undo.RegisterCreatedObjectUndo(panelObject, "Create concert lighting panel");
            panelObject.transform.SetParent(parent, false);
            RectTransform panelRect = panelObject.GetComponent<RectTransform>();
            panelRect.sizeDelta = new Vector2(760f, 300f);
            panelRect.localScale = Vector3.one * 0.001f;
            panelRect.localPosition = new Vector3(0f, 1.2f, -0.075f);
            panelRect.localRotation = Quaternion.identity;
            if (preservePlacement)
            {
                panelRect.localPosition = previousLocalPosition;
                panelRect.localRotation = previousLocalRotation;
                panelRect.localScale = previousLocalScale;
                panelRect.sizeDelta = previousSize;
            }
            panelObject.GetComponent<Canvas>().renderMode = RenderMode.WorldSpace;
            panelObject.GetComponent<Canvas>().sortingOrder = 25;
            panelObject.GetComponent<CanvasScaler>().dynamicPixelsPerUnit = 100f;
            panelObject.GetComponent<Image>().color = PanelColor;
            CreateText(panelRect, "Title", "コンサート照明", new Vector2(0f, -45f),
                new Vector2(700f, 80f), 48, TextAnchor.MiddleCenter, AccentColor);
            CreateButton(panelRect, "ToggleConcertLighting", "照明を切り替える",
                new Vector2(0f, -140f), new Vector2(620f, 78f), controller,
                "ToggleConcertLighting", 38);
            controller.statusText = CreateText(panelRect, "Status", "通常照明",
                new Vector2(0f, -225f), new Vector2(700f, 65f), 38,
                TextAnchor.MiddleCenter, AccentColor);
        }

        private static Material GetOrCreateConcertDarknessMaterial()
        {
            string path = GeneratedFolder + "/SGConcertDarkness.mat";
            Material material = AssetDatabase.LoadAssetAtPath<Material>(path);
            Shader shader = Shader.Find("SGimmicks/ConcertDarknessProjector");
            if (shader == null) throw new InvalidOperationException("暗転Projectorシェーダーが見つかりません。");
            if (material == null)
            {
                material = new Material(shader) { name = "SGConcertDarkness" };
                AssetDatabase.CreateAsset(material, path);
            }
            else material.shader = shader;
            material.SetFloat("_DimFactor", 1f);
            EditorUtility.SetDirty(material);
            return material;
        }

        private static Material GetOrCreateConcertBeamMaterial()
        {
            string path = GeneratedFolder + "/SGConcertLightBeam.mat";
            Material material = AssetDatabase.LoadAssetAtPath<Material>(path);
            Shader shader = Shader.Find("SGimmicks/ConcertLightBeam");
            if (shader == null) throw new InvalidOperationException("円錐ライトシェーダーが見つかりません。");
            if (material == null)
            {
                material = new Material(shader) { name = "SGConcertLightBeam" };
                AssetDatabase.CreateAsset(material, path);
            }
            else material.shader = shader;
            material.SetColor("_Color", new Color(1f, 0.82f, 0.58f, 1f));
            material.SetFloat("_Opacity", 0f);
            material.SetFloat("_EdgePower", 2f);
            EditorUtility.SetDirty(material);
            return material;
        }

        private static Mesh GetOrCreateConcertBeamMesh()
        {
            string path = GeneratedFolder + "/SGConcertLightCone.asset";
            Mesh existing = AssetDatabase.LoadAssetAtPath<Mesh>(path);
            if (existing != null) return existing;

            const int segments = 32;
            Vector3[] vertices = new Vector3[segments + 2];
            Vector2[] uv = new Vector2[vertices.Length];
            int[] triangles = new int[segments * 3];
            vertices[0] = Vector3.zero;
            uv[0] = new Vector2(0.5f, 0f);
            for (int i = 0; i <= segments; i++)
            {
                float angle = Mathf.PI * 2f * i / segments;
                vertices[i + 1] = new Vector3(Mathf.Cos(angle), Mathf.Sin(angle), 1f);
                uv[i + 1] = new Vector2((float)i / segments, 1f);
                if (i >= segments) continue;
                int triangle = i * 3;
                triangles[triangle] = 0;
                triangles[triangle + 1] = i + 1;
                triangles[triangle + 2] = i + 2;
            }

            Mesh mesh = new Mesh { name = "SGConcertLightCone" };
            mesh.vertices = vertices;
            mesh.uv = uv;
            mesh.triangles = triangles;
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();
            AssetDatabase.CreateAsset(mesh, path);
            return mesh;
        }

        public static SGMessageBoardController ConfigureMessageBoard(GameObject useObject,
            SGMessageBoardController existingController, IList<TMP_Text> requestedOutputs,
            float fontSize, AudioClip submitClip, float audioVolume, float audioMaxDistance)
        {
            if (useObject == null && existingController != null) useObject = existingController.gameObject;
            if (useObject == null) throw new ArgumentNullException(nameof(useObject));
            if (requestedOutputs == null || requestedOutputs.Count == 0)
                throw new ArgumentException("表示先のTextMeshProを1個以上指定してください。");

            SGMessageBoardController controller = existingController;
            if (controller == null || controller.gameObject != useObject)
            {
                controller = useObject.GetComponent<SGMessageBoardController>();
                if (controller == null) controller = AddUdonComponent<SGMessageBoardController>(useObject);
            }
            BoxCollider obsoleteInteractionCollider = useObject.GetComponent<BoxCollider>();
            if (obsoleteInteractionCollider != null)
                Undo.DestroyObjectImmediate(obsoleteInteractionCollider);
            TMP_FontAsset japaneseFont = EnsureJapaneseTmpFont();

            List<TMP_Text> outputs = new List<TMP_Text>();
            for (int i = 0; i < requestedOutputs.Count; i++)
            {
                TMP_Text output = requestedOutputs[i];
                if (output == null)
                    output = CreateMessageDisplayCanvas(useObject.transform, i, japaneseFont);
                outputs.Add(output);
            }
            foreach (TMP_Text output in outputs)
            {
                output.font = japaneseFont;
                output.fontSize = Mathf.Clamp(fontSize, 12f, 200f);
                output.richText = false;
                output.enableWordWrapping = true;
                EditorUtility.SetDirty(output);
            }

            Transform previousPanel = useObject.transform.Find("MessageInputPanel");
            if (previousPanel != null) Undo.DestroyObjectImmediate(previousPanel.gameObject);
            GameObject panelObject = new GameObject("MessageInputPanel", typeof(RectTransform),
                typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster), typeof(VRCUiShape), typeof(Image));
            Undo.RegisterCreatedObjectUndo(panelObject, "Create SGimmicks message input panel");
            panelObject.transform.SetParent(useObject.transform, false);
            RectTransform panelRect = panelObject.GetComponent<RectTransform>();
            panelRect.sizeDelta = new Vector2(1000f, 820f);
            panelRect.localPosition = new Vector3(0f, 0f, -0.03f);
            panelRect.localRotation = Quaternion.identity;
            panelRect.localScale = Vector3.one * 0.001f;
            Canvas canvas = panelObject.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.WorldSpace;
            canvas.sortingOrder = 40;
            panelObject.GetComponent<CanvasScaler>().dynamicPixelsPerUnit = 100f;
            panelObject.GetComponent<Image>().color = PanelColor;

            CreateTmpText(panelRect, "Title", "お題・メッセージ入力", new Vector2(0f, -28f),
                new Vector2(900f, 72f), 46f, japaneseFont, TextAlignmentOptions.Center);
            TMP_InputField input = CreateTmpInputField(panelRect, japaneseFont);
            TMP_Text preview = CreateTmpText(panelRect, "Preview", "入力内容のプレビュー",
                new Vector2(0f, -390f), new Vector2(850f, 190f), 40f, japaneseFont,
                TextAlignmentOptions.Center);
            preview.color = TextColor;

            CreateTmpButton(panelRect, "FontSizeDown", "文字を小さく", new Vector2(-245f, -580f),
                new Vector2(230f, 56f), controller, "DecreaseFontSize", japaneseFont);
            TMP_Text fontSizeLabel = CreateTmpText(panelRect, "FontSizeValue", "本文サイズ 52",
                new Vector2(0f, -580f), new Vector2(230f, 56f), 30f, japaneseFont,
                TextAlignmentOptions.Center);
            CreateTmpButton(panelRect, "FontSizeUp", "文字を大きく", new Vector2(245f, -580f),
                new Vector2(230f, 56f), controller, "IncreaseFontSize", japaneseFont);

            CreateTmpButton(panelRect, "PreviewButton", "プレビュー", new Vector2(-310f, -650f),
                new Vector2(260f, 72f), controller, "UpdatePreview", japaneseFont);
            CreateTmpButton(panelRect, "ClearButton", "クリア", new Vector2(0f, -650f),
                new Vector2(220f, 72f), controller, "ClearInput", japaneseFont);
            CreateTmpButton(panelRect, "SubmitButton", "OK・全員に表示", new Vector2(310f, -650f),
                new Vector2(300f, 72f), controller, "SubmitMessage", japaneseFont);
            CreateTmpButton(panelRect, "CancelButton", "キャンセル", new Vector2(0f, -742f),
                new Vector2(260f, 62f), controller, "CancelInput", japaneseFont);

            AudioSource audioSource = useObject.GetComponent<AudioSource>();
            if (audioSource == null) audioSource = Undo.AddComponent<AudioSource>(useObject);
            audioSource.playOnAwake = false;
            audioSource.loop = false;
            audioSource.spatialBlend = 1f;
            audioSource.volume = Mathf.Clamp01(audioVolume);
            audioSource.minDistance = 1f;
            audioSource.maxDistance = Mathf.Max(1f, audioMaxDistance);
            audioSource.rolloffMode = AudioRolloffMode.Linear;
            audioSource.clip = submitClip;

            List<AudioSource> outputAudioSources = new List<AudioSource>();
            foreach (TMP_Text output in outputs)
            {
                Canvas outputCanvas = output.GetComponentInParent<Canvas>();
                GameObject audioObject = outputCanvas != null ? outputCanvas.gameObject : output.gameObject;
                AudioSource outputAudio = audioObject.GetComponent<AudioSource>();
                if (outputAudio == null) outputAudio = Undo.AddComponent<AudioSource>(audioObject);
                outputAudio.playOnAwake = false;
                outputAudio.loop = false;
                outputAudio.spatialBlend = 1f;
                outputAudio.volume = Mathf.Clamp01(audioVolume);
                outputAudio.minDistance = 1f;
                outputAudio.maxDistance = Mathf.Max(1f, audioMaxDistance);
                outputAudio.rolloffMode = AudioRolloffMode.Linear;
                outputAudio.clip = submitClip;
                if (!outputAudioSources.Contains(outputAudio)) outputAudioSources.Add(outputAudio);
                EditorUtility.SetDirty(outputAudio);
            }

            controller.inputPanelRoot = panelObject;
            controller.inputField = input;
            controller.previewText = preview;
            controller.fontSizeText = fontSizeLabel;
            controller.maximumCharacters = 100;
            controller.keepInputPanelVisible = true;
            controller.outputTexts = outputs.ToArray();
            controller.outputFontSize = Mathf.Clamp(fontSize, 12f, 200f);
            controller.syncedFontSize = controller.outputFontSize;
            controller.submitAudioSource = audioSource;
            controller.outputAudioSources = outputAudioSources.ToArray();
            panelObject.SetActive(controller.keepInputPanelVisible);

            UdonBehaviour backing = UdonSharpEditorUtility.GetBackingUdonBehaviour(controller);
            if (backing == null) throw new InvalidOperationException("メッセージボードのBacking UdonBehaviourを作成できませんでした。");
            backing.SyncMethod = Networking.SyncType.Manual;
            backing.InteractionText = "文字を入力する";
            EditorUtility.SetDirty(backing);
            EditorUtility.SetDirty(controller);
            EditorUtility.SetDirty(audioSource);
            UdonSharpEditorUtility.CopyProxyToUdon(controller);
            if (useObject.scene.IsValid()) EditorSceneManager.MarkSceneDirty(useObject.scene);
            Selection.activeGameObject = useObject;
            return controller;
        }

        public static SGMessageBoardController CreateCompleteMessageBoard()
        {
            GameObject root = new GameObject("SGMessageBoard");
            Undo.RegisterCreatedObjectUndo(root, "Create SGimmicks message board");
            Vector3 spawnPosition = Vector3.zero;
            if (SceneView.lastActiveSceneView != null) spawnPosition = SceneView.lastActiveSceneView.pivot;
            root.transform.position = spawnPosition;

            TMP_Text output = CreateMessageDisplayCanvas(root.transform, 0, EnsureJapaneseTmpFont());

            SGMessageBoardController controller = ConfigureMessageBoard(root, null,
                new TMP_Text[] { output }, 52f, null, 1f, 25f);
            if (controller.inputPanelRoot != null)
            {
                controller.inputPanelRoot.transform.localPosition = new Vector3(0f, 1.96f, -0.02f);
                controller.inputPanelRoot.SetActive(true);
                EditorUtility.SetDirty(controller.inputPanelRoot.transform);
            }
            UdonSharpEditorUtility.CopyProxyToUdon(controller);
            Selection.activeGameObject = root;
            return controller;
        }

        private static TMP_Text CreateMessageDisplayCanvas(Transform parent, int index,
            TMP_FontAsset japaneseFont)
        {
            string suffix = index == 0 ? "" : "_" + (index + 1).ToString("00");
            GameObject displayCanvasObject = new GameObject("MessageDisplayCanvas" + suffix,
                typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler),
                typeof(GraphicRaycaster), typeof(VRCUiShape), typeof(Image));
            Undo.RegisterCreatedObjectUndo(displayCanvasObject, "Create message display UI");
            displayCanvasObject.transform.SetParent(parent, false);
            RectTransform displayRect = displayCanvasObject.GetComponent<RectTransform>();
            displayRect.sizeDelta = new Vector2(1200f, 500f);
            int column = index % 2;
            int row = index / 2;
            displayRect.localPosition = new Vector3(column * 3.9f, 3.25f - row * 1.8f, 1.5f);
            displayRect.localRotation = Quaternion.identity;
            displayRect.localScale = Vector3.one * 0.003f;
            Canvas displayCanvas = displayCanvasObject.GetComponent<Canvas>();
            displayCanvas.renderMode = RenderMode.WorldSpace;
            displayCanvas.sortingOrder = 20 + index;
            displayCanvasObject.GetComponent<CanvasScaler>().dynamicPixelsPerUnit = 100f;
            displayCanvasObject.GetComponent<Image>().color = PanelColor;

            TMP_Text output = CreateTmpText(displayRect, "MessageDisplayText", "お題を入力してください",
                Vector2.zero, Vector2.zero, 52f, japaneseFont, TextAlignmentOptions.Center);
            RectTransform outputRect = output.rectTransform;
            outputRect.anchorMin = Vector2.zero;
            outputRect.anchorMax = Vector2.one;
            outputRect.pivot = new Vector2(0.5f, 0.5f);
            outputRect.offsetMin = new Vector2(45f, 30f);
            outputRect.offsetMax = new Vector2(-45f, -30f);
            return output;
        }

        public static TMP_FontAsset EnsureJapaneseTmpFont()
        {
            EnsureAssetFolders();
            string fontAssetPath = GeneratedFolder + "/NotoSansJP-Dynamic SDF.asset";
            TMP_FontAsset existing = AssetDatabase.LoadAssetAtPath<TMP_FontAsset>(fontAssetPath);
            if (existing != null) return existing;
            Font source = AssetDatabase.LoadAssetAtPath<Font>(RootFolder + "/Fonts/NotoSansJP-Regular.ttf");
            if (source == null) throw new InvalidOperationException("同梱日本語フォントが見つかりません。");
            if (Shader.Find("TextMeshPro/Mobile/Distance Field") == null)
            {
                UnityEditor.PackageManager.PackageInfo package =
                    UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(TMP_FontAsset).Assembly);
                if (package == null) throw new InvalidOperationException("TextMesh Proパッケージが見つかりません。");
                string essentials = Path.Combine(package.resolvedPath,
                    "Package Resources", "TMP Essential Resources.unitypackage");
                AssetDatabase.ImportPackage(essentials, false);
                AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
            }
            if (Shader.Find("TextMeshPro/Mobile/Distance Field") == null)
                throw new InvalidOperationException("TextMesh ProのDistance Field Shaderを読み込めませんでした。");
            TMP_FontAsset created = TMP_FontAsset.CreateFontAsset(source);
            created.name = "NotoSansJP-Dynamic SDF";
            created.atlasPopulationMode = AtlasPopulationMode.Dynamic;
            created.isMultiAtlasTexturesEnabled = true;
            AssetDatabase.CreateAsset(created, fontAssetPath);
            if (created.material != null && !AssetDatabase.Contains(created.material))
                AssetDatabase.AddObjectToAsset(created.material, created);
            if (created.atlasTexture != null && !AssetDatabase.Contains(created.atlasTexture))
                AssetDatabase.AddObjectToAsset(created.atlasTexture, created);
            EditorUtility.SetDirty(created);
            AssetDatabase.SaveAssets();
            return created;
        }

        private static void BuildMonitorWall(SGSurveillanceController controller, Renderer legacyMonitorRenderer,
            Camera[] cameras, string[] labels, RenderTexture preferredFirstTexture)
        {
            Dictionary<RenderTexture, Material> existingMaterials = new Dictionary<RenderTexture, Material>();
            if (controller.monitorRenderers != null)
            {
                foreach (Renderer renderer in controller.monitorRenderers)
                {
                    RememberMonitorMaterial(existingMaterials, renderer);
                }
            }
            RememberMonitorMaterial(existingMaterials, legacyMonitorRenderer);

            Vector3 wallPosition = new Vector3(0f, 1.65f, 0f);
            Quaternion wallRotation = Quaternion.identity;
            Transform previousWall = controller.transform.Find("MonitorWall");
            if (previousWall != null)
            {
                wallPosition = previousWall.localPosition;
                wallRotation = previousWall.localRotation;
            }
            else if (legacyMonitorRenderer != null)
            {
                wallPosition = controller.transform.InverseTransformPoint(legacyMonitorRenderer.transform.position);
                wallRotation = Quaternion.Inverse(controller.transform.rotation) * legacyMonitorRenderer.transform.rotation;
            }

            Transform previousFocus = controller.transform.Find("LocalFocusMonitor");
            if (previousWall != null) Undo.DestroyObjectImmediate(previousWall.gameObject);
            if (previousFocus != null) Undo.DestroyObjectImmediate(previousFocus.gameObject);
            if (legacyMonitorRenderer != null && legacyMonitorRenderer.transform.parent == controller.transform &&
                legacyMonitorRenderer.gameObject.name == "Monitor")
            {
                Undo.DestroyObjectImmediate(legacyMonitorRenderer.gameObject);
            }

            int cameraCount = cameras.Length;
            int columns;
            if (cameraCount <= 4) columns = Mathf.CeilToInt(Mathf.Sqrt(cameraCount));
            else if (cameraCount <= 8) columns = Mathf.CeilToInt(cameraCount / 2f);
            else columns = Mathf.CeilToInt(Mathf.Sqrt(cameraCount * 16f / 9f));
            columns = Mathf.Max(1, columns);
            int rows = Mathf.Max(1, Mathf.CeilToInt((float)cameraCount / columns));
            controller.monitorColumns = columns;
            controller.monitorRows = rows;

            const float screenWidth = 2.2f;
            const float screenHeight = 1.2375f;
            const float horizontalGap = 0.16f;
            const float verticalGap = 0.24f;
            float totalWidth = columns * screenWidth + (columns - 1) * horizontalGap;
            float totalHeight = rows * screenHeight + (rows - 1) * verticalGap;

            GameObject wallObject = new GameObject("MonitorWall");
            wallObject.transform.SetParent(controller.transform, false);
            wallObject.transform.localPosition = wallPosition;
            wallObject.transform.localRotation = wallRotation;
            controller.monitorWallRoot = wallObject;

            Material frameMaterial = GetOrCreateFrameMaterial();
            Renderer[] monitorRenderers = new Renderer[cameraCount];
            Material[] cameraMaterials = new Material[cameraCount];
            HashSet<RenderTexture> assignedTextures = new HashSet<RenderTexture>();

            for (int i = 0; i < cameraCount; i++)
            {
                RenderTexture texture = i == 0 && preferredFirstTexture != null
                    ? preferredFirstTexture
                    : cameras[i].targetTexture;
                Material monitorMaterial = null;
                if (texture == null || assignedTextures.Contains(texture))
                {
                    CreateSurveillanceAssets(controller.gameObject.name + "_Camera_" + (i + 1).ToString("00"),
                        512, 288, out texture, out monitorMaterial);
                }
                else if (!existingMaterials.TryGetValue(texture, out monitorMaterial))
                {
                    monitorMaterial = GetOrCreateMonitorMaterial(texture);
                }

                assignedTextures.Add(texture);
                cameraMaterials[i] = monitorMaterial;
                cameras[i].targetTexture = texture;
                cameras[i].enabled = false;
                EditorUtility.SetDirty(cameras[i]);

                int row = i / columns;
                int column = i % columns;
                int itemsInRow = Mathf.Min(columns, cameraCount - row * columns);
                float rowWidth = itemsInRow * screenWidth + (itemsInRow - 1) * horizontalGap;
                float x = -rowWidth * 0.5f + screenWidth * 0.5f + column * (screenWidth + horizontalGap);
                float y = totalHeight * 0.5f - screenHeight * 0.5f - row * (screenHeight + verticalGap);
                monitorRenderers[i] = CreateFramedMonitor(wallObject.transform,
                    "Monitor_" + (i + 1).ToString("00"), new Vector3(x, y, 0f),
                    screenWidth, screenHeight, monitorMaterial, frameMaterial, labels[i]);
            }

            controller.monitorRenderers = monitorRenderers;
            controller.monitorRenderer = monitorRenderers.Length > 0 ? monitorRenderers[0] : null;

            GameObject focusRoot = new GameObject("LocalFocusMonitor");
            focusRoot.transform.SetParent(controller.transform, false);
            focusRoot.transform.localPosition = wallPosition + wallRotation * new Vector3(0f, 0f, -0.12f);
            focusRoot.transform.localRotation = wallRotation;
            controller.focusMonitorRoot = focusRoot;

            float focusWidth = Mathf.Clamp(totalWidth, 3.8f, 6.8f);
            float focusHeight = focusWidth * 9f / 16f;
            CreateMonitorFrame(focusRoot.transform, "FocusFrame", Vector3.zero,
                focusWidth, focusHeight, frameMaterial);
            GameObject[] focusScreens = new GameObject[cameraCount];
            for (int i = 0; i < cameraCount; i++)
            {
                GameObject screen = CreateMonitorScreen(focusRoot.transform,
                    "FocusCamera_" + (i + 1).ToString("00"), Vector3.zero,
                    focusWidth, focusHeight, cameraMaterials[i]);
                screen.SetActive(i == 0);
                focusScreens[i] = screen;
            }
            CreateWorldLabel(focusRoot.transform, "FocusLabel", "ローカル拡大表示",
                new Vector3(0f, focusHeight * 0.5f + 0.16f, -0.035f));
            controller.focusMonitorScreens = focusScreens;
            focusRoot.SetActive(false);
            AssetDatabase.SaveAssets();
        }

        private static Renderer CreateFramedMonitor(Transform parent, string name, Vector3 position,
            float width, float height, Material screenMaterial, Material frameMaterial, string label)
        {
            GameObject root = new GameObject(name);
            root.transform.SetParent(parent, false);
            root.transform.localPosition = position;
            CreateMonitorFrame(root.transform, "Frame", Vector3.zero, width, height, frameMaterial);
            GameObject screen = CreateMonitorScreen(root.transform, "Screen", Vector3.zero,
                width, height, screenMaterial);
            CreateWorldLabel(root.transform, "CameraLabel", label,
                new Vector3(0f, -height * 0.5f - 0.10f, -0.035f));
            return screen.GetComponent<Renderer>();
        }

        private static void CreateMonitorFrame(Transform parent, string name, Vector3 position,
            float width, float height, Material material)
        {
            GameObject frame = GameObject.CreatePrimitive(PrimitiveType.Cube);
            frame.name = name;
            frame.transform.SetParent(parent, false);
            frame.transform.localPosition = position + new Vector3(0f, 0f, 0.035f);
            frame.transform.localScale = new Vector3(width + 0.14f, height + 0.14f, 0.07f);
            Collider collider = frame.GetComponent<Collider>();
            if (collider != null) UnityEngine.Object.DestroyImmediate(collider);
            frame.GetComponent<Renderer>().sharedMaterial = material;
        }

        private static GameObject CreateMonitorScreen(Transform parent, string name, Vector3 position,
            float width, float height, Material material)
        {
            GameObject screen = GameObject.CreatePrimitive(PrimitiveType.Quad);
            screen.name = name;
            screen.transform.SetParent(parent, false);
            // Keep the video surface clearly in front of the solid frame backing.
            // Coplanar surfaces cause view-dependent Z-fighting and visible flashing in VR.
            screen.transform.localPosition = position + new Vector3(0f, 0f, -0.025f);
            screen.transform.localScale = new Vector3(width, height, 1f);
            Collider collider = screen.GetComponent<Collider>();
            if (collider != null) UnityEngine.Object.DestroyImmediate(collider);
            screen.GetComponent<Renderer>().sharedMaterial = material;
            return screen;
        }

        private static void CreateWorldLabel(Transform parent, string name, string value, Vector3 position)
        {
            GameObject labelObject = new GameObject(name, typeof(TextMesh));
            labelObject.transform.SetParent(parent, false);
            labelObject.transform.localPosition = position;
            TextMesh label = labelObject.GetComponent<TextMesh>();
            Font japaneseFont = AssetDatabase.LoadAssetAtPath<Font>(
                RootFolder + "/Fonts/NotoSansJP-Regular.ttf");
            if (japaneseFont != null)
            {
                label.font = japaneseFont;
                label.GetComponent<MeshRenderer>().sharedMaterial = japaneseFont.material;
            }
            label.text = string.IsNullOrWhiteSpace(value) ? "カメラ" : value;
            label.fontSize = 48;
            label.characterSize = 0.032f;
            label.fontStyle = FontStyle.Bold;
            label.anchor = TextAnchor.UpperCenter;
            label.alignment = TextAlignment.Center;
            label.color = TextColor;
        }

        private static void RememberMonitorMaterial(IDictionary<RenderTexture, Material> materials,
            Renderer renderer)
        {
            if (renderer == null || renderer.sharedMaterial == null) return;
            RenderTexture texture = renderer.sharedMaterial.mainTexture as RenderTexture;
            if (texture != null && !materials.ContainsKey(texture)) materials.Add(texture, renderer.sharedMaterial);
        }

        private static Material GetOrCreateMonitorMaterial(RenderTexture texture)
        {
            string texturePath = AssetDatabase.GetAssetPath(texture);
            string guid = string.IsNullOrEmpty(texturePath) ? "runtime" : AssetDatabase.AssetPathToGUID(texturePath);
            if (guid.Length > 8) guid = guid.Substring(0, 8);
            string materialPath = GeneratedFolder + "/SGMonitor_" + MakeSafeAssetName(texture.name) +
                                  "_" + guid + ".mat";
            Material material = AssetDatabase.LoadAssetAtPath<Material>(materialPath);
            if (material == null)
            {
                Shader shader = Shader.Find("Unlit/Texture");
                if (shader == null) shader = Shader.Find("Standard");
                material = new Material(shader) { name = Path.GetFileNameWithoutExtension(materialPath) };
                AssetDatabase.CreateAsset(material, materialPath);
            }
            material.mainTexture = texture;
            EditorUtility.SetDirty(material);
            return material;
        }

        private static Material GetOrCreateFrameMaterial()
        {
            string materialPath = GeneratedFolder + "/SGMonitorFrame.mat";
            Material material = AssetDatabase.LoadAssetAtPath<Material>(materialPath);
            if (material == null)
            {
                Shader shader = Shader.Find("Standard");
                material = new Material(shader) { name = "SGMonitorFrame" };
                AssetDatabase.CreateAsset(material, materialPath);
            }
            material.color = new Color(0.012f, 0.018f, 0.025f, 1f);
            EditorUtility.SetDirty(material);
            return material;
        }

        private static void PositionOperationPanel(SGSurveillanceController controller)
        {
            Transform panel = controller.transform.Find("OperationPanel");
            if (panel == null) return;
            if (controller.monitorWallRoot == null) return;
            const float screenWidth = 2.2f;
            const float horizontalGap = 0.16f;
            int columns = Mathf.Max(1, controller.monitorColumns);
            float wallWidth = columns * screenWidth + (columns - 1) * horizontalGap;
            Transform wall = controller.monitorWallRoot.transform;
            panel.localPosition = wall.localPosition + wall.localRotation *
                                  new Vector3(wallWidth * 0.5f + 0.75f, 0f, -0.04f);
            panel.localRotation = wall.localRotation;
        }

        public static void CreateSurveillanceAssets(string baseName, int width, int height,
            out RenderTexture renderTexture, out Material monitorMaterial)
        {
            EnsureAssetFolders();
            string safeName = MakeSafeAssetName(baseName);
            string renderTexturePath = AssetDatabase.GenerateUniqueAssetPath(
                GeneratedFolder + "/" + safeName + ".renderTexture");
            renderTexture = new RenderTexture(Mathf.Max(64, width), Mathf.Max(64, height), 16,
                RenderTextureFormat.ARGB32)
            {
                name = safeName,
                antiAliasing = 1,
                useMipMap = false,
                autoGenerateMips = false
            };
            AssetDatabase.CreateAsset(renderTexture, renderTexturePath);

            Shader shader = Shader.Find("Unlit/Texture");
            if (shader == null) shader = Shader.Find("Standard");
            monitorMaterial = new Material(shader)
            {
                name = safeName + "_Material",
                mainTexture = renderTexture
            };
            string materialPath = AssetDatabase.GenerateUniqueAssetPath(
                GeneratedFolder + "/" + safeName + "_Material.mat");
            AssetDatabase.CreateAsset(monitorMaterial, materialPath);
            AssetDatabase.SaveAssets();
        }

        public static void EnsureAssetFolders()
        {
            if (!IsVpmPackage) EnsureFolder(RootFolder);
            EnsureFolder(GeneratedFolder);
            if (!IsVpmPackage)
            {
                EnsureFolder(PrefabFolder);
                EnsureFolder(SceneFolder);
            }
        }

        private static string[] BuildCameraLabels(Camera[] cameras, string[] requestedLabels)
        {
            string[] result = new string[cameras.Length];
            for (int i = 0; i < cameras.Length; i++)
            {
                if (requestedLabels != null && i < requestedLabels.Length &&
                    !string.IsNullOrWhiteSpace(requestedLabels[i]))
                {
                    result[i] = requestedLabels[i].Trim();
                }
                else
                {
                    result[i] = cameras[i] == null ? "カメラ " + (i + 1) : cameras[i].name;
                }
            }
            return result;
        }

        private static void CreateOperationPanel(Transform parent, SGSurveillanceController controller,
            int panelFontSize)
        {
            panelFontSize = Mathf.Clamp(panelFontSize, 28, 52);
            int titleFontSize = Mathf.Clamp(panelFontSize + 8, 40, 58);
            int statusFontSize = Mathf.Clamp(panelFontSize, 34, 52);
            int sectionFontSize = Mathf.Clamp(panelFontSize - 2, 32, 48);
            int pageFontSize = Mathf.Clamp(panelFontSize - 4, 30, 44);
            GameObject panelObject = new GameObject("OperationPanel", typeof(RectTransform), typeof(Canvas),
                typeof(CanvasScaler), typeof(GraphicRaycaster), typeof(VRCUiShape));
            panelObject.transform.SetParent(parent, false);
            RectTransform panelRect = panelObject.GetComponent<RectTransform>();
            panelRect.sizeDelta = new Vector2(920f, 1040f);
            panelRect.localScale = Vector3.one * 0.001f;
            panelRect.localPosition = new Vector3(1.55f, 1.45f, -0.015f);
            panelRect.localRotation = Quaternion.identity;

            Canvas canvas = panelObject.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.WorldSpace;
            canvas.sortingOrder = 20;
            CanvasScaler scaler = panelObject.GetComponent<CanvasScaler>();
            scaler.dynamicPixelsPerUnit = 100f;

            Image background = panelObject.AddComponent<Image>();
            background.color = PanelColor;

            CreateText(panelRect, "Title", "SGimmicks 監視システム", new Vector2(0f, -22f),
                new Vector2(850f, 62f), titleFontSize, TextAnchor.MiddleCenter, AccentColor);

            Button overviewTab = CreateButton(panelRect, "OverviewTab", "一覧表示", new Vector2(-290f, -92f),
                new Vector2(260f, 54f), controller, "ShowOverviewTab", sectionFontSize);
            Button focusTab = CreateButton(panelRect, "FocusTab", "拡大表示", new Vector2(0f, -92f),
                new Vector2(260f, 54f), controller, "ShowFocusTab", sectionFontSize);
            Button voiceTab = CreateButton(panelRect, "VoiceTab", "音声選択", new Vector2(290f, -92f),
                new Vector2(260f, 54f), controller, "ShowVoiceTab", sectionFontSize);
            controller.overviewTabIndicator = CreateSelectionIndicator(overviewTab.transform, "Active", 220f);
            controller.focusTabIndicator = CreateSelectionIndicator(focusTab.transform, "Active", 220f);
            controller.voiceTabIndicator = CreateSelectionIndicator(voiceTab.transform, "Active", 220f);

            RectTransform overviewContent = CreateContentRoot(panelRect, "OverviewTabContent");
            RectTransform focusContent = CreateContentRoot(panelRect, "FocusTabContent");
            RectTransform voiceContent = CreateContentRoot(panelRect, "VoiceTabContent");
            controller.overviewTabContent = overviewContent.gameObject;
            controller.focusTabContent = focusContent.gameObject;
            controller.voiceTabContent = voiceContent.gameObject;

            controller.overviewSummaryText = CreateText(overviewContent, "OverviewSummary",
                "全カメラを表示中", new Vector2(0f, -205f), new Vector2(820f, 60f),
                statusFontSize, TextAnchor.MiddleCenter, AccentColor);
            CreateText(overviewContent, "OverviewHelp",
                "すべての監視カメラをモニター壁へ同時表示しています。\n大きく確認するときは「拡大表示」タブを選んでください。",
                new Vector2(0f, -300f), new Vector2(820f, 150f), sectionFontSize,
                TextAnchor.MiddleCenter, TextColor);

            controller.cameraStatusText = CreateText(focusContent, "CameraStatus", "カメラ",
                new Vector2(0f, -165f), new Vector2(850f, 50f), statusFontSize,
                TextAnchor.MiddleCenter, TextColor);
            CreateText(focusContent, "CameraNumberTitle", "拡大するカメラ番号", new Vector2(0f, -220f),
                new Vector2(850f, 48f), sectionFontSize, TextAnchor.MiddleCenter, AccentColor);

            const int cameraButtonCount = 8;
            controller.camerasPerPage = cameraButtonCount;
            controller.focusCameraButtonTexts = new Text[cameraButtonCount];
            controller.focusCameraSelectionIndicators = new GameObject[cameraButtonCount];
            for (int i = 0; i < cameraButtonCount; i++)
            {
                int row = i / 4;
                int column = i % 4;
                float x = -315f + column * 210f;
                float y = -278f - row * 62f;
                Button cameraButton = CreateButton(focusContent, "CameraSlot_" + i, "カメラ " + (i + 1),
                    new Vector2(x, y), new Vector2(190f, 50f), controller,
                    "SelectCameraSlot" + i, sectionFontSize);
                controller.focusCameraButtonTexts[i] = cameraButton.GetComponentInChildren<Text>();
                controller.focusCameraSelectionIndicators[i] =
                    CreateSelectionIndicator(cameraButton.transform, "Selected", 150f);
            }

            controller.focusCameraPageText = CreateText(focusContent, "CameraPage", "1 / 1",
                new Vector2(0f, -408f), new Vector2(170f, 45f), pageFontSize,
                TextAnchor.MiddleCenter, TextColor);
            CreateButton(focusContent, "PreviousCameraPage", "＜ 番号ページ", new Vector2(-270f, -408f),
                new Vector2(250f, 48f), controller, "PreviousCameraPage", sectionFontSize);
            CreateButton(focusContent, "NextCameraPage", "番号ページ ＞", new Vector2(270f, -408f),
                new Vector2(250f, 48f), controller, "NextCameraPage", sectionFontSize);

            CreateButton(focusContent, "PreviousCamera", "＜ 前のカメラ", new Vector2(-220f, -474f),
                new Vector2(390f, 54f), controller, "PreviousCamera", panelFontSize);
            CreateButton(focusContent, "NextCamera", "次のカメラ ＞", new Vector2(220f, -474f),
                new Vector2(390f, 54f), controller, "NextCamera", panelFontSize);
            CreateButton(focusContent, "PanLeft", "パン 左", new Vector2(-285f, -540f),
                new Vector2(250f, 54f), controller, "PanLeft", panelFontSize);
            CreateButton(focusContent, "PanRight", "パン 右", new Vector2(285f, -540f),
                new Vector2(250f, 54f), controller, "PanRight", panelFontSize);
            CreateButton(focusContent, "TiltUp", "上を見る", new Vector2(-285f, -604f),
                new Vector2(250f, 54f), controller, "TiltUp", panelFontSize);
            CreateButton(focusContent, "ResetView", "視点リセット", new Vector2(0f, -604f),
                new Vector2(250f, 54f), controller, "ResetCameraView", panelFontSize);
            CreateButton(focusContent, "TiltDown", "下を見る", new Vector2(285f, -604f),
                new Vector2(250f, 54f), controller, "TiltDown", panelFontSize);
            CreateButton(focusContent, "ZoomIn", "拡大", new Vector2(-145f, -668f),
                new Vector2(250f, 54f), controller, "ZoomIn", panelFontSize);
            CreateButton(focusContent, "ZoomOut", "縮小", new Vector2(145f, -668f),
                new Vector2(250f, 54f), controller, "ZoomOut", panelFontSize);
            CreateText(focusContent, "LocalOnlyHelp",
                "大型画面とカメラ操作は、この操作をしたユーザーにだけ反映されます。",
                new Vector2(0f, -748f), new Vector2(820f, 80f), sectionFontSize,
                TextAnchor.MiddleCenter, AccentColor);

            CreateText(voiceContent, "VoiceTitle", "遠隔音声（複数選択可）", new Vector2(0f, -175f),
                new Vector2(850f, 50f), sectionFontSize, TextAnchor.MiddleCenter, AccentColor);
            const int rowCount = 8;
            controller.playersPerPage = rowCount;
            controller.playerRowTexts = new Text[rowCount];
            controller.playerSelectionIndicators = new GameObject[rowCount];
            for (int i = 0; i < rowCount; i++)
            {
                float y = -235f - i * 63f;
                Button rowButton = CreateButton(voiceContent, "PlayerRow_" + i, "---", new Vector2(0f, y),
                    new Vector2(820f, 54f), controller, "TogglePlayerSlot" + i, panelFontSize);
                controller.playerRowTexts[i] = rowButton.GetComponentInChildren<Text>();
                controller.playerSelectionIndicators[i] =
                    CreateSelectionIndicator(rowButton.transform, "Selected", 12f, true);
            }

            controller.playerPageText = CreateText(voiceContent, "Page", "1 / 1", new Vector2(0f, -770f),
                new Vector2(180f, 45f), pageFontSize, TextAnchor.MiddleCenter, TextColor);
            CreateButton(voiceContent, "PreviousPage", "＜ 前ページ", new Vector2(-290f, -770f),
                new Vector2(230f, 50f), controller, "PreviousPlayerPage", panelFontSize);
            CreateButton(voiceContent, "NextPage", "次ページ ＞", new Vector2(290f, -770f),
                new Vector2(230f, 50f), controller, "NextPlayerPage", panelFontSize);
            CreateButton(voiceContent, "RefreshPlayers", "一覧更新", new Vector2(-210f, -840f),
                new Vector2(350f, 48f), controller, "RefreshPlayers", panelFontSize);
            CreateButton(voiceContent, "StopVoice", "音声選択を全解除", new Vector2(210f, -840f),
                new Vector2(350f, 48f), controller, "StopAllVoiceMonitoring", panelFontSize);

            overviewContent.gameObject.SetActive(true);
            focusContent.gameObject.SetActive(false);
            voiceContent.gameObject.SetActive(false);
            controller.overviewTabIndicator.SetActive(true);
            controller.focusTabIndicator.SetActive(false);
            controller.voiceTabIndicator.SetActive(false);
        }

        private static RectTransform CreateContentRoot(RectTransform parent, string name)
        {
            GameObject contentObject = new GameObject(name, typeof(RectTransform));
            contentObject.transform.SetParent(parent, false);
            RectTransform rect = contentObject.GetComponent<RectTransform>();
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
            return rect;
        }

        private static GameObject CreateSelectionIndicator(Transform parent, string name, float width,
            bool vertical = false)
        {
            GameObject indicator = new GameObject(name, typeof(RectTransform), typeof(Image));
            indicator.transform.SetParent(parent, false);
            RectTransform rect = indicator.GetComponent<RectTransform>();
            if (vertical)
            {
                rect.anchorMin = new Vector2(0f, 0.5f);
                rect.anchorMax = new Vector2(0f, 0.5f);
                rect.pivot = new Vector2(0f, 0.5f);
                rect.anchoredPosition = new Vector2(12f, 0f);
                rect.sizeDelta = new Vector2(width, 34f);
            }
            else
            {
                rect.anchorMin = new Vector2(0.5f, 0f);
                rect.anchorMax = new Vector2(0.5f, 0f);
                rect.pivot = new Vector2(0.5f, 0f);
                rect.anchoredPosition = new Vector2(0f, 4f);
                rect.sizeDelta = new Vector2(width, 5f);
            }
            indicator.GetComponent<Image>().color = AccentColor;
            indicator.GetComponent<Image>().raycastTarget = false;
            indicator.SetActive(false);
            return indicator;
        }

        private static TMP_Text CreateTmpText(RectTransform parent, string name, string value,
            Vector2 position, Vector2 size, float fontSize, TMP_FontAsset font,
            TextAlignmentOptions alignment)
        {
            GameObject textObject = new GameObject(name, typeof(RectTransform), typeof(TextMeshProUGUI));
            textObject.transform.SetParent(parent, false);
            RectTransform rect = textObject.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(0.5f, 1f);
            rect.anchorMax = new Vector2(0.5f, 1f);
            rect.pivot = new Vector2(0.5f, 1f);
            rect.anchoredPosition = position;
            rect.sizeDelta = size;
            TextMeshProUGUI text = textObject.GetComponent<TextMeshProUGUI>();
            text.font = font;
            text.text = value;
            text.fontSize = fontSize;
            text.fontStyle = FontStyles.Bold;
            text.alignment = alignment;
            text.color = TextColor;
            text.enableWordWrapping = true;
            text.richText = false;
            text.raycastTarget = false;
            return text;
        }

        private static TMP_InputField CreateTmpInputField(RectTransform parent, TMP_FontAsset font)
        {
            GameObject fieldObject = new GameObject("InputField", typeof(RectTransform), typeof(Image),
                typeof(TMP_InputField));
            fieldObject.transform.SetParent(parent, false);
            RectTransform fieldRect = fieldObject.GetComponent<RectTransform>();
            fieldRect.anchorMin = new Vector2(0.5f, 1f);
            fieldRect.anchorMax = new Vector2(0.5f, 1f);
            fieldRect.pivot = new Vector2(0.5f, 1f);
            fieldRect.anchoredPosition = new Vector2(0f, -120f);
            fieldRect.sizeDelta = new Vector2(850f, 220f);
            fieldObject.GetComponent<Image>().color = new Color(0.015f, 0.025f, 0.04f, 1f);

            GameObject viewportObject = new GameObject("Text Area", typeof(RectTransform), typeof(RectMask2D));
            viewportObject.transform.SetParent(fieldObject.transform, false);
            RectTransform viewport = viewportObject.GetComponent<RectTransform>();
            viewport.anchorMin = Vector2.zero;
            viewport.anchorMax = Vector2.one;
            viewport.offsetMin = new Vector2(22f, 16f);
            viewport.offsetMax = new Vector2(-22f, -16f);

            TMP_Text inputText = CreateTmpText(viewport, "Text", "", Vector2.zero,
                Vector2.zero, 38f, font, TextAlignmentOptions.TopLeft);
            RectTransform inputRect = inputText.rectTransform;
            inputRect.anchorMin = Vector2.zero;
            inputRect.anchorMax = Vector2.one;
            inputRect.pivot = new Vector2(0.5f, 0.5f);
            inputRect.offsetMin = Vector2.zero;
            inputRect.offsetMax = Vector2.zero;
            inputText.raycastTarget = true;

            TMP_Text placeholder = CreateTmpText(viewport, "Placeholder", "ここに日本語を入力（100文字まで）",
                Vector2.zero, Vector2.zero, 34f, font, TextAlignmentOptions.TopLeft);
            RectTransform placeholderRect = placeholder.rectTransform;
            placeholderRect.anchorMin = Vector2.zero;
            placeholderRect.anchorMax = Vector2.one;
            placeholderRect.pivot = new Vector2(0.5f, 0.5f);
            placeholderRect.offsetMin = Vector2.zero;
            placeholderRect.offsetMax = Vector2.zero;
            placeholder.color = new Color(0.65f, 0.7f, 0.75f, 0.75f);

            TMP_InputField field = fieldObject.GetComponent<TMP_InputField>();
            field.textViewport = viewport;
            field.textComponent = inputText;
            field.placeholder = placeholder;
            field.characterLimit = 100;
            field.lineType = TMP_InputField.LineType.MultiLineNewline;
            field.richText = false;
            field.customCaretColor = true;
            field.caretColor = AccentColor;
            field.selectionColor = new Color(0.2f, 0.7f, 0.8f, 0.45f);
            return field;
        }

        private static Button CreateTmpButton(RectTransform parent, string name, string label,
            Vector2 position, Vector2 size, UdonSharpBehaviour receiver, string eventName,
            TMP_FontAsset font)
        {
            GameObject buttonObject = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Button));
            buttonObject.transform.SetParent(parent, false);
            RectTransform rect = buttonObject.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(0.5f, 1f);
            rect.anchorMax = new Vector2(0.5f, 1f);
            rect.pivot = new Vector2(0.5f, 1f);
            rect.anchoredPosition = position;
            rect.sizeDelta = size;
            Image image = buttonObject.GetComponent<Image>();
            image.color = ButtonColor;
            Button button = buttonObject.GetComponent<Button>();
            TMP_Text labelText = CreateTmpText(rect, "Label", label, Vector2.zero, size, 31f, font,
                TextAlignmentOptions.Center);
            RectTransform textRect = labelText.rectTransform;
            textRect.anchorMin = Vector2.zero;
            textRect.anchorMax = Vector2.one;
            textRect.pivot = new Vector2(0.5f, 0.5f);
            textRect.anchoredPosition = Vector2.zero;
            textRect.sizeDelta = Vector2.zero;
            WireUdonEvent(button, receiver, eventName);
            return button;
        }

        private static Text CreateText(RectTransform parent, string name, string value, Vector2 position,
            Vector2 size, int fontSize, TextAnchor alignment, Color color)
        {
            GameObject textObject = new GameObject(name, typeof(RectTransform), typeof(Text));
            textObject.transform.SetParent(parent, false);
            RectTransform rect = textObject.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(0.5f, 1f);
            rect.anchorMax = new Vector2(0.5f, 1f);
            rect.pivot = new Vector2(0.5f, 1f);
            rect.anchoredPosition = position;
            rect.sizeDelta = size;
            Text text = textObject.GetComponent<Text>();
            Font japaneseFont = AssetDatabase.LoadAssetAtPath<Font>(
                RootFolder + "/Fonts/NotoSansJP-Regular.ttf");
            text.font = japaneseFont != null
                ? japaneseFont
                : Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            text.text = value;
            text.fontSize = fontSize;
            text.fontStyle = FontStyle.Bold;
            text.resizeTextForBestFit = true;
            text.resizeTextMinSize = Mathf.Min(30, fontSize);
            text.resizeTextMaxSize = fontSize;
            text.alignment = alignment;
            text.color = color;
            text.raycastTarget = false;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Truncate;
            Outline outline = textObject.AddComponent<Outline>();
            outline.effectColor = new Color(0f, 0f, 0f, 0.9f);
            outline.effectDistance = new Vector2(1.5f, -1.5f);
            return text;
        }

        private static Button CreateButton(RectTransform parent, string name, string label, Vector2 position,
            Vector2 size, UdonSharpBehaviour receiver, string eventName, int fontSize)
        {
            GameObject buttonObject = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Button));
            buttonObject.transform.SetParent(parent, false);
            RectTransform rect = buttonObject.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(0.5f, 1f);
            rect.anchorMax = new Vector2(0.5f, 1f);
            rect.pivot = new Vector2(0.5f, 1f);
            rect.anchoredPosition = position;
            rect.sizeDelta = size;

            Image image = buttonObject.GetComponent<Image>();
            image.color = ButtonColor;
            Button button = buttonObject.GetComponent<Button>();
            ColorBlock colors = button.colors;
            colors.normalColor = ButtonColor;
            colors.highlightedColor = new Color(0.18f, 0.38f, 0.48f, 1f);
            colors.pressedColor = AccentColor;
            colors.selectedColor = ButtonColor;
            button.colors = colors;

            Text text = CreateText(rect, "Label", label, Vector2.zero, size, fontSize, TextAnchor.MiddleCenter, TextColor);
            RectTransform textRect = text.rectTransform;
            textRect.anchorMin = Vector2.zero;
            textRect.anchorMax = Vector2.one;
            textRect.pivot = new Vector2(0.5f, 0.5f);
            textRect.anchoredPosition = Vector2.zero;
            textRect.sizeDelta = Vector2.zero;

            WireUdonEvent(button, receiver, eventName);
            return button;
        }

        private static void WireUdonEvent(Button button, UdonSharpBehaviour receiver, string eventName)
        {
            if (receiver == null)
                throw new InvalidOperationException("UdonSharpのイベント受信先が未設定です。");

            UdonBehaviour backing = UdonSharpEditorUtility.GetBackingUdonBehaviour(receiver);
            if (backing == null)
                throw new InvalidOperationException(
                    "Backing UdonBehaviourを作成できませんでした: " + receiver.GetType().Name);

            // Create the persistent call in the exact form used by RTab's own UdonSharp UI
            // prefabs. UnityEventTools writes a concrete assembly type here, while UdonSharp's
            // serialized SendCustomEvent calls intentionally leave it blank.
            SerializedObject serializedButton = new SerializedObject(button);
            serializedButton.Update();
            SerializedProperty calls = serializedButton.FindProperty("m_OnClick.m_PersistentCalls.m_Calls");
            if (calls == null)
                throw new InvalidOperationException("ButtonのOnClickイベントを作成できませんでした。");

            int callIndex = calls.arraySize;
            calls.arraySize = callIndex + 1;
            SerializedProperty call = calls.GetArrayElementAtIndex(callIndex);
            call.FindPropertyRelative("m_Target").objectReferenceValue = backing;
            call.FindPropertyRelative("m_TargetAssemblyTypeName").stringValue = string.Empty;
            call.FindPropertyRelative("m_MethodName").stringValue = "SendCustomEvent";
            call.FindPropertyRelative("m_Mode").enumValueIndex = 5;
            SerializedProperty arguments = call.FindPropertyRelative("m_Arguments");
            arguments.FindPropertyRelative("m_ObjectArgument").objectReferenceValue = null;
            arguments.FindPropertyRelative("m_ObjectArgumentAssemblyTypeName").stringValue =
                "UnityEngine.Object, UnityEngine";
            arguments.FindPropertyRelative("m_IntArgument").intValue = 0;
            arguments.FindPropertyRelative("m_FloatArgument").floatValue = 0f;
            arguments.FindPropertyRelative("m_StringArgument").stringValue = eventName;
            arguments.FindPropertyRelative("m_BoolArgument").boolValue = false;
            call.FindPropertyRelative("m_CallState").enumValueIndex = 2;
            serializedButton.ApplyModifiedPropertiesWithoutUndo();
            EditorUtility.SetDirty(button);
        }

        private static T AddUdonComponent<T>(GameObject target) where T : UdonSharpBehaviour
        {
            T component = target.AddUdonSharpComponent<T>();
            if (component == null) throw new InvalidOperationException("Could not add " + typeof(T).Name);
            return component;
        }

        private static void EnsureFolder(string assetPath)
        {
            if (AssetDatabase.IsValidFolder(assetPath)) return;
            string parent = Path.GetDirectoryName(assetPath)?.Replace('\\', '/');
            string name = Path.GetFileName(assetPath);
            if (string.IsNullOrEmpty(parent) || string.IsNullOrEmpty(name)) return;
            EnsureFolder(parent);
            AssetDatabase.CreateFolder(parent, name);
        }

        private static string MakeSafeAssetName(string value)
        {
            string result = string.IsNullOrWhiteSpace(value) ? "SGMonitor" : value.Trim();
            foreach (char invalid in Path.GetInvalidFileNameChars()) result = result.Replace(invalid, '_');
            return result;
        }
    }
}
