using System;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace SGimmicks.Editor
{
    public sealed class SGImageExtrusionWindow : EditorWindow
    {
        private const string OutputRoot = "Assets/SGimmicksGenerated/ImageExtrusions";

        [SerializeField] private Texture2D _image;
        [SerializeField] private string _objectName = "画像オブジェクト";
        [SerializeField] private float _widthMeters = 1.5f;
        [SerializeField] private float _thicknessMeters = 0.08f;
        [SerializeField] private float _alphaThreshold = 0.5f;
        [SerializeField] private int _outlineResolution = 512;
        [SerializeField] private float _outlineTolerance = 0.25f;
        [SerializeField] private Color _sideColor = new Color(0.16f, 0.16f, 0.18f, 1f);
        [SerializeField] private bool _unlitFront = true;
        [SerializeField] private bool _collider;

        [MenuItem("SGimmicks/透過画像を3Dオブジェクト化", priority = 12)]
        public static void Open()
        {
            SGImageExtrusionWindow window = GetWindow<SGImageExtrusionWindow>();
            window.titleContent = new GUIContent("透過画像の立体化");
            window.minSize = new Vector2(460f, 410f);
            window.Show();
        }

        private void OnGUI()
        {
            EditorGUILayout.LabelField("透過PNGから厚みのある切り抜きを作成", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "キャラクター展示パネルやロゴ向けです。PNGの透明部分は除き、画像を前面・背面へ貼り、輪郭に側面を付けます。生成したPrefabはワールドへ配置できます。",
                MessageType.Info);

            _image = (Texture2D)EditorGUILayout.ObjectField("透過PNG", _image, typeof(Texture2D), false);
            _objectName = EditorGUILayout.TextField("オブジェクト名", _objectName);
            _widthMeters = EditorGUILayout.Slider("切り抜きの横幅（m）", _widthMeters, 0.05f, 10f);
            _thicknessMeters = EditorGUILayout.Slider("厚み（m）", _thicknessMeters, 0.005f, 1f);
            _alphaThreshold = EditorGUILayout.Slider(
                new GUIContent("輪郭の透明度しきい値", "高いほど半透明の縁を除外します。"),
                _alphaThreshold, 0.05f, 0.95f);
            _outlineResolution = EditorGUILayout.IntSlider(
                new GUIContent("輪郭の細かさ", "大きいほど輪郭が滑らかになりますが、ポリゴン数が増えます。"),
                _outlineResolution, 64, 1024);
            _outlineTolerance = EditorGUILayout.Slider(
                new GUIContent("輪郭の整え具合", "小さな凹凸を整理する量です。初期値0.25、0で画像の輪郭をそのまま使用します。"),
                _outlineTolerance, 0f, 2f);
            _sideColor = EditorGUILayout.ColorField("側面の色", _sideColor);
            _unlitFront = EditorGUILayout.Toggle("画像の明るさを固定", _unlitFront);
            _collider = EditorGUILayout.Toggle("Mesh Colliderを追加", _collider);

            EditorGUILayout.Space(10f);
            EditorGUI.BeginDisabledGroup(_image == null);
            if (GUILayout.Button("メッシュ・Prefabを生成してシーンに配置", GUILayout.Height(42f)))
            {
                try
                {
                    GameObject created = Create(_image, _objectName, _widthMeters,
                        _thicknessMeters, _alphaThreshold, _outlineResolution,
                        _sideColor, _unlitFront, _collider, _outlineTolerance);
                    Selection.activeGameObject = created;
                    EditorGUIUtility.PingObject(created);
                    ShowNotification(new GUIContent("立体オブジェクトを生成しました"));
                }
                catch (Exception exception)
                {
                    Debug.LogException(exception);
                    EditorUtility.DisplayDialog("SGimmicks", exception.Message, "OK");
                }
            }
            EditorGUI.EndDisabledGroup();
            EditorGUILayout.HelpBox(
                "出力先: Assets/SGimmicksGenerated/ImageExtrusions。裏側から見る画像は鏡像になります。細い線が欠ける場合は輪郭の細かさを上げるか、しきい値を下げてください。",
                MessageType.None);
        }

        internal static GameObject Create(Texture2D source, string requestedName,
            float widthMeters, float thicknessMeters, float alphaThreshold,
            int maxResolution, Color sideColor, bool unlitFront, bool addCollider,
            float outlineTolerance = 0.25f)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            string path = AssetDatabase.GetAssetPath(source);
            string projectRoot = Directory.GetParent(Application.dataPath)?.FullName;
            string absolutePath = string.IsNullOrEmpty(projectRoot) || string.IsNullOrEmpty(path)
                ? null : Path.Combine(projectRoot, path);
            if (string.IsNullOrEmpty(path) || !path.StartsWith("Assets/", StringComparison.Ordinal) ||
                !path.EndsWith(".png", StringComparison.OrdinalIgnoreCase) ||
                string.IsNullOrEmpty(absolutePath) || !File.Exists(absolutePath))
                throw new InvalidOperationException("Assets内の透過PNGを指定してください。");

            widthMeters = Mathf.Clamp(widthMeters, 0.05f, 10f);
            thicknessMeters = Mathf.Clamp(thicknessMeters, 0.005f, 1f);
            alphaThreshold = Mathf.Clamp(alphaThreshold, 0.05f, 0.95f);
            maxResolution = Mathf.Clamp(maxResolution, 64, 1024);

            Texture2D decoded = new Texture2D(2, 2, TextureFormat.RGBA32, false);
            Mesh mesh;
            try
            {
                if (!ImageConversion.LoadImage(decoded, File.ReadAllBytes(absolutePath), false))
                    throw new InvalidOperationException("PNGを読み込めませんでした。");
                mesh = BuildMesh(decoded.GetPixels32(), decoded.width, decoded.height,
                    widthMeters, thicknessMeters, alphaThreshold, maxResolution, outlineTolerance);
            }
            finally
            {
                DestroyImmediate(decoded);
            }

            Shader frontShader = Shader.Find(unlitFront ? "Unlit/Texture" : "Standard");
            Shader sideShader = Shader.Find("Standard");
            if (frontShader == null || sideShader == null)
                throw new InvalidOperationException("必要なBuilt-inシェーダーが見つかりません。");

            string safeName = MakeSafeName(requestedName, source.name);
            EnsureFolder(OutputRoot);
            string uniqueFolder = AssetDatabase.GenerateUniqueAssetPath(OutputRoot + "/" + safeName);
            string folderName = Path.GetFileName(uniqueFolder);
            if (string.IsNullOrEmpty(AssetDatabase.CreateFolder(OutputRoot, folderName)))
                throw new InvalidOperationException("出力フォルダーを作成できませんでした。");

            string meshPath = uniqueFolder + "/" + safeName + ".asset";
            string frontPath = uniqueFolder + "/" + safeName + "_画像.mat";
            string sidePath = uniqueFolder + "/" + safeName + "_側面.mat";
            string prefabPath = uniqueFolder + "/" + safeName + ".prefab";
            mesh.name = safeName;
            AssetDatabase.CreateAsset(mesh, meshPath);

            Material front = new Material(frontShader) { name = safeName + "_画像", mainTexture = source };
            if (front.HasProperty("_Color")) front.color = Color.white;
            AssetDatabase.CreateAsset(front, frontPath);

            Material side = new Material(sideShader) { name = safeName + "_側面", color = sideColor };
            AssetDatabase.CreateAsset(side, sidePath);

            GameObject temporary = new GameObject(safeName);
            try
            {
                temporary.AddComponent<MeshFilter>().sharedMesh = mesh;
                temporary.AddComponent<MeshRenderer>().sharedMaterials = new[] { front, side };
                if (addCollider) temporary.AddComponent<MeshCollider>().sharedMesh = mesh;
                GameObject prefab = PrefabUtility.SaveAsPrefabAsset(temporary, prefabPath);
                if (prefab == null)
                    throw new InvalidOperationException("Prefabを保存できませんでした。");
            }
            finally
            {
                DestroyImmediate(temporary);
            }

            AssetDatabase.SaveAssets();
            GameObject prefabAsset = AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath);
            GameObject instance = PrefabUtility.InstantiatePrefab(prefabAsset) as GameObject;
            if (instance == null)
                throw new InvalidOperationException("Prefabをシーンへ配置できませんでした。");
            SceneView view = SceneView.lastActiveSceneView;
            if (view != null && view.camera != null)
            {
                Transform cameraTransform = view.camera.transform;
                instance.transform.position = cameraTransform.position + cameraTransform.forward * 3f;
                instance.transform.rotation = Quaternion.LookRotation(-cameraTransform.forward, Vector3.up);
            }
            Undo.RegisterCreatedObjectUndo(instance, "Create 3D Image Cutout");
            EditorSceneManager.MarkSceneDirty(instance.scene);
            return instance;
        }

        internal static Mesh BuildMesh(Color32[] pixels, int imageWidth, int imageHeight,
            float widthMeters, float thicknessMeters, float alphaThreshold, int maxResolution,
            float outlineTolerance = 0.25f)
        {
            return SGImageOutlineMesh.Build(pixels, imageWidth, imageHeight, widthMeters,
                thicknessMeters, alphaThreshold, maxResolution, outlineTolerance);
        }

        private static string MakeSafeName(string requested, string fallback)
        {
            string value = string.IsNullOrWhiteSpace(requested) ? fallback : requested.Trim();
            foreach (char invalid in Path.GetInvalidFileNameChars()) value = value.Replace(invalid, '_');
            return string.IsNullOrWhiteSpace(value) ? "画像オブジェクト" : value;
        }

        private static void EnsureFolder(string path)
        {
            if (AssetDatabase.IsValidFolder(path)) return;
            string parent = Path.GetDirectoryName(path)?.Replace('\\', '/');
            if (string.IsNullOrEmpty(parent)) throw new InvalidOperationException("出力先が無効です。");
            EnsureFolder(parent);
            AssetDatabase.CreateFolder(parent, Path.GetFileName(path));
        }
    }
}
