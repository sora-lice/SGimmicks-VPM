using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace SGimmicks.Editor
{
    // Marching squares produces interpolated contours instead of voxel stair steps.
    // A horizontal sweep tessellates all rings together using the even-odd rule,
    // preserving holes and detached pieces without a separate polygon dependency.
    internal static class SGImageOutlineMesh
    {
        private const float Epsilon = 0.00001f;

        internal static Mesh Build(Color32[] pixels, int imageWidth, int imageHeight,
            float widthMeters, float thicknessMeters, float threshold, int resolution, float tolerance)
        {
            if (pixels == null || imageWidth < 1 || imageHeight < 1 ||
                pixels.Length != imageWidth * imageHeight)
                throw new ArgumentException("画像のピクセルデータが正しくありません。");
            resolution = Mathf.Clamp(resolution, 64, 1024);
            threshold = Mathf.Clamp(threshold, 0.05f, 0.95f) + 0.000001f;
            float scale = resolution / (float)Mathf.Max(imageWidth, imageHeight);
            int width = Mathf.Max(1, Mathf.RoundToInt(imageWidth * scale));
            int height = Mathf.Max(1, Mathf.RoundToInt(imageHeight * scale));
            float[,] alpha = new float[width + 2, height + 2];
            for (int y = 0; y < height; y++)
                for (int x = 0; x < width; x++)
                {
                    float sx = Mathf.Clamp((x + 0.5f) * imageWidth / width - 0.5f, 0f, imageWidth - 1f);
                    float sy = Mathf.Clamp((y + 0.5f) * imageHeight / height - 0.5f, 0f, imageHeight - 1f);
                    int x0 = Mathf.Clamp(Mathf.FloorToInt(sx), 0, imageWidth - 1);
                    int y0 = Mathf.Clamp(Mathf.FloorToInt(sy), 0, imageHeight - 1);
                    int x1 = Mathf.Min(x0 + 1, imageWidth - 1);
                    int y1 = Mathf.Min(y0 + 1, imageHeight - 1);
                    float bottom = Mathf.Lerp(pixels[y0 * imageWidth + x0].a,
                        pixels[y0 * imageWidth + x1].a, sx - Mathf.Floor(sx));
                    float top = Mathf.Lerp(pixels[y1 * imageWidth + x0].a,
                        pixels[y1 * imageWidth + x1].a, sx - Mathf.Floor(sx));
                    alpha[x + 1, y + 1] = Mathf.Lerp(bottom, top, sy - Mathf.Floor(sy)) / 255f;
                }

            ContourGraph graph = new ContourGraph(alpha, width, height, threshold);
            List<List<Vector2>> raw = graph.Trace();
            if (raw.Count == 0)
                throw new InvalidOperationException("指定したしきい値以上の不透明な部分がありません。");
            List<List<Vector2>> rings = SimplifyContours(raw, Mathf.Clamp(tolerance, 0f, 2f));
            OrientContours(rings);
            return Tessellate(rings, width, height, widthMeters, thicknessMeters);
        }

        private sealed class ContourGraph
        {
            private readonly float[,] _alpha;
            private readonly int _width, _height;
            private readonly float _threshold;
            private readonly Dictionary<long, int> _edgeNodes = new Dictionary<long, int>();
            private readonly List<Vector2> _positions = new List<Vector2>();
            private readonly List<List<int>> _neighbors = new List<List<int>>();

            internal ContourGraph(float[,] alpha, int width, int height, float threshold)
            {
                _alpha = alpha; _width = width; _height = height; _threshold = threshold;
            }

            internal List<List<Vector2>> Trace()
            {
                for (int y = 0; y <= _height; y++)
                    for (int x = 0; x <= _width; x++)
                    {
                        int state = (_alpha[x, y] >= _threshold ? 1 : 0) |
                            (_alpha[x + 1, y] >= _threshold ? 2 : 0) |
                            (_alpha[x + 1, y + 1] >= _threshold ? 4 : 0) |
                            (_alpha[x, y + 1] >= _threshold ? 8 : 0);
                        bool centerSolid = (_alpha[x, y] + _alpha[x + 1, y] +
                            _alpha[x + 1, y + 1] + _alpha[x, y + 1]) * 0.25f >= _threshold;
                        switch (state)
                        {
                            case 1: case 14: Connect(x, y, 3, 0); break;
                            case 2: case 13: Connect(x, y, 0, 1); break;
                            case 3: case 12: Connect(x, y, 3, 1); break;
                            case 4: case 11: Connect(x, y, 1, 2); break;
                            case 5:
                                Connect(x, y, 3, centerSolid ? 2 : 0);
                                Connect(x, y, 1, centerSolid ? 0 : 2);
                                break;
                            case 6: case 9: Connect(x, y, 0, 2); break;
                            case 7: case 8: Connect(x, y, 3, 2); break;
                            case 10:
                                Connect(x, y, 0, centerSolid ? 3 : 1);
                                Connect(x, y, 2, centerSolid ? 1 : 3);
                                break;
                        }
                    }
                bool[] visited = new bool[_positions.Count];
                List<List<Vector2>> rings = new List<List<Vector2>>();
                for (int seed = 0; seed < visited.Length; seed++)
                {
                    if (visited[seed]) continue;
                    List<Vector2> ring = new List<Vector2>();
                    int previous = -1, current = seed;
                    do
                    {
                        if (visited[current] || _neighbors[current].Count != 2)
                            throw new InvalidOperationException("輪郭を閉じられませんでした。透明度しきい値を少し変えてください。");
                        visited[current] = true;
                        Vector2 point = _positions[current];
                        if (ring.Count == 0 || (point - ring[ring.Count - 1]).sqrMagnitude > Epsilon * Epsilon)
                            ring.Add(point);
                        int next = _neighbors[current][0] != previous
                            ? _neighbors[current][0] : _neighbors[current][1];
                        previous = current;
                        current = next;
                    } while (current != seed);
                    if (ring.Count > 1 && (ring[0] - ring[ring.Count - 1]).sqrMagnitude < Epsilon * Epsilon)
                        ring.RemoveAt(ring.Count - 1);
                    if (ring.Count >= 3 && Mathf.Abs(SignedArea(ring)) > Epsilon) rings.Add(ring);
                }
                return rings;
            }

            private void Connect(int x, int y, int edgeA, int edgeB)
            {
                int a = Node(x, y, edgeA), b = Node(x, y, edgeB);
                _neighbors[a].Add(b); _neighbors[b].Add(a);
                if (_positions.Count > 24000)
                    throw new InvalidOperationException("輪郭が複雑すぎます。輪郭の細かさを下げるか、画像の細かなノイズを除いてください。");
            }

            private int Node(int x, int y, int edge)
            {
                int ax = x, ay = y, bx = x, by = y;
                switch (edge)
                {
                    case 0: bx++; break;
                    case 1: ax++; bx++; by++; break;
                    case 2: ay++; by++; bx++; break;
                    case 3: by++; break;
                }
                int aKey = ay * (_width + 2) + ax, bKey = by * (_width + 2) + bx;
                long key = ((long)Mathf.Min(aKey, bKey) << 32) | (uint)Mathf.Max(aKey, bKey);
                if (_edgeNodes.TryGetValue(key, out int existing)) return existing;
                float a = _alpha[ax, ay], b = _alpha[bx, by];
                float t = Mathf.Clamp01((_threshold - a) / (b - a));
                Vector2 position = Vector2.Lerp(new Vector2(ax - 0.5f, ay - 0.5f),
                    new Vector2(bx - 0.5f, by - 0.5f), t);
                position.x = Mathf.Clamp(position.x, 0f, _width);
                position.y = Mathf.Clamp(position.y, 0f, _height);
                int index = _positions.Count;
                _positions.Add(position); _neighbors.Add(new List<int>(2));
                _edgeNodes.Add(key, index);
                return index;
            }
        }

        private static List<List<Vector2>> SimplifyContours(List<List<Vector2>> raw, float tolerance)
        {
            List<List<Vector2>> result = new List<List<Vector2>>();
            foreach (List<Vector2> ring in raw)
            {
                List<Vector2> simplified = SimplifyRing(ring, tolerance);
                result.Add(simplified.Count < 3 || SelfIntersects(simplified)
                    ? new List<Vector2>(ring) : simplified);
            }
            // A simplification must not cross another ring or change its nesting.
            // Restore affected rings instead of losing holes or joining separate parts.
            bool changed;
            do
            {
                changed = false;
                for (int i = 0; i < result.Count; i++)
                    for (int j = i + 1; j < result.Count; j++)
                    {
                        bool invalid = RingsIntersect(result[i], result[j]) ||
                            Contains(raw[i][0], raw[j]) != Contains(raw[i][0], result[j]) ||
                            Contains(raw[j][0], raw[i]) != Contains(raw[j][0], result[i]);
                        if (!invalid) continue;
                        if (result[i] != raw[i]) { result[i] = raw[i]; changed = true; }
                        if (result[j] != raw[j]) { result[j] = raw[j]; changed = true; }
                    }
            } while (changed);
            return result;
        }

        private static List<Vector2> SimplifyRing(List<Vector2> ring, float tolerance)
        {
            if (tolerance <= 0f || ring.Count <= 3) return new List<Vector2>(ring);
            int first = 0;
            for (int i = 1; i < ring.Count; i++)
                if (ring[i].x < ring[first].x ||
                    (ring[i].x == ring[first].x && ring[i].y < ring[first].y)) first = i;
            int opposite = first;
            for (int i = 0; i < ring.Count; i++)
                if ((ring[i] - ring[first]).sqrMagnitude > (ring[opposite] - ring[first]).sqrMagnitude)
                    opposite = i;
            List<Vector2> arcA = Arc(ring, first, opposite), arcB = Arc(ring, opposite, first);
            arcA = SimplifyOpen(arcA, tolerance); arcB = SimplifyOpen(arcB, tolerance);
            arcA.RemoveAt(arcA.Count - 1); arcB.RemoveAt(arcB.Count - 1);
            arcA.AddRange(arcB);
            return arcA;
        }

        private static List<Vector2> Arc(List<Vector2> ring, int start, int end)
        {
            List<Vector2> points = new List<Vector2> { ring[start] };
            while (start != end) { start = (start + 1) % ring.Count; points.Add(ring[start]); }
            return points;
        }

        private static List<Vector2> SimplifyOpen(List<Vector2> points, float tolerance)
        {
            bool[] keep = new bool[points.Count]; keep[0] = keep[keep.Length - 1] = true;
            Stack<Vector2Int> ranges = new Stack<Vector2Int>();
            ranges.Push(new Vector2Int(0, points.Count - 1));
            while (ranges.Count > 0)
            {
                Vector2Int range = ranges.Pop();
                float farthestDistance = tolerance * tolerance;
                int farthest = -1;
                for (int i = range.x + 1; i < range.y; i++)
                {
                    float distance = DistanceToSegmentSquared(points[i], points[range.x], points[range.y]);
                    if (distance > farthestDistance) { farthestDistance = distance; farthest = i; }
                }
                if (farthest < 0) continue;
                keep[farthest] = true;
                ranges.Push(new Vector2Int(range.x, farthest));
                ranges.Push(new Vector2Int(farthest, range.y));
            }
            List<Vector2> result = new List<Vector2>();
            for (int i = 0; i < points.Count; i++) if (keep[i]) result.Add(points[i]);
            return result;
        }

        private static void OrientContours(List<List<Vector2>> rings)
        {
            for (int i = 0; i < rings.Count; i++)
            {
                int depth = 0;
                for (int j = 0; j < rings.Count; j++)
                    if (i != j && Contains(rings[i][0], rings[j])) depth++;
                bool counterClockwise = (depth % 2) == 0;
                if ((SignedArea(rings[i]) > 0f) != counterClockwise) rings[i].Reverse();
            }
        }

        private struct Crossing
        {
            internal float bottom, top, middle;
        }

        private static Mesh Tessellate(List<List<Vector2>> rings, int imageWidth, int imageHeight,
            float widthMeters, float thicknessMeters)
        {
            Vector2 min = new Vector2(float.MaxValue, float.MaxValue), max = -min;
            List<float> ys = new List<float>();
            foreach (List<Vector2> ring in rings)
                foreach (Vector2 point in ring) { min = Vector2.Min(min, point); max = Vector2.Max(max, point); ys.Add(point.y); }
            if (max.x - min.x < Epsilon || max.y - min.y < Epsilon)
                throw new InvalidOperationException("輪郭が小さすぎます。画像かしきい値を確認してください。");
            float units = widthMeters / (max.x - min.x);
            Vector2 center = (min + max) * 0.5f;
            float half = thicknessMeters * 0.5f;
            ys.Sort();
            List<float> levels = new List<float>();
            foreach (float y in ys)
                if (levels.Count == 0 || y - levels[levels.Count - 1] > Epsilon) levels.Add(y);
            if ((long)ys.Count * levels.Count > 30000000L)
                throw new InvalidOperationException("輪郭が複雑すぎます。輪郭の整え具合を上げるか、輪郭の細かさを下げてください。");
            List<Vector3> vertices = new List<Vector3>(), normals = new List<Vector3>();
            List<Vector2> uvs = new List<Vector2>();
            List<int> faces = new List<int>(), sides = new List<int>();

            for (int band = 0; band < levels.Count - 1; band++)
            {
                float bottom = levels[band], top = levels[band + 1], middle = (bottom + top) * 0.5f;
                List<Crossing> crossings = new List<Crossing>();
                foreach (List<Vector2> ring in rings)
                    for (int i = 0; i < ring.Count; i++)
                    {
                        Vector2 a = ring[i], b = ring[(i + 1) % ring.Count];
                        if (middle <= Mathf.Min(a.y, b.y) || middle >= Mathf.Max(a.y, b.y)) continue;
                        float slope = (b.x - a.x) / (b.y - a.y);
                        crossings.Add(new Crossing {
                            bottom = a.x + (bottom - a.y) * slope,
                            top = a.x + (top - a.y) * slope,
                            middle = a.x + (middle - a.y) * slope });
                    }
                crossings.Sort((a, b) => a.middle.CompareTo(b.middle));
                if (crossings.Count % 2 != 0)
                    throw new InvalidOperationException("輪郭を面に変換できませんでした。輪郭の整え具合を下げてください。");
                for (int i = 0; i < crossings.Count; i += 2)
                {
                    Crossing left = crossings[i], right = crossings[i + 1];
                    if (right.middle - left.middle <= Epsilon) continue;
                    Vector2 a = new Vector2(left.bottom, bottom), b = new Vector2(right.bottom, bottom);
                    Vector2 c = new Vector2(right.top, top), d = new Vector2(left.top, top);
                    Quad(vertices, normals, uvs, faces,
                        World(a, center, units, half), World(b, center, units, half),
                        World(c, center, units, half), World(d, center, units, half),
                        UV(a, imageWidth, imageHeight), UV(b, imageWidth, imageHeight),
                        UV(c, imageWidth, imageHeight), UV(d, imageWidth, imageHeight),
                        Vector3.forward, Vector3.forward, Vector3.forward, Vector3.forward);
                    Quad(vertices, normals, uvs, faces,
                        World(b, center, units, -half), World(a, center, units, -half),
                        World(d, center, units, -half), World(c, center, units, -half),
                        UV(b, imageWidth, imageHeight), UV(a, imageWidth, imageHeight),
                        UV(d, imageWidth, imageHeight), UV(c, imageWidth, imageHeight),
                        Vector3.back, Vector3.back, Vector3.back, Vector3.back);
                }
            }

            foreach (List<Vector2> ring in rings)
                for (int i = 0; i < ring.Count; i++)
                {
                    Vector2 a = ring[i], b = ring[(i + 1) % ring.Count];
                    Vector3 normal = Outward(a, b);
                    Vector3 previous = Outward(ring[(i + ring.Count - 1) % ring.Count], a);
                    Vector3 next = Outward(b, ring[(i + 2) % ring.Count]);
                    // Smooth shallow turns while retaining sharp corners in logos.
                    Vector3 normalA = Vector3.Dot(normal, previous) > 0.7071f ? (normal + previous).normalized : normal;
                    Vector3 normalB = Vector3.Dot(normal, next) > 0.7071f ? (normal + next).normalized : normal;
                    Quad(vertices, normals, uvs, sides,
                        World(a, center, units, half), World(a, center, units, -half),
                        World(b, center, units, -half), World(b, center, units, half),
                        Vector2.zero, Vector2.right, Vector2.one, Vector2.up,
                        normalA, normalA, normalB, normalB);
                }
            Mesh mesh = new Mesh { name = "SG Smooth Image Extrusion" };
            if (vertices.Count > 65535) mesh.indexFormat = IndexFormat.UInt32;
            mesh.SetVertices(vertices); mesh.SetNormals(normals); mesh.SetUVs(0, uvs);
            mesh.subMeshCount = 2;
            mesh.SetTriangles(faces, 0, false); mesh.SetTriangles(sides, 1, false);
            mesh.RecalculateBounds();
            return mesh;
        }

        private static Vector3 World(Vector2 p, Vector2 center, float units, float z)
            => new Vector3((p.x - center.x) * units, (p.y - center.y) * units, z);
        private static Vector2 UV(Vector2 p, int width, int height) => new Vector2(p.x / width, p.y / height);
        private static Vector3 Outward(Vector2 a, Vector2 b)
            => new Vector3(b.y - a.y, a.x - b.x, 0f).normalized;

        private static void Quad(List<Vector3> vertices, List<Vector3> normals, List<Vector2> uvs,
            List<int> triangles, Vector3 a, Vector3 b, Vector3 c, Vector3 d,
            Vector2 uvA, Vector2 uvB, Vector2 uvC, Vector2 uvD,
            Vector3 normalA, Vector3 normalB, Vector3 normalC, Vector3 normalD)
        {
            if (vertices.Count >= 200000)
                throw new InvalidOperationException("輪郭が複雑すぎます。輪郭の細かさを下げて再生成してください。");
            int first = vertices.Count;
            vertices.Add(a); vertices.Add(b); vertices.Add(c); vertices.Add(d);
            normals.Add(normalA); normals.Add(normalB); normals.Add(normalC); normals.Add(normalD);
            uvs.Add(uvA); uvs.Add(uvB); uvs.Add(uvC); uvs.Add(uvD);
            if (Vector3.Cross(b - a, c - a).sqrMagnitude > 1e-24f)
            { triangles.Add(first); triangles.Add(first + 1); triangles.Add(first + 2); }
            if (Vector3.Cross(c - a, d - a).sqrMagnitude > 1e-24f)
            { triangles.Add(first); triangles.Add(first + 2); triangles.Add(first + 3); }
        }

        private static float SignedArea(List<Vector2> ring)
        {
            float area = 0f;
            for (int i = 0; i < ring.Count; i++) area += Cross(ring[i], ring[(i + 1) % ring.Count]);
            return area * 0.5f;
        }
        private static float Cross(Vector2 a, Vector2 b) => a.x * b.y - a.y * b.x;
        private static float DistanceToSegmentSquared(Vector2 p, Vector2 a, Vector2 b)
        {
            Vector2 edge = b - a;
            float t = edge.sqrMagnitude < Epsilon * Epsilon ? 0f : Mathf.Clamp01(Vector2.Dot(p - a, edge) / edge.sqrMagnitude);
            return (p - (a + edge * t)).sqrMagnitude;
        }
        private static bool Contains(Vector2 point, List<Vector2> ring)
        {
            bool inside = false;
            for (int i = 0, j = ring.Count - 1; i < ring.Count; j = i++)
            {
                Vector2 a = ring[i], b = ring[j];
                if ((a.y > point.y) != (b.y > point.y) &&
                    point.x < (b.x - a.x) * (point.y - a.y) / (b.y - a.y) + a.x) inside = !inside;
            }
            return inside;
        }
        private static bool SelfIntersects(List<Vector2> ring)
        {
            for (int i = 0; i < ring.Count; i++)
                for (int j = i + 2; j < ring.Count; j++)
                {
                    if (i == 0 && j == ring.Count - 1) continue;
                    if (Intersects(ring[i], ring[(i + 1) % ring.Count], ring[j], ring[(j + 1) % ring.Count])) return true;
                }
            return false;
        }
        private static bool RingsIntersect(List<Vector2> a, List<Vector2> b)
        {
            Vector2 minA = a[0], maxA = a[0], minB = b[0], maxB = b[0];
            foreach (Vector2 point in a) { minA = Vector2.Min(minA, point); maxA = Vector2.Max(maxA, point); }
            foreach (Vector2 point in b) { minB = Vector2.Min(minB, point); maxB = Vector2.Max(maxB, point); }
            if (maxA.x < minB.x || maxB.x < minA.x || maxA.y < minB.y || maxB.y < minA.y) return false;
            for (int i = 0; i < a.Count; i++)
                for (int j = 0; j < b.Count; j++)
                    if (Intersects(a[i], a[(i + 1) % a.Count], b[j], b[(j + 1) % b.Count])) return true;
            return false;
        }
        private static bool Intersects(Vector2 a, Vector2 b, Vector2 c, Vector2 d)
        {
            if (Mathf.Max(a.x, b.x) + Epsilon < Mathf.Min(c.x, d.x) ||
                Mathf.Max(c.x, d.x) + Epsilon < Mathf.Min(a.x, b.x) ||
                Mathf.Max(a.y, b.y) + Epsilon < Mathf.Min(c.y, d.y) ||
                Mathf.Max(c.y, d.y) + Epsilon < Mathf.Min(a.y, b.y)) return false;
            float abC = Cross(b - a, c - a), abD = Cross(b - a, d - a);
            float cdA = Cross(d - c, a - c), cdB = Cross(d - c, b - c);
            return abC * abD <= 0f && cdA * cdB <= 0f;
        }
    }
}
