﻿param([switch]$SelfTest, [string]$PreviewPath)
$ErrorActionPreference = 'Stop'
$corePath = Join-Path $PSScriptRoot '_SGReceptionCore.exe'
$stateRoot = Join-Path $env:LOCALAPPDATA 'SGimmicksReception'
$activeProfile = Join-Path $stateRoot 'active-profile.json'

function New-CoreStartInfo([string]$InputKey, [string]$ConfigFile, [string]$LogFile, [bool]$Follow) {
    if ($InputKey -notmatch '^[a-fA-F0-9]{64}$') { throw 'INVALID_KEY' }
    foreach ($path in @($ConfigFile, $LogFile)) {
        if (-not [IO.Path]::IsPathRooted($path) -or $path.Contains('"')) { throw 'INVALID_PATH' }
    }
    $info = New-Object Diagnostics.ProcessStartInfo
    $info.FileName = $corePath
    $info.Arguments = '--config "' + $ConfigFile + '" --log "' + $LogFile + '" --gui'
    if ($Follow) { $info.Arguments += ' --follow-log' }
    $info.WorkingDirectory = $PSScriptRoot
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardInput = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    $info.EnvironmentVariables['SG_RECEPTION_KEY'] = $InputKey
    $info.EnvironmentVariables['PYTHONIOENCODING'] = 'utf-8'
    return $info
}

if ($SelfTest) {
    $fake = 'a' * 64
    $info = New-CoreStartInfo $fake 'C:\test\profile.json' 'C:\test\output_log_test.txt' $true
    if ($info.Arguments.Contains($fake) -or $info.UseShellExecute -or -not $info.CreateNoWindow) { throw 'Unsafe launch configuration' }
    if (-not $info.Arguments.Contains('--follow-log') -or -not $info.RedirectStandardInput) { throw 'Missing runtime controls' }
    $info.EnvironmentVariables.Remove('SG_RECEPTION_KEY')
    'COMPANION_GUI_SELF_TEST_OK (no network, no real key)'
    exit 0
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
$form = New-Object Windows.Forms.Form
$form.Text = 'SGimmicks 受付連携ツール'
$form.ClientSize = New-Object Drawing.Size(780, 425)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.ShowInTaskbar = $true
$form.TopMost = $true
$form.Font = New-Object Drawing.Font('Meiryo', 10)

function Label([string]$Content, [int]$Y) {
    $control = New-Object Windows.Forms.Label
    $control.Text = $Content; $control.Location = New-Object Drawing.Point(22, $Y)
    $control.Size = New-Object Drawing.Size(175, 28); $form.Controls.Add($control)
}
function Field([int]$Y, [bool]$ReadOnly) {
    $control = New-Object Windows.Forms.TextBox
    $control.Location = New-Object Drawing.Point(200, $Y)
    $control.Size = New-Object Drawing.Size(430, 30); $control.ReadOnly = $ReadOnly
    $form.Controls.Add($control); return $control
}
function Button([string]$Content, [int]$X, [int]$Y, [int]$Width) {
    $control = New-Object Windows.Forms.Button
    $control.Text = $Content; $control.Location = New-Object Drawing.Point($X, $Y)
    $control.Size = New-Object Drawing.Size($Width, 34); $form.Controls.Add($control); return $control
}

Label '設定ファイル' 25
$profileBox = Field 22 $true
$pickProfile = Button '選択' 650 20 100
Label '連携担当の表示名' 75
$nameBox = Field 72 $false
Label 'VRChatのログ' 125
$logBox = Field 122 $true
$pickLog = Button '選択' 650 120 100
Label '台帳の連携キー' 175
$keyBox = Field 172 $false
$keyBox.UseSystemPasswordChar = $true; $keyBox.MaxLength = 128
$follow = New-Object Windows.Forms.CheckBox
$follow.Text = 'VRChat再起動時、同じワールドのログへ自動で切り替える'
$follow.Checked = $true; $follow.Location = New-Object Drawing.Point(200, 214)
$follow.Size = New-Object Drawing.Size(550, 28); $form.Controls.Add($follow)
$start = Button '連携を開始' 24 260 185
$stop = Button '停止' 224 260 145; $stop.Enabled = $false
$retry = Button '失敗分を再送' 384 260 185; $retry.Enabled = $false
$close = Button '閉じる' 585 260 165
$status = New-Object Windows.Forms.Label
$status.Location = New-Object Drawing.Point(24, 315); $status.Size = New-Object Drawing.Size(730, 95)
$status.Text = 'Unityで書き出した設定ファイルと、参加中のVRChatのログを選んでください。'
$form.Controls.Add($status)
$script:worker = $null; $script:outTask = $null; $script:errTask = $null; $script:nextStatusAt = [DateTime]::MinValue

function Load-Profile([string]$Path) {
    $value = Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach ($property in $value.PSObject.Properties.Name) {
        if ($property -notin @('schema_version','name','world_id','backend_url','bridge_display_name')) { throw 'INVALID_PROFILE_FIELDS' }
    }
    if ($value.schema_version -ne 1 -or $value.world_id -notmatch '^[A-Za-z0-9_-]{1,80}$' -or $value.backend_url -notmatch '^https://script\.google\.com/macros/s/[A-Za-z0-9_-]+/exec$') { throw 'INVALID_PROFILE' }
    return $value
}
$defaultProfile = Join-Path $PSScriptRoot 'profile.json'
if (Test-Path -LiteralPath $defaultProfile) {
    try { $loaded = Load-Profile $defaultProfile; $profileBox.Text = $defaultProfile; $nameBox.Text = $loaded.bridge_display_name } catch { }
}
$logDirectory = Join-Path $env:USERPROFILE 'AppData\LocalLow\VRChat\VRChat'
$latest = Get-ChildItem -LiteralPath $logDirectory -Filter 'output_log_*.txt' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($latest) { $logBox.Text = $latest.FullName }
$pickProfile.Add_Click({
    $picker = New-Object Windows.Forms.OpenFileDialog
    try {
        $picker.Filter = '受付連携設定 (*.json)|*.json'
        if ($picker.ShowDialog($form) -eq [Windows.Forms.DialogResult]::OK) {
            $loaded = Load-Profile $picker.FileName; $profileBox.Text = $picker.FileName; $nameBox.Text = $loaded.bridge_display_name
        }
    } catch { $status.Text = '受付連携用の設定ファイルを選んでください。' }
    finally { $picker.Dispose() }
})
$pickLog.Add_Click({
    $picker = New-Object Windows.Forms.OpenFileDialog
    try {
        $picker.Filter = 'VRChatログ|output_log_*.txt'
        if (Test-Path -LiteralPath $logDirectory) { $picker.InitialDirectory = $logDirectory }
        if ($picker.ShowDialog($form) -eq [Windows.Forms.DialogResult]::OK) { $logBox.Text = $picker.FileName }
    } finally { $picker.Dispose() }
})

$timer = New-Object Windows.Forms.Timer
$timer.Interval = 500
$timer.Add_Tick({
    if ($null -eq $script:worker) { return }
    if ($script:worker.HasExited) {
        $timer.Stop()
        $result = $script:outTask.GetAwaiter().GetResult()
        $null = $script:errTask.GetAwaiter().GetResult()
        $status.Text = '停止しました。未送信の記録はPCに保存されています。'
        if ($script:worker.ExitCode -ne 0) {
            $status.Text = '起動または接続に失敗しました。設定・ログ・連携キーを確認してください。'
            $match = [regex]::Match($result, 'ERROR: ([A-Z_]{3,64})')
            if ($match.Success) { $status.Text += "`r`nエラー: " + $match.Groups[1].Value }
        }
        $script:worker.Dispose(); $script:worker = $null
        $start.Enabled = $true; $stop.Enabled = $false; $retry.Enabled = $false
        return
    }
    if ([DateTime]::UtcNow -lt $script:nextStatusAt) { return }
    $script:nextStatusAt = [DateTime]::UtcNow.AddSeconds(2)
    $response = $null; $reader = $null
    try {
        $request = [Net.HttpWebRequest]::Create('http://127.0.0.1:22542/v1/state'); $request.Proxy = $null; $request.Timeout = 1000
        $response = $request.GetResponse(); $reader = New-Object IO.StreamReader($response.GetResponseStream(), [Text.Encoding]::UTF8)
        $value = $reader.ReadToEnd() | ConvertFrom-Json
        if ($value.protocol -ne 'sgimmicks.reception.bridge.v1' -or $value.world_id -ne $script:activeWorld) { throw 'Wrong companion' }
        $cloud = if ($value.cloud_ok) { 'Google接続中' } else { 'Google接続待ち' }
        $world = if ($value.world_connected) { 'ワールド接続中' } else { 'ワールド待機中' }
        $pending = if ($value.counts.pending) { $value.counts.pending } else { 0 }
        $failed = if ($value.counts.rejected) { $value.counts.rejected } else { 0 }
        $status.Text = $cloud + ' ／ ' + $world + "`r`n送信待ち: " + $pending + '件　要確認: ' + $failed + '件'
        if ($value.error -match '^[A-Z_]{3,64}$') { $status.Text += "`r`nエラー: " + $value.error }
        $status.ForeColor = if ($value.cloud_ok -and -not $value.error) { [Drawing.Color]::DarkGreen } else { [Drawing.Color]::DarkRed }
        $retry.Enabled = $failed -gt 0
    } catch { $status.Text = '補助ツールの起動を待っています。' }
    finally { if ($reader) { $reader.Dispose() }; if ($response) { $response.Dispose() } }
})

$start.Add_Click({
    $info = $null
    try {
        if (-not (Test-Path -LiteralPath $corePath)) { throw 'CORE_NOT_FOUND' }
        $loaded = Load-Profile $profileBox.Text
        $name = $nameBox.Text.Trim()
        if (-not $name -or $name.Length -gt 64 -or $name -match '[\x00-\x1f]') { throw 'BRIDGE_NAME_REQUIRED' }
        if (-not (Test-Path -LiteralPath $logBox.Text -PathType Leaf)) { throw 'LOG_NOT_FOUND' }
        $key = $keyBox.Text.Trim(); $keyBox.Clear()
        $info = New-CoreStartInfo $key $activeProfile $logBox.Text $follow.Checked
        $key = $null
        New-Item -ItemType Directory -Force -Path $stateRoot | Out-Null
        @{schema_version=1;name=$loaded.name;world_id=$loaded.world_id;backend_url=$loaded.backend_url;bridge_display_name=$name} | ConvertTo-Json | Set-Content -LiteralPath $activeProfile -Encoding UTF8
        $script:activeWorld = $loaded.world_id
        $script:worker = New-Object Diagnostics.Process; $script:worker.StartInfo = $info
        if (-not $script:worker.Start()) { throw 'START_FAILED' }
        $script:outTask = $script:worker.StandardOutput.ReadToEndAsync(); $script:errTask = $script:worker.StandardError.ReadToEndAsync()
        $start.Enabled = $false; $stop.Enabled = $true; $script:nextStatusAt = [DateTime]::MinValue
        $status.Text = '接続中です。連携キーは保存しません。'; $timer.Start()
    } catch {
        if ($script:worker) { $script:worker.Dispose(); $script:worker = $null }
        $keyBox.Clear(); $status.ForeColor = [Drawing.Color]::DarkRed
        $status.Text = '設定ファイル・担当者の表示名・ログ・64桁の連携キーを確認してください。'
    } finally { $key = $null; if ($info) { $info.EnvironmentVariables.Remove('SG_RECEPTION_KEY') } }
})
$stop.Add_Click({ if ($script:worker -and -not $script:worker.HasExited) { $script:worker.StandardInput.WriteLine('stop'); $script:worker.StandardInput.Flush(); $status.Text = '停止処理中です。送信中の要求の結果を待っています。' } })
$retry.Add_Click({ if ($script:worker -and -not $script:worker.HasExited) { $script:worker.StandardInput.WriteLine('retry_failed'); $script:worker.StandardInput.Flush() } })
$close.Add_Click({ $form.Close() })
$form.Add_Shown({ if (-not $PreviewPath) { $form.Activate() }; $form.TopMost = $false })
if ($PreviewPath) {
    $form.ShowInTaskbar = $false
    $form.TopMost = $false
    $form.StartPosition = 'Manual'
    $form.Location = New-Object Drawing.Point(-12000, -12000)
    $form.Show()
    [Windows.Forms.Application]::DoEvents()
    $bitmap = New-Object Drawing.Bitmap($form.Width, $form.Height)
    try { $form.DrawToBitmap($bitmap, (New-Object Drawing.Rectangle(0, 0, $form.Width, $form.Height))); $bitmap.Save($PreviewPath, [Drawing.Imaging.ImageFormat]::Png) }
    finally { $bitmap.Dispose(); $timer.Dispose(); $form.Close(); $form.Dispose() }
    exit 0
}
try { $null = $form.ShowDialog() }
finally {
    $timer.Stop(); $timer.Dispose()
    if ($script:worker) {
        if (-not $script:worker.HasExited) {
            try { $script:worker.StandardInput.WriteLine('stop'); $script:worker.StandardInput.Flush() } catch { }
            if (-not $script:worker.WaitForExit(2000)) { $script:worker.Kill() }
        }
        $script:worker.Dispose()
    }
    $keyBox.Clear(); $form.Dispose()
}
