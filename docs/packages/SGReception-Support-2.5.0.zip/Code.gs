// Bind this script to the user's NEW spreadsheet. This is not the stage 1 probe.
var RH_PROTOCOL = 'sgimmicks.reception.v1';
var RH_BOOK_ID = 'YOUR_SPREADSHEET_ID';
var RH_HEADERS = {
  '顧客台帳': ['顧客ID', '表示名', '旧表示名（改行区切り）', '移行前累計', '移行前最終加算日時UTC', '初期共有メモ', '累計来店回数（自動）', '最終加算日時UTC（自動）', '共有メモ（自動）'],
  '営業日別予約': ['予約ID', '営業日', '顧客ID', '参加枠', '指名キャスト', '前半／後半', '時間外枠', '当日枠選定状況'],
  'スタッフ': ['表示名', '有効'],
  '設定': ['設定キー', '値', '説明'],
  '受付履歴': ['要求ID', '顧客ID', '表示名', '受付日時UTC', '加算', '加算後累計', '前回加算日時UTC', 'メッセージ種別', '表示メッセージ', '要求ハッシュ', '応答JSON'],
  'メモ履歴': ['要求ID', '顧客ID', '変更日時UTC', '担当表示名', '改訂番号', '変更前メモ', '変更後メモ', '要求ハッシュ', '応答JSON']
};
var RH_SETTINGS = [
  ['business_date', '', '空欄なら日本時間の当日。予約一覧の営業日。24時間判定には影響しません。'],
  ['first_message', '{name}さん、初めてのご来店ありがとうございます。', '初回来店用。{name}と{count}を置換します。'],
  ['repeat_message', '{name}さん、おかえりなさい。累計{count}回のご来店ありがとうございます。', '通常のリピーター用。'],
  ['milestone_message', '{name}さん、{count}回目のご来店ありがとうございます！', '節目用。'],
  ['milestones', '5,10,25,50,100', 'カンマ区切りの正整数。'],
  ['milestone_interval', '100', '最大の節目を超えた後、この回数ごとに節目扱い。']
];

function setupReception() {
  var book = SpreadsheetApp.getActiveSpreadsheet();
  if (!book || book.getId() !== RH_BOOK_ID) throw new Error('SETUP_TARGET_MISMATCH');
  Object.keys(RH_HEADERS).forEach(function(name) {
    var sheet = book.getSheetByName(name) || book.insertSheet(name);
    var headers = RH_HEADERS[name];
    if (sheet.getLastRow() === 0) rhWrite_(sheet.getRange(1, 1, 1, headers.length), [headers]);
    else rhHeaders_(sheet, headers);
    sheet.setFrozenRows(1);
  });
  var customers = book.getSheetByName('顧客台帳');
  if (customers.getMaxRows() < 1001) customers.insertRowsAfter(customers.getMaxRows(), 1001 - customers.getMaxRows());
  var formulas = [];
  for (var r = 2; r <= 1001; r++) formulas.push(rhCustomerFormulas_(r));
  customers.getRange(2, 7, 1000, 3).setFormulas(formulas);
  var settings = book.getSheetByName('設定');
  if (settings.getLastRow() === 1) rhWrite_(settings.getRange(2, 1, RH_SETTINGS.length, 3), RH_SETTINGS);
  book.setSpreadsheetTimeZone('Asia/Tokyo');
  var props = PropertiesService.getScriptProperties();
  var key = props.getProperty('RECEPTION_KEY');
  if (!/^[a-f0-9]{64}$/i.test(key || '')) key = Utilities.getUuid().replace(/-/g, '') + Utilities.getUuid().replace(/-/g, '');
  props.setProperties({ RECEPTION_KEY: key, RECEPTION_SPREADSHEET_ID: RH_BOOK_ID });
  SpreadsheetApp.flush();
  // Editor / standalone / automated executions may not have a spreadsheet UI.
  // Retrieve the existing key in Project Settings > Script properties instead.
  // Never print the key in execution logs or write it into a sheet cell.
  console.log('受付台帳の初期設定が完了しました。連携キーは「プロジェクトの設定」→「スクリプト プロパティ」のRECEPTION_KEYから取得してください。');
  return { ok: true, spreadsheet_id: RH_BOOK_ID, key_property: 'RECEPTION_KEY' };
}

function doGet() { return rhJson_({ ok: false, protocol: RH_PROTOCOL, error: 'POST_REQUIRED' }); }

function doPost(e) {
  var lock = null;
  try {
    var body = e && e.postData && e.postData.contents;
    if (!body || body.length > 12000) rhFail_('INVALID_BODY');
    var req = JSON.parse(body);
    if (!req || Array.isArray(req) || typeof req !== 'object') rhFail_('INVALID_REQUEST');
    var props = PropertiesService.getScriptProperties();
    var key = props.getProperty('RECEPTION_KEY');
    if (!key || key.length < 32 || req.key !== key) rhFail_('UNAUTHORIZED');
    if (req.protocol !== RH_PROTOCOL) rhFail_('PROTOCOL_MISMATCH');
    var normalized = rhRequest_(req);
    lock = LockService.getScriptLock();
    lock.waitLock(10000);
    var book = SpreadsheetApp.openById(props.getProperty('RECEPTION_SPREADSHEET_ID'));
    if (book.getId() !== RH_BOOK_ID) rhFail_('TARGET_MISMATCH');
    return rhJson_(rhHandle_(book, normalized, new Date()));
  } catch (err) {
    var code = String(err.message || 'BACKEND_ERROR');
    if (!/^[A-Z_]{3,64}$/.test(code)) code = 'BACKEND_ERROR';
    var response = { ok: false, protocol: RH_PROTOCOL, error: code };
    if (code === 'MEMO_CONFLICT' && err.current) response.current = err.current;
    return rhJson_(response);
  } finally { if (lock && lock.hasLock()) lock.releaseLock(); }
}

function rhRequest_(req) {
  var fields = {
    ping: [], lookup: ['display_name'], check_in: ['request_id', 'display_name'],
    staff_snapshot: ['staff_name', 'offset', 'limit', 'business_date', 'revision'],
    update_memo: ['request_id', 'customer_id', 'staff_name', 'expected_revision', 'memo']
  };
  if (!Object.prototype.hasOwnProperty.call(fields, req.action)) rhFail_('INVALID_ACTION');
  var allowed = ['protocol', 'key', 'action'].concat(fields[req.action]);
  Object.keys(req).forEach(function(k) { if (allowed.indexOf(k) < 0) rhFail_('UNKNOWN_FIELD'); });
  var result = { action: req.action };
  fields[req.action].forEach(function(k) { if (req[k] !== undefined) result[k] = req[k]; });
  if (req.action === 'lookup' || req.action === 'check_in') rhName_(result.display_name);
  if (req.action === 'check_in' || req.action === 'update_memo') rhId_(result.request_id, 8, 96);
  if (req.action === 'staff_snapshot' || req.action === 'update_memo') rhName_(result.staff_name);
  if (req.action === 'update_memo') {
    rhId_(result.customer_id, 3, 64);
    rhInteger_(result.expected_revision, 0, 10000);
    rhText_(result.memo, 1000, true);
  }
  if (req.action === 'staff_snapshot') {
    result.offset = req.offset === undefined ? 0 : req.offset;
    result.limit = req.limit === undefined ? 30 : req.limit;
    rhInteger_(result.offset, 0, 1000); rhInteger_(result.limit, 1, 50);
    if (result.business_date !== undefined) rhDay_(result.business_date);
    if (result.revision !== undefined) rhText_(result.revision, 64, false);
  }
  return result;
}

function rhHandle_(book, req, now) {
  var stamp = now.toISOString();
  if (req.action === 'ping') return rhOk_({ server_time_utc: stamp, schema_version: 1 });
  var data = rhLoad_(book);
  if (req.action === 'update_memo' || req.action === 'staff_snapshot') rhStaff_(data, req.staff_name);
  var hash = rhHash_(JSON.stringify(req));
  if (req.request_id) {
    var saved = rhReplay_(data, req.request_id, hash);
    if (saved) return saved;
  }
  if (req.action === 'lookup') {
    var found = rhFindName_(data, req.display_name);
    return rhOk_({ customer: found ? rhGuest_(rhState_(data, found), data.settings) : null });
  }
  if (req.action === 'staff_snapshot') {
    var revision = rhHash_(JSON.stringify(data.raw));
    if (req.revision && req.revision !== revision) rhFail_('SNAPSHOT_CHANGED');
    var day = req.business_date || data.settings.business_date || Utilities.formatDate(now, 'Asia/Tokyo', 'yyyy-MM-dd');
    rhDay_(day);
    var customers = data.customers.slice().sort(function(a, b) { return a.id < b.id ? -1 : a.id > b.id ? 1 : 0; });
    var page = customers.slice(req.offset, req.offset + req.limit).map(function(customer) {
      var state = rhState_(data, customer);
      state.bookings = data.bookings.filter(function(b) { return b.customer_id === customer.id && b.business_date === day; });
      return state;
    });
    return rhOk_({ server_time_utc: stamp, business_date: day, revision: revision, total: customers.length,
      next_offset: req.offset + page.length < customers.length ? req.offset + page.length : null, customers: page });
  }
  if (req.action === 'check_in') {
    var customer = rhFindName_(data, req.display_name);
    if (!customer) {
      var id = 'C_' + rhHash_(req.display_name).slice(0, 24);
      if (data.customers.some(function(c) { return c.id.toUpperCase() === id.toUpperCase(); })) rhFail_('CUSTOMER_ID_CONFLICT');
      if (data.customers.length >= 1000) rhFail_('CUSTOMER_CAPACITY');
      var rowIndex = 2;
      while (data.usedCustomerRows.indexOf(rowIndex) >= 0) rowIndex++;
      customer = { id: id, display_name: req.display_name, aliases: [], base_count: 0, base_last: '', base_memo: '' };
      rhWrite_(book.getSheetByName('顧客台帳').getRange(rowIndex, 1, 1, 6), [[id, req.display_name, '', 0, '', '']]);
      data.customers.push(customer);
    }
    var state = rhState_(data, customer);
    if (state.last_counted_at && Date.parse(state.last_counted_at) > now.getTime()) rhFail_('FUTURE_LAST_VISIT');
    var counted = !state.last_counted_at || now.getTime() - Date.parse(state.last_counted_at) >= 86400000;
    var previous = state.last_counted_at;
    if (counted) { state.count++; state.previous_counted_at = previous; state.last_counted_at = stamp; }
    var guest = rhGuest_(state, data.settings);
    var response = rhOk_({ request_id: req.request_id, counted: counted, accepted_at_utc: stamp, customer: guest, replayed: false });
    rhAppend_(book.getSheetByName('受付履歴'), data.receipts.length, [req.request_id, customer.id, req.display_name, stamp,
      counted ? 1 : 0, state.count, previous, guest.message_kind, guest.message, hash, JSON.stringify(response)]);
    return response;
  }
  if (req.action === 'update_memo') {
    var target = data.customers.filter(function(c) { return c.id === req.customer_id; })[0];
    if (!target) rhFail_('CUSTOMER_NOT_FOUND');
    var current = rhState_(data, target);
    if (req.expected_revision !== current.memo_revision) {
      var err = new Error('MEMO_CONFLICT');
      err.current = { memo: current.memo, memo_revision: current.memo_revision };
      throw err;
    }
    var updated = rhOk_({ request_id: req.request_id, customer_id: target.id, memo: req.memo,
      memo_revision: current.memo_revision + 1, updated_at_utc: stamp, replayed: false });
    rhAppend_(book.getSheetByName('メモ履歴'), data.memos.length, [req.request_id, target.id, stamp, req.staff_name,
      updated.memo_revision, current.memo, req.memo, hash, JSON.stringify(updated)]);
    return updated;
  }
  rhFail_('INVALID_ACTION');
}

function rhLoad_(book) {
  var raw = {};
  Object.keys(RH_HEADERS).forEach(function(name) {
    var limit = name === '顧客台帳' ? 1000 : name === '営業日別予約' ? 3000 : name === 'スタッフ' || name === '設定' ? 1000 : 10000;
    raw[name] = rhRows_(book.getSheetByName(name), RH_HEADERS[name], limit);
  });
  var ids = Object.create(null), idKeys = Object.create(null), names = Object.create(null), used = [];
  var customers = raw['顧客台帳'].map(function(entry) {
    var row = entry.values; used.push(entry.row);
    rhId_(row[0], 3, 64); rhName_(row[1]);
    if (ids[row[0]] || idKeys[row[0].toUpperCase()]) rhFail_('DUPLICATE_CUSTOMER_ID');
    ids[row[0]] = true; idKeys[row[0].toUpperCase()] = true;
    var aliases = String(row[2] || '').split(/\r?\n/).map(function(n) { return n.trim(); }).filter(Boolean);
    var count = rhInteger_(Number(row[3] || 0), 0, 1000000);
    var last = rhStamp_(row[4]);
    var memo = String(row[5] || ''); rhText_(memo, 1000, true);
    [row[1]].concat(aliases).forEach(function(n) {
      rhName_(n);
      if (Object.prototype.hasOwnProperty.call(names, n) && names[n] !== row[0]) rhFail_('AMBIGUOUS_DISPLAY_NAME');
      names[n] = row[0];
    });
    return { id: row[0], display_name: row[1], aliases: aliases, base_count: count, base_last: last, base_memo: memo };
  });
  var settings = Object.create(null);
  RH_SETTINGS.forEach(function(r) { settings[r[0]] = r[1]; });
  raw['設定'].forEach(function(e) {
    var value = e.values[1];
    settings[e.values[0]] = e.values[0] === 'business_date' && value instanceof Date
      ? Utilities.formatDate(value, 'Asia/Tokyo', 'yyyy-MM-dd') : String(value === undefined ? '' : value);
  });
  if (settings.business_date) rhDay_(settings.business_date);
  var bookingIds = Object.create(null);
  var bookings = raw['営業日別予約'].map(function(e) {
    var r = e.values;
    rhId_(r[0], 3, 64); rhId_(r[2], 3, 64);
    if (bookingIds[r[0]]) rhFail_('DUPLICATE_BOOKING_ID');
    bookingIds[r[0]] = true;
    if (!ids[r[2]]) rhFail_('UNKNOWN_BOOKING_CUSTOMER');
    var day = r[1] instanceof Date ? Utilities.formatDate(r[1], 'Asia/Tokyo', 'yyyy-MM-dd') : String(r[1]);
    rhDay_(day);
    if (['', '未指定', '前半', '後半'].indexOf(String(r[5])) < 0 || ['未選定', '候補', '確定', '対象外', ''].indexOf(String(r[7])) < 0) rhFail_('INVALID_BOOKING_OPTION');
    return { booking_id: r[0], business_date: day, customer_id: r[2], slot: String(r[3] || ''), cast: String(r[4] || ''),
      half: String(r[5] || ''), overtime: rhBool_(r[6]), selection_status: String(r[7] || '') };
  });
  raw['受付履歴'].forEach(function(e) {
    var r = e.values;
    rhId_(r[0], 8, 96);
    if (!ids[r[1]] || !rhStamp_(r[3])) rhFail_('RECEIPT_HISTORY_CORRUPT');
    rhInteger_(Number(r[4]), 0, 1);
  });
  raw['メモ履歴'].forEach(function(e) { if (!ids[e.values[1]]) rhFail_('MEMO_HISTORY_CORRUPT'); });
  return { raw: raw, customers: customers, usedCustomerRows: used, bookings: bookings,
    receipts: raw['受付履歴'], memos: raw['メモ履歴'], staff: raw['スタッフ'], settings: settings };
}

function rhState_(data, customer) {
  var count = customer.base_count, last = customer.base_last, previous = '', memo = customer.base_memo, revision = 0;
  data.receipts.forEach(function(e) {
    var r = e.values;
    if (r[1] !== customer.id) return;
    var increment = rhInteger_(Number(r[4]), 0, 1);
    if (increment) { previous = last; last = rhStamp_(r[3]); count++; }
  });
  data.memos.forEach(function(e) {
    var r = e.values;
    if (r[1] !== customer.id) return;
    var next = rhInteger_(Number(r[4]), 1, 10000);
    if (next !== revision + 1) rhFail_('MEMO_HISTORY_CORRUPT');
    revision = next; memo = String(r[6]); rhText_(memo, 1000, true);
  });
  return { customer_id: customer.id, display_name: customer.display_name, count: count,
    last_counted_at: last, previous_counted_at: previous, memo: memo, memo_revision: revision };
}

function rhGuest_(state, settings) {
  var points = String(settings.milestones).split(',').map(function(v) { return rhInteger_(Number(v.trim()), 1, 1000000); });
  var interval = rhInteger_(Number(settings.milestone_interval), 1, 1000000);
  var maximum = Math.max.apply(null, points);
  var kind = state.count === 1 ? 'first' : points.indexOf(state.count) >= 0 || state.count > maximum && state.count % interval === 0 ? 'milestone' : 'repeat';
  var template = String(settings[kind + '_message']); rhText_(template, 1500, true);
  var message = template.replace(/\{name\}/g, function() { return state.display_name; }).replace(/\{count\}/g, String(state.count));
  return { customer_id: state.customer_id, display_name: state.display_name, count: state.count, message_kind: kind,
    message: message, last_counted_at: state.last_counted_at,
    next_count_at_utc: state.last_counted_at ? new Date(Date.parse(state.last_counted_at) + 86400000).toISOString() : '', display_seconds: 30 };
}

function rhReplay_(data, id, hash) {
  var matches = [];
  data.receipts.forEach(function(e) { if (e.values[0] === id) matches.push([e.values[9], e.values[10]]); });
  data.memos.forEach(function(e) { if (e.values[0] === id) matches.push([e.values[7], e.values[8]]); });
  if (!matches.length) return null;
  if (matches.length !== 1) rhFail_('DUPLICATE_REQUEST_HISTORY');
  if (matches[0][0] !== hash) rhFail_('REQUEST_ID_CONFLICT');
  var response = JSON.parse(matches[0][1]);
  if (!response || response.ok !== true || response.request_id !== id || response.protocol !== RH_PROTOCOL) rhFail_('HISTORY_CORRUPT');
  response.replayed = true;
  return response;
}
function rhFindName_(data, name) {
  return data.customers.filter(function(c) { return c.display_name === name || c.aliases.indexOf(name) >= 0; })[0] || null;
}
function rhStaff_(data, name) {
  if (!data.staff.some(function(e) { return e.values[0] === name && rhBool_(e.values[1]); })) rhFail_('STAFF_REQUIRED');
}
function rhRows_(sheet, headers, limit) {
  if (!sheet) rhFail_('MISSING_SHEET');
  rhHeaders_(sheet, headers);
  var last = sheet.getLastRow();
  if (last > limit + 1) rhFail_('ROW_CAPACITY');
  if (last < 2) return [];
  var rows = sheet.getRange(2, 1, last - 1, headers.length).getValues();
  var result = [];
  rows.forEach(function(r, i) {
    // Calculated customer columns are a view, never inputs to counting or memo state.
    var source = headers === RH_HEADERS['顧客台帳'] ? r.slice(0, 6) : r;
    if (source.every(function(v) { return v === '' || v === null || v === false; })) return;
    if (source[0] === '') rhFail_('ROW_MISSING_ID');
    result.push({ row: i + 2, values: source });
  });
  return result;
}
function rhHeaders_(sheet, headers) {
  var actual = sheet.getRange(1, 1, 1, headers.length).getValues()[0];
  if (JSON.stringify(actual) !== JSON.stringify(headers)) rhFail_('HEADER_MISMATCH');
}
function rhAppend_(sheet, count, row) {
  if (count >= 10000 || sheet.getLastRow() >= 10001) rhFail_('HISTORY_CAPACITY');
  rhWrite_(sheet.getRange(sheet.getLastRow() + 1, 1, 1, row.length), [row]);
  SpreadsheetApp.flush();
}
function rhWrite_(range, rows) {
  // Prefix ALL strings, including leading apostrophes, so Sheets never interprets user text as a formula.
  range.setValues(rows.map(function(r) { return r.map(function(v) { return typeof v === 'string' ? "'" + v : v; }); }));
}
function rhCustomerFormulas_(r) {
  return [
    '=IF(A' + r + '="","",D' + r + '+COUNTIFS(\'受付履歴\'!B$2:B$10001,A' + r + ',\'受付履歴\'!E$2:E$10001,1))',
    '=IF(A' + r + '="","",IFERROR(ARRAYFORMULA(LOOKUP(2,1/((\'受付履歴\'!B$2:B$10001=A' + r + ')*(\'受付履歴\'!E$2:E$10001=1)),\'受付履歴\'!D$2:D$10001)),E' + r + '))',
    '=IF(A' + r + '="","",IFERROR(ARRAYFORMULA(LOOKUP(2,1/(\'メモ履歴\'!B$2:B$10001=A' + r + '),\'メモ履歴\'!G$2:G$10001)),F' + r + '))'
  ];
}
function rhStamp_(v) {
  if (v === '' || v === null || v === undefined) return '';
  if (v instanceof Date) return v.toISOString();
  if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{3})?Z$/.test(v) || !isFinite(Date.parse(v))) rhFail_('INVALID_UTC_TIMESTAMP');
  var canonical = new Date(v).toISOString();
  if (canonical.replace('.000Z', 'Z') !== v.replace('.000Z', 'Z')) rhFail_('INVALID_UTC_TIMESTAMP');
  return canonical;
}
function rhDay_(v) {
  if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(v) || !isFinite(Date.parse(v + 'T00:00:00Z')) || new Date(v + 'T00:00:00Z').toISOString().slice(0, 10) !== v) rhFail_('INVALID_BUSINESS_DATE');
  return v;
}
function rhInteger_(v, min, max) { if (typeof v !== 'number' || !isFinite(v) || Math.floor(v) !== v || v < min || v > max) rhFail_('INVALID_INTEGER'); return v; }
function rhName_(v) { rhText_(v, 64, false); if (!v || v.trim() !== v) rhFail_('INVALID_DISPLAY_NAME'); return v; }
function rhId_(v, min, max) { if (typeof v !== 'string' || v.length < min || v.length > max || !/^[A-Za-z0-9_-]+$/.test(v)) rhFail_('INVALID_ID'); return v; }
function rhText_(v, max, multiline) { if (typeof v !== 'string' || v.length > max || (multiline ? /[\x00-\x08\x0b\x0c\x0e-\x1f]/ : /[\x00-\x1f]/).test(v)) rhFail_('INVALID_TEXT'); return v; }
function rhBool_(v) { if (v === true || v === 'TRUE') return true; if (v === false || v === '' || v === 'FALSE') return false; rhFail_('INVALID_BOOLEAN'); }
function rhHash_(text) { return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, text, Utilities.Charset.UTF_8).map(function(b) { return ('0' + ((b + 256) % 256).toString(16)).slice(-2); }).join(''); }
function rhOk_(value) { return Object.assign({ ok: true, protocol: RH_PROTOCOL }, value); }
function rhJson_(value) { return ContentService.createTextOutput(JSON.stringify(value)).setMimeType(ContentService.MimeType.JSON); }
function rhFail_(code) { throw new Error(code); }
