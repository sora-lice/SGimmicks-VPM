using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using VRC.SDK3.UdonNetworkCalling;
using VRC.Udon.Common.Interfaces;

namespace SGimmicks
{
    [UdonBehaviourSyncMode(BehaviourSyncMode.Manual)]
    public class SGGlobalObjectToggleController : UdonSharpBehaviour
    {
        [Header("個別の表示切替")]
        public GameObject[] targets = new GameObject[0];
        public string[] showCodes = new string[0];
        public string[] hideCodes = new string[0];
        public bool[] initiallyVisible = new bool[0];
        [Header("全対象の一括操作（空欄で無効）")]
        public string showAllCode = "";
        public string hideAllCode = "";

        [UdonSynced] private bool[] _visible = new bool[0];

        private void Start()
        {
            EnsureState();
            ApplyState();
            if (Networking.IsOwner(gameObject)) RequestSerialization();
        }

        public override void OnDeserialization()
        {
            ApplyState();
        }

        public override void OnOwnershipTransferred(VRCPlayerApi player)
        {
            if (!Utilities.IsValid(player) || !player.isLocal) return;
            EnsureState();
            ApplyState();
            RequestSerialization();
        }

        // UIの有効・無効と同期を切り離すため、このBehaviourは常時有効な別ルートへ置きます。
        public int RequestCode(string code)
        {
            int count = CountTargets(code);
            if (count == 0) return 0;
            if (!Utilities.IsValid(Networking.LocalPlayer)) return -1;
            if (Networking.IsOwner(gameObject)) ApplyCode(code);
            else SendCustomNetworkEvent(NetworkEventTarget.Owner, nameof(NetApplyCode), code);
            return count;
        }

        [NetworkCallable(maxEventsPerSecond: 5)]
        public void NetApplyCode(string code)
        {
            if (!Networking.IsOwner(gameObject)) return;
            if (CountTargets(code) > 0) ApplyCode(code);
        }

        private int CountTargets(string code)
        {
            if (string.IsNullOrEmpty(code) || code.Length != 4 || targets == null) return 0;
            int count = 0;
            for (int i = 0; i < targets.Length; i++)
                if (targets[i] != null && Matches(i, code)) count++;
            return count;
        }

        private bool Matches(int index, string code)
        {
            return (!string.IsNullOrEmpty(showAllCode) && code == showAllCode) ||
                (!string.IsNullOrEmpty(hideAllCode) && code == hideAllCode) ||
                (showCodes != null && index < showCodes.Length && code == showCodes[index]) ||
                (hideCodes != null && index < hideCodes.Length && code == hideCodes[index]);
        }

        private void ApplyCode(string code)
        {
            EnsureState();
            for (int i = 0; i < targets.Length; i++)
            {
                if (targets[i] == null || !Matches(i, code)) continue;
                bool show = (!string.IsNullOrEmpty(showAllCode) && code == showAllCode) ||
                    (showCodes != null && i < showCodes.Length && code == showCodes[i]);
                _visible[i] = show;
            }
            ApplyState();
            RequestSerialization();
        }

        private void EnsureState()
        {
            int count = targets == null ? 0 : targets.Length;
            if (_visible != null && _visible.Length == count) return;
            _visible = new bool[count];
            for (int i = 0; i < count; i++)
                _visible[i] = initiallyVisible != null && i < initiallyVisible.Length
                    ? initiallyVisible[i] : targets[i] != null && targets[i].activeSelf;
        }

        private void ApplyState()
        {
            if (targets == null || _visible == null || _visible.Length != targets.Length) return;
            for (int i = 0; i < targets.Length; i++)
                if (targets[i] != null) targets[i].SetActive(_visible[i]);
        }
    }
}
