using System;
using System.Collections.Generic;
using UdonSharpEditor;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace SGimmicks.Editor
{
    [Serializable]
    public sealed class SGGlobalToggleEntry
    {
        public GameObject target;
        public string showCode = "9001";
        public string hideCode = "9000";
        public bool initiallyVisible = true;
    }

    internal static class SGGlobalToggleFactory
    {
        internal static List<SGGlobalToggleEntry> Read(SGRoomTeleportController app)
        {
            var result = new List<SGGlobalToggleEntry>();
            var controller = app == null ? null : app.globalToggleController;
            if (controller != null && controller.targets != null)
            {
                for (int i = 0; i < controller.targets.Length; i++)
                    result.Add(new SGGlobalToggleEntry
                    {
                        target = controller.targets[i],
                        showCode = controller.showCodes != null && i < controller.showCodes.Length ? controller.showCodes[i] : "9001",
                        hideCode = controller.hideCodes != null && i < controller.hideCodes.Length ? controller.hideCodes[i] : "9000",
                        initiallyVisible = controller.initiallyVisible != null && i < controller.initiallyVisible.Length
                            ? controller.initiallyVisible[i] : controller.targets[i] != null && controller.targets[i].activeSelf
                    });
            }
            else if (app != null && app.globalToggleObject != null)
                result.Add(new SGGlobalToggleEntry { target = app.globalToggleObject, showCode = app.globalShowCode,
                    hideCode = app.globalHideCode, initiallyVisible = app.globalToggleObject.activeSelf });
            return result;
        }

        internal static void Validate(Transform appsRoot, SGRoomTeleportController app,
            IList<SGGlobalToggleEntry> entries, IList<string> roomCodes, string allShow, string allHide)
        {
            if (entries == null) throw new ArgumentException("表示切替の設定一覧がありません。");
            var sync = app == null ? null : app.globalToggleController;
            if (sync != null && (EditorUtility.IsPersistent(sync) || sync.gameObject.scene != appsRoot.gameObject.scene))
                throw new ArgumentException("表示切替の同期コントローラーはRTabと同じシーンへ配置してください。");
            var targets = new HashSet<GameObject>();
            var individualCodes = new HashSet<string>();
            foreach (var entry in entries)
            {
                if (entry == null || entry.target == null || EditorUtility.IsPersistent(entry.target) ||
                    entry.target.scene != appsRoot.gameObject.scene)
                    throw new ArgumentException("表示切替の対象を、RTabと同じシーンのHierarchyから指定してください。");
                if (!targets.Add(entry.target)) throw new ArgumentException("同じオブジェクトを重複登録できません。");
                if (appsRoot.IsChildOf(entry.target.transform) || (app != null && app.transform.IsChildOf(entry.target.transform)))
                    throw new ArgumentException("RTab本体・Apps・アプリ自身やその親は表示切替対象にできません。");
                if (sync != null && sync.transform.IsChildOf(entry.target.transform))
                    throw new ArgumentException("表示状態の同期コントローラー自身やその親は対象にできません。");
                string show = Trim(entry.showCode), hide = Trim(entry.hideCode);
                RequireCode(show); RequireCode(hide);
                if (show == hide) throw new ArgumentException("同じ対象の表示番号と非表示番号には別の4桁を指定してください。");
                if (Contains(roomCodes, show) || Contains(roomCodes, hide))
                    throw new ArgumentException("表示切替番号とテレポート用の部屋番号は重複できません。");
                individualCodes.Add(show); individualCodes.Add(hide);
            }
            allShow = Trim(allShow); allHide = Trim(allHide);
            if (entries.Count > 0)
            {
                if (allShow != "") RequireCode(allShow);
                if (allHide != "") RequireCode(allHide);
                if (allShow != "" && allShow == allHide) throw new ArgumentException("一括表示と一括非表示には別の番号を指定してください。");
                foreach (string code in new[] { allShow, allHide })
                    if (code != "" && (individualCodes.Contains(code) || Contains(roomCodes, code)))
                        throw new ArgumentException("一括操作の番号は、個別の表示切替番号・部屋番号と重複できません。");
            }
        }

        internal static void Configure(SGRoomTeleportController app, IList<SGGlobalToggleEntry> entries,
            string allShow, string allHide)
        {
            var controller = app.globalToggleController;
            if (controller == null && entries.Count > 0)
            {
                var root = new GameObject("SGRoomGlobalObjectVisibility");
                Undo.RegisterCreatedObjectUndo(root, "Create global object visibility controller");
                UnityEngine.SceneManagement.SceneManager.MoveGameObjectToScene(root, app.gameObject.scene);
                controller = SGEditorFactory.AddBundledComponent<SGGlobalObjectToggleController>(root);
            }
            if (controller != null)
            {
                if (EditorUtility.IsPersistent(controller) || controller.gameObject.scene != app.gameObject.scene)
                    throw new ArgumentException("表示切替の同期コントローラーはRTabと同じシーンへ配置してください。");
                Undo.RecordObject(controller.gameObject, "Keep visibility controller active");
                Undo.SetTransformParent(controller.transform, null, "Keep visibility controller at scene root");
                controller.gameObject.SetActive(true);
                Undo.RecordObject(controller, "Configure global object visibility");
                controller.enabled = true;
                controller.targets = new GameObject[entries.Count];
                controller.showCodes = new string[entries.Count];
                controller.hideCodes = new string[entries.Count];
                controller.initiallyVisible = new bool[entries.Count];
                controller.showAllCode = entries.Count > 0 ? Trim(allShow) : "";
                controller.hideAllCode = entries.Count > 0 ? Trim(allHide) : "";
                for (int i = 0; i < entries.Count; i++)
                {
                    var entry = entries[i];
                    controller.targets[i] = entry.target;
                    controller.showCodes[i] = Trim(entry.showCode);
                    controller.hideCodes[i] = Trim(entry.hideCode);
                    controller.initiallyVisible[i] = entry.initiallyVisible;
                    Undo.RecordObject(entry.target, "Set global visibility initial state");
                    entry.target.SetActive(entry.initiallyVisible);
                    EditorUtility.SetDirty(entry.target);
                    PrefabUtility.RecordPrefabInstancePropertyModifications(entry.target);
                }
                UdonSharpEditorUtility.CopyProxyToUdon(controller);
                var backing = UdonSharpEditorUtility.GetBackingUdonBehaviour(controller);
                Undo.RecordObject(backing, "Keep global visibility sync enabled");
                backing.enabled = true;
                backing.SyncMethod = VRC.SDKBase.Networking.SyncType.Manual;
                EditorUtility.SetDirty(backing);
                EditorUtility.SetDirty(controller);
                PrefabUtility.RecordPrefabInstancePropertyModifications(controller);
                PrefabUtility.RecordPrefabInstancePropertyModifications(backing);
                EditorSceneManager.MarkSceneDirty(controller.gameObject.scene);
            }
            Undo.RecordObject(app, "Bind global visibility controller");
            app.globalToggleController = controller;
            app.globalToggleObject = null;
            app.globalShowCode = "";
            app.globalHideCode = "";
        }

        private static string Trim(string value) { return value == null ? "" : value.Trim(); }
        private static bool Contains(IList<string> list, string code)
        {
            if (list == null) return false;
            for (int i = 0; i < list.Count; i++) if (Trim(list[i]) == code) return true;
            return false;
        }
        private static void RequireCode(string code)
        {
            if (code.Length != 4) throw new ArgumentException("表示切替番号は半角数字4桁で入力してください。");
            for (int i = 0; i < code.Length; i++)
                if (code[i] < '0' || code[i] > '9') throw new ArgumentException("表示切替番号は半角数字4桁で入力してください。");
        }
    }
}
