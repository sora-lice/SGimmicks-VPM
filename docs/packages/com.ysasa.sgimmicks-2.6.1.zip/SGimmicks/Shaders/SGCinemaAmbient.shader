Shader "SGimmicks/Cinema Blurred Ambient"
{
    Properties
    {
        _MainTex ("Video", 2D) = "black" {}
        _IsAVProVideo ("AVPro", Int) = 0
        _Side ("Left -1 Center 0 Right 1", Float) = 0
        _EdgeWidth ("Edge Sample Width", Range(0.02,0.5)) = 0.18
        _Blur ("Blur", Range(0,0.2)) = 0.045
        _Brightness ("Brightness", Range(0,2)) = 0.5
        _AudioReactiveStrength ("AudioLink Strength", Range(0,1)) = 0.15
        _GlowUVScale ("Glow UV Scale", Vector) = (1.4,1.7,0,0)
        _ProjectionOrigin ("Projection Origin", Vector) = (0,0,0,1)
        _ProjectionDirection ("Projection Direction", Vector) = (0,0,1,0)
        _ProjectionDepth ("Projection Depth", Float) = 1.25
    }
    CGINCLUDE
    #include "SGCinemaVideo.cginc"
    half4 AmbientColor(float2 uv)
    {
        float2 videoUV = (uv - 0.5) * _GlowUVScale.xy + 0.5;
        return half4(SGBlurredVideo(videoUV) * SGGlowFalloff(uv) * _Brightness * SGAudioBrightness(), 0);
    }
    ENDCG
    SubShader
    {
        Tags { "Queue"="Transparent-10" "RenderType"="Transparent" "IgnoreProjector"="True" }
        Pass
        {
            Name "AMBIENT_SURFACE"
            Cull Off ZWrite Off ZTest LEqual Blend One One
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma target 4.0
            #pragma multi_compile_instancing
            struct appdata { float4 vertex : POSITION; float2 uv : TEXCOORD0; UNITY_VERTEX_INPUT_INSTANCE_ID };
            struct v2f { float4 pos : SV_POSITION; float2 uv : TEXCOORD0; UNITY_VERTEX_OUTPUT_STEREO };
            v2f vert(appdata v) { v2f o; UNITY_SETUP_INSTANCE_ID(v); UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o); o.pos = UnityObjectToClipPos(v.vertex); o.uv = v.uv; return o; }
            half4 frag(v2f i) : SV_Target { UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(i); return AmbientColor(i.uv); }
            ENDCG
        }
    }
}
