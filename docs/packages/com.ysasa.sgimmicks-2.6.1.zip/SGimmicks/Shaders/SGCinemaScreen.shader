Shader "SGimmicks/Cinema Extended Screen"
{
    Properties
    {
        _MainTex ("Video", 2D) = "black" {}
        _IsAVProVideo ("AVPro", Int) = 0
        _Side ("Left -1 Center 0 Right 1", Float) = 0
        _EdgeWidth ("Edge Sample Width", Range(0.02,0.5)) = 0.18
        _Blur ("Blur", Range(0,0.2)) = 0
        _Brightness ("Brightness", Range(0,2)) = 1
        _AudioReactiveStrength ("AudioLink Strength", Range(0,1)) = 0
        _GlowUVScale ("Glow UV Scale", Vector) = (1,1,0,0)
    }
    SubShader
    {
        Tags { "RenderType"="Opaque" "Queue"="Geometry" "IgnoreProjector"="True" }
        Pass
        {
            Cull Off ZWrite On
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma target 4.0
            #pragma multi_compile_instancing
            #include "SGCinemaVideo.cginc"
            struct appdata { float4 vertex : POSITION; float2 uv : TEXCOORD0; UNITY_VERTEX_INPUT_INSTANCE_ID };
            struct v2f { float4 pos : SV_POSITION; float2 uv : TEXCOORD0; UNITY_VERTEX_OUTPUT_STEREO };
            v2f vert(appdata v) { v2f o; UNITY_SETUP_INSTANCE_ID(v); UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o); o.pos = UnityObjectToClipPos(v.vertex); o.uv = v.uv; return o; }
            half4 frag(v2f i) : SV_Target { UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(i); return half4(SGBlurredVideo(i.uv) * _Brightness, 1); }
            ENDCG
        }
    }
}
