#ifndef SG_CINEMA_VIDEO_INCLUDED
#define SG_CINEMA_VIDEO_INCLUDED
#include "UnityCG.cginc"
sampler2D _MainTex;
int _IsAVProVideo;
float _Side, _EdgeWidth, _Blur, _Brightness, _AudioReactiveStrength;
float4 _GlowUVScale;
Texture2D<float4> _AudioTexture;

float2 SGMirrorUV(float2 p) { return 1.0 - abs(frac(p * 0.5) * 2.0 - 1.0); }
float2 SGMapVideo(float2 p)
{
    if (_Side < -0.5) p.x = (1.0 - p.x) * _EdgeWidth;
    if (_Side > 0.5) p.x = 1.0 - p.x * _EdgeWidth;
    return SGMirrorUV(p);
}
half3 SGReadVideo(float2 p)
{
    p = clamp(SGMapVideo(p), 0.0001, 0.9999);
    #if UNITY_UV_STARTS_AT_TOP
    if (_IsAVProVideo != 0) p.y = 1.0 - p.y;
    #endif
    half3 color = tex2D(_MainTex, p).rgb;
    #ifndef UNITY_COLORSPACE_GAMMA
    if (_IsAVProVideo != 0) color = GammaToLinearSpace(color);
    #endif
    return color;
}
half3 SGBlurredVideo(float2 p)
{
    if (_Blur <= 0.00001) return SGReadVideo(p);
    float2 d = float2(_Blur, _Blur * 1.777778);
    half3 c = SGReadVideo(p) * 0.2;
    c += (SGReadVideo(p + float2(d.x, 0)) + SGReadVideo(p - float2(d.x, 0))
        + SGReadVideo(p + float2(0, d.y)) + SGReadVideo(p - float2(0, d.y))) * 0.12;
    c += (SGReadVideo(p + d) + SGReadVideo(p - d)
        + SGReadVideo(p + float2(d.x, -d.y)) + SGReadVideo(p + float2(-d.x, d.y))) * 0.08;
    return c;
}
float SGAudioBrightness()
{
    uint w, h;
    _AudioTexture.GetDimensions(w, h);
    if (w < 128 || h < 32) return 1.0;
    float bass = saturate(_AudioTexture.Load(int3(0, 28, 0)).r);
    return lerp(1.0, 0.7 + bass * 0.3, _AudioReactiveStrength);
}
float SGGlowFalloff(float2 uv)
{
    float2 fade = 1.0 - smoothstep(0.35, 1.0, abs(uv - 0.5) * 2.0);
    return fade.x * fade.y;
}
#endif
