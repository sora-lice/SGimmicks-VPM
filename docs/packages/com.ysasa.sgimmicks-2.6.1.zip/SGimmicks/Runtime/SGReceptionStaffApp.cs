using UdonSharp;
using UnityEngine;
using UnityEngine.UI;
using VRC.SDKBase;
using VRC.SDK3.Data;
using VRC.Udon;

namespace SGimmicks
{
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class SGReceptionStaffApp : UdonSharpBehaviour
    {
        public SGReceptionController controller;
        public UdonBehaviour callbackReceiver;
        public Text[] rowLabels = new Text[6];
        public Button[] rowButtons = new Button[6];
        public Text detailText;
        public Text pageText;
        public Text statusText;
        public GameObject memoPanel;
        public InputField memoInput;
        public Text memoStatus;
        public string responseJson;
        public string responseRequestId;
        public string responseAction;
        private DataList _rows;
        private int _offset;
        private int _askedOffset;
        private int _total;
        private int _selected;
        private string _pendingId = "";
        private string _originalMemo = "";
        private string _editedCustomer = "";
        private int _memoRevision;
        private bool _editing;
        private bool _conflict;
        private string _latestMemo = "";
        private int _latestRevision;
        private float _refreshAt;
        private bool _wasVisible;
        private float _waitNoticeAt;

        private void Start() { if (memoPanel != null) memoPanel.SetActive(false); ClearRows(); }
        private void OnDisable() { if (memoPanel != null) memoPanel.SetActive(false); _wasVisible = false; }
        private void Update()
        {
            bool visible = Visible();
            if (!visible && _wasVisible && memoPanel != null) memoPanel.SetActive(false);
            if (visible && !_wasVisible && _editing && memoPanel != null) memoPanel.SetActive(true);
            _wasVisible = visible;
            if (visible && _pendingId != "" && Time.time >= _waitNoticeAt && controller != null)
            { _waitNoticeAt = Time.time + 2f; Message(controller.GetWaitMessage(true)); }
            if (visible && !_editing && _pendingId == "" && Time.time >= _refreshAt) RequestPage(_offset);
        }

        private bool Visible()
        {
            Transform current = transform;
            for (int i = 0; i < 16 && current != null; i++)
            {
                if (!current.gameObject.activeInHierarchy) return false;
                CanvasGroup group = current.GetComponent<CanvasGroup>();
                if (group != null && group.alpha < .01f) return false;
                current = current.parent;
            }
            return true;
        }

        private void Message(string value)
        { if (statusText != null) statusText.text = value; if (memoStatus != null) memoStatus.text = value; }

        private bool CanBrowse()
        {
            if (_pendingId != "") { Message("応答を待っています。"); return false; }
            if (_editing) { Message("メモを保存するか、編集を取り消してください。"); return false; }
            return true;
        }

        public void _Refresh() { if (CanBrowse()) RequestPage(_offset); }
        public void _PreviousPage() { if (CanBrowse()) RequestPage(Mathf.Max(0, _offset - 6)); }
        public void _NextPage() { if (CanBrowse() && _offset + 6 < _total) RequestPage(_offset + 6); }
        private void RequestPage(int offset)
        {
            _refreshAt = Time.time + 30f;
            if (controller == null || callbackReceiver == null) { Message("受付システムが未設定です。"); return; }
            _askedOffset = offset;
            _pendingId = controller.Submit(2, "{\"offset\":" + offset + ",\"limit\":6}", callbackReceiver);
            _waitNoticeAt = Time.time + 8f;
            Message(_pendingId == "" ? "送信できませんでした。更新を押してください。" : "台帳を取得しています…");
        }

        public void _Select0() { Select(0); }
        public void _Select1() { Select(1); }
        public void _Select2() { Select(2); }
        public void _Select3() { Select(3); }
        public void _Select4() { Select(4); }
        public void _Select5() { Select(5); }
        private void Select(int index)
        {
            if (!CanBrowse() || _rows == null || index < 0 || index >= _rows.Count) return;
            _selected = index; RenderDetail();
        }

        private string StringValue(DataDictionary value, string key)
        { DataToken token; return value.TryGetValue(key, TokenType.String, out token) ? token.String : ""; }
        private int NumberValue(DataDictionary value, string key)
        { DataToken token; return value.TryGetValue(key, TokenType.Double, out token) ? (int)token.Double : 0; }
        private string Stamp(string value)
        { return value == "" ? "—" : value.Length >= 19 ? value.Substring(0, 10) + " " + value.Substring(11, 8) + " UTC" : value; }
        private DataDictionary Selected()
        { return _rows == null || _selected < 0 || _selected >= _rows.Count || _rows[_selected].TokenType != TokenType.DataDictionary ? null : _rows[_selected].DataDictionary; }

        private void ClearRows()
        {
            _rows = null;
            for (int i = 0; i < rowLabels.Length; i++) if (rowLabels[i] != null) rowLabels[i].text = "";
            for (int i = 0; i < rowButtons.Length; i++) if (rowButtons[i] != null) rowButtons[i].interactable = false;
            if (detailText != null) detailText.text = "お客さまを選択してください。";
        }

        private void RenderRows()
        {
            for (int i = 0; i < rowLabels.Length; i++)
            {
                bool valid = _rows != null && i < _rows.Count && _rows[i].TokenType == TokenType.DataDictionary;
                if (rowLabels[i] != null) rowLabels[i].text = valid ? StringValue(_rows[i].DataDictionary, "display_name") : "";
                if (i < rowButtons.Length && rowButtons[i] != null) rowButtons[i].interactable = valid;
            }
            if (pageText != null) pageText.text = _total == 0 ? "登録なし" : (_offset + 1) + "～" + Mathf.Min(_offset + 6, _total) + " / " + _total;
            RenderDetail();
        }

        private void RenderDetail()
        {
            DataDictionary row = Selected();
            if (detailText == null) return;
            if (row == null) { detailText.text = "お客さまを選択してください。"; return; }
            string value = StringValue(row, "display_name") + "\n累計 " + NumberValue(row, "count") + " 回\n";
            value += "最終加算受付: " + Stamp(StringValue(row, "last_counted_at")) + "\n前回加算受付: " + Stamp(StringValue(row, "previous_counted_at"));
            DataToken bookings;
            if (row.TryGetValue("bookings", TokenType.DataList, out bookings) && bookings.DataList.Count > 0)
            {
                for (int i = 0; i < bookings.DataList.Count; i++)
                {
                    if (bookings.DataList[i].TokenType != TokenType.DataDictionary) continue;
                    DataDictionary booking = bookings.DataList[i].DataDictionary;
                    DataToken overtime;
                    value += "\n参加枠: " + StringValue(booking, "slot") + " / 指名: " + StringValue(booking, "cast") + " " + StringValue(booking, "half");
                    value += booking.TryGetValue("overtime", TokenType.Boolean, out overtime) && overtime.Boolean ? " / 時間外" : "";
                    value += "\n当日枠: " + StringValue(booking, "selection_status");
                }
            }
            else value += "\n指定営業日の予約なし";
            value += "\n\n共有メモ\n" + StringValue(row, "memo");
            detailText.text = value;
            detailText.rectTransform.sizeDelta = new Vector2(0f, Mathf.Max(600f, detailText.preferredHeight + 24f));
            ScrollRect scroll = detailText.GetComponentInParent<ScrollRect>();
            if (scroll != null) scroll.verticalNormalizedPosition = 1f;
        }

        public void _EditMemo()
        {
            DataDictionary row = Selected();
            if (_pendingId != "" || row == null || memoPanel == null || memoInput == null) return;
            VRCPlayerApi local = Networking.LocalPlayer;
            if (!Utilities.IsValid(local)) return;
            _editing = true; _conflict = false;
            _editedCustomer = StringValue(row, "customer_id"); _originalMemo = StringValue(row, "memo");
            _memoRevision = NumberValue(row, "memo_revision"); memoInput.text = _originalMemo; memoInput.interactable = true;
            VRCPlayerApi.TrackingData head = local.GetTrackingData(VRCPlayerApi.TrackingDataType.Head);
            Quaternion rotation = Quaternion.Euler(0f, head.rotation.eulerAngles.y, 0f);
            memoPanel.transform.SetPositionAndRotation(head.position + rotation * new Vector3(0, -.05f, .8f), rotation);
            memoPanel.SetActive(true); Message("共有メモを編集できます（1000文字まで）。");
        }

        public void _CancelMemo()
        {
            if (_pendingId != "") { Message("保存の応答を待っています。"); return; }
            _editing = false; _conflict = false;
            if (memoPanel != null) memoPanel.SetActive(false);
            if (memoInput != null) memoInput.text = "";
            _refreshAt = Time.time + 30f; Message("編集を取り消しました。");
        }

        public void _LoadLatest()
        {
            if (!_editing || !_conflict || _pendingId != "" || memoInput == null) return;
            _originalMemo = _latestMemo; _memoRevision = _latestRevision; memoInput.text = _latestMemo; _conflict = false;
            Message("最新のメモを読み込みました。編集して保存してください。");
        }

        public void _SaveMemo()
        {
            if (!_editing || _pendingId != "" || memoInput == null || controller == null) return;
            if (_conflict) { Message("他のスタッフが更新しました。「最新を読込」後に編集し直してください。"); return; }
            if (memoInput.text == _originalMemo) { _CancelMemo(); return; }
            DataDictionary args = new DataDictionary();
            args.Add("customer_id", new DataToken(_editedCustomer)); args.Add("expected_revision", new DataToken(_memoRevision));
            args.Add("memo", new DataToken(memoInput.text));
            DataToken json;
            if (!VRCJson.TrySerializeToJson(args, JsonExportType.Minify, out json)) return;
            _pendingId = controller.Submit(3, json.String, callbackReceiver);
            _waitNoticeAt = Time.time + 8f;
            memoInput.interactable = _pendingId == "";
            Message(_pendingId == "" ? "送信できませんでした。再度保存してください。" : "共有メモを保存しています…");
        }

        public void _OnReceptionResponse()
        {
            if (responseRequestId != _pendingId || _pendingId == "") return;
            _pendingId = ""; _refreshAt = Time.time + 30f;
            if (memoInput != null) memoInput.interactable = true;
            DataToken root, ok;
            if (!VRCJson.TryDeserializeFromJson(responseJson, out root) || root.TokenType != TokenType.DataDictionary) { Message("応答を読み取れませんでした。"); return; }
            DataDictionary data = root.DataDictionary;
            if (!data.TryGetValue("ok", TokenType.Boolean, out ok) || !ok.Boolean)
            {
                string error = StringValue(data, "error");
                DataToken current;
                if (error == "MEMO_CONFLICT" && data.TryGetValue("current", TokenType.DataDictionary, out current))
                {
                    _conflict = true; _latestMemo = StringValue(current.DataDictionary, "memo"); _latestRevision = NumberValue(current.DataDictionary, "memo_revision");
                    Message("他のスタッフが更新しました。下書きを残しています。「最新を読込」で再編集してください。");
                }
                else { if (responseAction == "staff_snapshot") ClearRows(); Message(error == "STAFF_REQUIRED" ? "スタッフ台帳に登録されていません。" : "取得・保存できませんでした: " + error); }
                return;
            }
            if (responseAction == "staff_snapshot")
            {
                DataToken customers;
                if (!data.TryGetValue("customers", TokenType.DataList, out customers)) { Message("一覧を読み取れませんでした。"); return; }
                string selected = Selected() == null ? "" : StringValue(Selected(), "customer_id");
                _rows = customers.DataList; _total = NumberValue(data, "total"); _offset = _askedOffset; _selected = 0;
                for (int i = 0; i < _rows.Count; i++) if (_rows[i].TokenType == TokenType.DataDictionary && StringValue(_rows[i].DataDictionary, "customer_id") == selected) _selected = i;
                RenderRows(); Message("営業日 " + StringValue(data, "business_date") + " / 30秒ごとに更新");
            }
            else if (responseAction == "update_memo")
            {
                _editing = false; _conflict = false;
                if (memoPanel != null) memoPanel.SetActive(false);
                if (memoInput != null) memoInput.text = "";
                RequestPage(_offset);
            }
        }
    }
}
