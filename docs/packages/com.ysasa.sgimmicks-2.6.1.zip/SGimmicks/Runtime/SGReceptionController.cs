using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using VRC.SDK3.Data;
using VRC.SDK3.StringLoading;
using VRC.SDK3.UdonNetworkCalling;
using VRC.Udon;
using VRC.Udon.Common.Interfaces;

namespace SGimmicks
{
    [UdonBehaviourSyncMode(BehaviourSyncMode.Manual)]
    public class SGReceptionController : UdonSharpBehaviour
    {
        public string worldId = "sg-reception-main";
        public string bridgeDisplayName = "";
        public VRCUrl bridgeUrl = new VRCUrl("http://127.0.0.1:22542/v1/state");
        [UdonSynced] public int bridgePlayerId = -1;
        public bool cloudConnected;
        public string localCustomerJson = "";

        private const string Protocol = "sgimmicks.reception.bridge.v1";
        private string _clientToken = "";
        private string _session = "";
        private int _counter;
        private bool _lookupStarted;
        private bool _bridge;
        private bool _loading;
        private float _pollAt;
        private float _lastHttp = -1000f;
        private int _bridgeIssue;
        private float _helloAt;
        private int _lastSequence;
        private string[] _ids = new string[8];
        private int[] _kinds = new int[8];
        private string[] _arguments = new string[8];
        private float[] _retryAt = new float[8];
        private UdonBehaviour[] _receivers = new UdonBehaviour[8];

        private string[] _outIds = new string[32];
        private string[] _outTokens = new string[32];
        private int[] _outPlayers = new int[32];
        private int[] _outSequences = new int[32];
        private string[] _outPayloads = new string[32];
        private int _outHead;
        private int _outCount;
        private int _sendPart;
        private int _sendOffset;
        private int _sendTotal;
        private float _sendAt;
        private string _assembleId = "";
        private int _assembleSequence;
        private int _assembleTotal;
        private int _assembleCount;
        private string[] _chunks = new string[192];
        private bool[] _chunkSeen = new bool[192];
        private string _completedJson = "";
        private string _completedRequestId = "";

        private void Start() { EnsureClient(); }

        private void EnsureClient()
        {
            VRCPlayerApi local = Networking.LocalPlayer;
            if (_clientToken != "" || !Utilities.IsValid(local)) return;
            _clientToken = "p" + local.playerId + "_" + Random.Range(10000000, 99999999) + "_" + Random.Range(10000000, 99999999);
        }

        private bool IsBridgeName(string value) { return bridgeDisplayName != null && bridgeDisplayName != "" && value == bridgeDisplayName; }

        private void Update()
        {
            EnsureClient();
            VRCPlayerApi local = Networking.LocalPlayer;
            if (!Utilities.IsValid(local)) return;
            if (!_lookupStarted && Submit(0, "{}", null) != "") _lookupStarted = true;
            if (IsBridgeName(local.displayName) && Time.time >= _pollAt && !_loading)
            {
                _pollAt = Time.time + 7f; _loading = true;
                VRCStringDownloader.LoadUrl(bridgeUrl, this);
            }
            if (Time.time - _lastHttp > 24f && _bridge) SetBridgeIssue(4);
            if (_bridge && Networking.IsOwner(gameObject))
            {
                if (Time.time >= _helloAt)
                {
                    _helloAt = Time.time + 15f;
                    string hello = EncodeRequest(_clientToken + "_hello", _clientToken, local.playerId, local.displayName, 4, "{}");
                    if (hello != "") Debug.Log("[SGReception] " + hello);
                }
                DispatchChunk();
            }
            for (int i = 0; i < _ids.Length; i++)
                if (_ids[i] != null && _ids[i] != "" && Time.time >= _retryAt[i]) SendPending(i);
        }

        public string Submit(int kind, string argumentsJson, UdonBehaviour receiver)
        {
            EnsureClient();
            if (_clientToken == "" || kind < 0 || kind > 3 || CanonicalArguments(kind, argumentsJson) == null) return "";
            for (int i = 0; i < _ids.Length; i++)
            {
                if (_ids[i] != null && _ids[i] != "") continue;
                _counter++;
                _ids[i] = _clientToken + "_r" + _counter;
                _kinds[i] = kind; _arguments[i] = argumentsJson; _receivers[i] = receiver;
                SendPending(i);
                return _ids[i];
            }
            return "";
        }

        private void SendPending(int index)
        {
            _retryAt[index] = Time.time + 20f;
            SendCustomNetworkEvent(NetworkEventTarget.Owner, nameof(NetRequest), _ids[index], _clientToken, _kinds[index], _arguments[index]);
        }

        private VRCPlayerApi Caller() { return NetworkCalling.InNetworkCall ? NetworkCalling.CallingPlayer : Networking.LocalPlayer; }

        [NetworkCallable(maxEventsPerSecond: 3)]
        public void NetRequest(string requestId, string token, int kind, string argumentsJson)
        {
            if (!_bridge || !Networking.IsOwner(gameObject) || kind < 0 || kind > 3) return;
            VRCPlayerApi caller = Caller();
            if (!Utilities.IsValid(caller) || !ValidId(token, 8, 96) || !ValidId(requestId, 8, 96) || !requestId.StartsWith(token + "_")) return;
            string json = EncodeRequest(requestId, token, caller.playerId, caller.displayName, kind, argumentsJson);
            if (json != "") Debug.Log("[SGReception] " + json);
        }

        private string KindName(int kind)
        {
            if (kind == 0) return "lookup";
            if (kind == 1) return "check_in";
            if (kind == 2) return "staff_snapshot";
            if (kind == 3) return "update_memo";
            if (kind == 4) return "hello";
            return "";
        }

        public bool IsLocalBridgeUser()
        {
            VRCPlayerApi local = Networking.LocalPlayer;
            return Utilities.IsValid(local) && IsBridgeName(local.displayName);
        }

        public string GetWaitMessage(bool detail)
        {
            if (!detail) return "応答を待っています。時間がかかる場合はスタッフにお知らせください。";
            if (_bridgeIssue == 2) return "シーンと補助ツールの設定が違います。このシーンからprofile.jsonを書き出し、補助ツールへ読み込んでください。";
            if (_bridgeIssue == 3) return "Unityと補助ツールの連携担当者が一致していません。設定を書き出し直して読み込んでください。";
            if (_bridgeIssue == 4) return "補助ツールに接続できません。起動状態とAllow Untrusted URLsを確認してください。";
            if (_bridgeIssue == 5) return "補助ツールの応答形式を確認できません。同じバージョンの補助ツールを使用してください。";
            if (bridgeDisplayName == null || bridgeDisplayName == "" || bridgeDisplayName == "連携担当者の表示名を設定")
                return "連携担当者の表示名が未設定です。Unityの受付設定で指定し、更新してください。";
            if (!IsLocalBridgeUser())
            {
                if (bridgePlayerId > 0) return "連携担当者から台帳の応答を待っています。時間がかかる場合は担当者に補助ツールの状態を確認してください。";
                return "連携担当者の接続を待っています。担当者の表示名と補助ツールを確認してください。";
            }
            if (!_bridge) return "補助ツールへの接続待ちです。このシーンのprofile.jsonを選択して連携を開始してください。";
            if (!cloudConnected) return "Googleとの接続待ちです。補助ツールの接続状態を確認してください。";
            return "台帳の応答を待っています。補助ツールの送信待ちとエラー表示を確認してください。";
        }

        private void SetBridgeIssue(int value)
        {
            if (value != 1) { _bridge = false; cloudConnected = false; }
            if (_bridgeIssue == value) return;
            _bridgeIssue = value;
            string code = "WAITING";
            if (value == 1) code = "CONNECTED";
            else if (value == 2) code = "WORLD_ID_MISMATCH";
            else if (value == 3) code = "BRIDGE_NAME_MISMATCH";
            else if (value == 4) code = "LOCAL_HTTP_UNAVAILABLE";
            else if (value == 5) code = "INVALID_BRIDGE_RESPONSE";
            Debug.Log("[SGReceptionStatus] " + code);
        }

        private string EncodeRequest(string requestId, string token, int player, string actor, int kind, string argumentsJson)
        {
            if (_session == "" || KindName(kind) == "") return "";
            DataDictionary args = CanonicalArguments(kind, argumentsJson);
            if (args == null) return "";
            DataDictionary value = new DataDictionary();
            value.Add("protocol", new DataToken(Protocol)); value.Add("world_id", new DataToken(worldId));
            value.Add("session", new DataToken(_session)); value.Add("request_id", new DataToken(requestId));
            value.Add("client_token", new DataToken(token)); value.Add("player_id", new DataToken(player));
            value.Add("actor_name", new DataToken(actor)); value.Add("action", new DataToken(KindName(kind)));
            value.Add("args", new DataToken(args));
            DataToken json;
            return VRCJson.TrySerializeToJson(value, JsonExportType.Minify, out json) ? json.String : "";
        }

        private DataDictionary CanonicalArguments(int kind, string json)
        {
            if (json == null || json.Length > 5000) return null;
            DataToken root;
            if (!VRCJson.TryDeserializeFromJson(json, out root) || root.TokenType != TokenType.DataDictionary) return null;
            DataDictionary source = root.DataDictionary;
            DataDictionary result = new DataDictionary();
            if (kind == 0 || kind == 1 || kind == 4) return source.Count == 0 ? result : null;
            DataToken token;
            DataList keys = source.GetKeys();
            for (int i = 0; i < keys.Count; i++)
            {
                string key = keys[i].String;
                if (kind == 2 && key != "offset" && key != "limit" && key != "business_date" && key != "revision") return null;
                if (kind == 3 && key != "customer_id" && key != "expected_revision" && key != "memo") return null;
            }
            if (kind == 2)
            {
                int offset = 0;
                if (source.TryGetValue("offset", out token))
                {
                    if (token.TokenType != TokenType.Double || token.Double < 0 || token.Double > 1000 || token.Double != (int)token.Double) return null;
                    offset = (int)token.Double;
                }
                if (source.TryGetValue("limit", out token) && (token.TokenType != TokenType.Double || token.Double != 6)) return null;
                result.Add("offset", new DataToken(offset)); result.Add("limit", new DataToken(6));
                if (source.TryGetValue("business_date", out token))
                {
                    if (token.TokenType != TokenType.String || token.String.Length != 10) return null;
                    result.Add("business_date", token);
                }
                if (source.TryGetValue("revision", out token))
                {
                    if (token.TokenType != TokenType.String || token.String.Length != 64) return null;
                    result.Add("revision", token);
                }
                return result;
            }
            if (kind == 3)
            {
                DataToken customer, revision, memo;
                if (source.Count != 3 || !source.TryGetValue("customer_id", TokenType.String, out customer) || !ValidId(customer.String, 3, 64) ||
                    !source.TryGetValue("expected_revision", TokenType.Double, out revision) || revision.Double < 0 || revision.Double > 10000 || revision.Double != (int)revision.Double ||
                    !source.TryGetValue("memo", TokenType.String, out memo) || memo.String.Length > 1000) return null;
                result.Add("customer_id", customer); result.Add("expected_revision", new DataToken((int)revision.Double)); result.Add("memo", memo);
                return result;
            }
            return null;
        }

        private bool ValidId(string value, int minimum, int maximum)
        {
            if (value == null || value.Length < minimum || value.Length > maximum) return false;
            for (int i = 0; i < value.Length; i++)
            {
                char c = value[i];
                if (!(c >= 'a' && c <= 'z') && !(c >= 'A' && c <= 'Z') && !(c >= '0' && c <= '9') && c != '_' && c != '-') return false;
            }
            return true;
        }

        public override void OnStringLoadSuccess(IVRCStringDownload result)
        {
            _loading = false;
            ApplyBridgeState(result.Result);
        }
        public override void OnStringLoadError(IVRCStringDownload result) { _loading = false; SetBridgeIssue(4); }

        private bool ApplyBridgeState(string json)
        {
            DataToken root;
            if (json == null || json.Length > 1200000 || !VRCJson.TryDeserializeFromJson(json, out root) || root.TokenType != TokenType.DataDictionary)
            { SetBridgeIssue(5); return false; }
            DataDictionary data = root.DataDictionary;
            DataToken protocol, world, name, session, cloud, replies;
            if (!data.TryGetValue("protocol", TokenType.String, out protocol) || protocol.String != Protocol ||
                !data.TryGetValue("world_id", TokenType.String, out world) ||
                !data.TryGetValue("bridge_display_name", TokenType.String, out name) ||
                !data.TryGetValue("session", TokenType.String, out session) || session.String.Length != 32 ||
                !data.TryGetValue("cloud_ok", TokenType.Boolean, out cloud) || !data.TryGetValue("replies", TokenType.DataList, out replies))
            { SetBridgeIssue(5); return false; }
            if (world.String != worldId) { SetBridgeIssue(2); return false; }
            if (!IsBridgeName(name.String)) { SetBridgeIssue(3); return false; }
            VRCPlayerApi local = Networking.LocalPlayer;
            if (!Utilities.IsValid(local) || local.displayName != name.String) return false;
            SetBridgeIssue(1);
            if (_session != session.String) { _session = session.String; _lastSequence = 0; _outHead = 0; _outCount = 0; _sendPart = 0; _sendOffset = 0; }
            _bridge = true; _lastHttp = Time.time; cloudConnected = cloud.Boolean;
            if (!Networking.IsOwner(gameObject)) Networking.SetOwner(local, gameObject);
            if (bridgePlayerId != local.playerId) { bridgePlayerId = local.playerId; RequestSerialization(); }
            DataList list = replies.DataList;
            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].TokenType != TokenType.DataDictionary) continue;
                DataDictionary packet = list[i].DataDictionary;
                DataToken seq, player, token, id, response;
                if (!packet.TryGetValue("sequence", TokenType.Double, out seq) || seq.Double <= _lastSequence || seq.Double > int.MaxValue ||
                    !packet.TryGetValue("player_id", TokenType.Double, out player) ||
                    !packet.TryGetValue("client_token", TokenType.String, out token) || !packet.TryGetValue("request_id", TokenType.String, out id) ||
                    !packet.TryGetValue("response", TokenType.DataDictionary, out response)) continue;
                bool duplicate = false;
                for (int q = 0; q < _outCount; q++) if (_outIds[(_outHead + q) % 32] == id.String && _outTokens[(_outHead + q) % 32] == token.String) duplicate = true;
                if (duplicate) { _lastSequence = (int)seq.Double; continue; }
                if (_outCount >= 32) break;
                DataToken encoded;
                if (!VRCJson.TrySerializeToJson(response, JsonExportType.Minify, out encoded) || encoded.String.Length > 153600) continue;
                int index = (_outHead + _outCount) % 32;
                _outIds[index] = id.String; _outTokens[index] = token.String; _outPlayers[index] = (int)player.Double;
                _outSequences[index] = (int)seq.Double; _outPayloads[index] = encoded.String; _outCount++;
                _lastSequence = (int)seq.Double;
            }
            return true;
        }

        private void DispatchChunk()
        {
            if (_outCount == 0 || Time.time < _sendAt) return;
            _sendAt = Time.time + 0.5f;
            if (_sendPart == 0) _sendTotal = ChunkCount(_outPayloads[_outHead]);
            int length = SafeChunkLength(_outPayloads[_outHead], _sendOffset);
            string part = _outPayloads[_outHead].Substring(_sendOffset, length);
            SendCustomNetworkEvent(NetworkEventTarget.All, nameof(NetReplyChunk), _outPlayers[_outHead], _outTokens[_outHead], _outIds[_outHead], _outSequences[_outHead], _sendPart, _sendTotal, part);
            _sendOffset += length;
            _sendPart++;
            if (_sendPart >= _sendTotal) { _outPayloads[_outHead] = ""; _outHead = (_outHead + 1) % 32; _outCount--; _sendPart = 0; _sendOffset = 0; }
        }

        private int SafeChunkLength(string value, int start)
        {
            int length = Mathf.Min(800, value.Length - start);
            if (start + length < value.Length && length > 0 && value[start + length - 1] >= '\uD800' && value[start + length - 1] <= '\uDBFF' && value[start + length] >= '\uDC00' && value[start + length] <= '\uDFFF') length--;
            return length;
        }

        private int ChunkCount(string value)
        {
            int count = 0, start = 0;
            while (start < value.Length) { start += SafeChunkLength(value, start); count++; }
            return count;
        }

        [NetworkCallable(maxEventsPerSecond: 5)]
        public void NetReplyChunk(int player, string token, string requestId, int sequence, int part, int total, string chunk)
        {
            VRCPlayerApi caller = Caller();
            if (!Utilities.IsValid(caller) || caller != Networking.GetOwner(gameObject) || !IsBridgeName(caller.displayName)) return;
            VRCPlayerApi local = Networking.LocalPlayer;
            if (!Utilities.IsValid(local) || local.playerId != player || token != _clientToken) return;
            AcceptChunk(requestId, sequence, part, total, chunk);
        }

        private bool AcceptChunk(string requestId, int sequence, int part, int total, string chunk)
        {
            int slot = -1;
            for (int i = 0; i < _ids.Length; i++) if (_ids[i] == requestId) slot = i;
            if (slot < 0 || total < 1 || total > 192 || part < 0 || part >= total || chunk == null || chunk.Length > 800) return false;
            if (_assembleId != requestId || _assembleSequence != sequence)
            {
                _assembleId = requestId; _assembleSequence = sequence; _assembleTotal = total; _assembleCount = 0;
                for (int i = 0; i < 192; i++) { _chunks[i] = ""; _chunkSeen[i] = false; }
            }
            if (_assembleTotal != total) return false;
            if (!_chunkSeen[part]) { _chunkSeen[part] = true; _chunks[part] = chunk; _assembleCount++; }
            if (_assembleCount != total) return true;
            string json = "";
            for (int i = 0; i < total; i++) json += _chunks[i];
            DataToken root, protocol;
            if (!VRCJson.TryDeserializeFromJson(json, out root) || root.TokenType != TokenType.DataDictionary ||
                !root.DataDictionary.TryGetValue("protocol", TokenType.String, out protocol) || protocol.String != "sgimmicks.reception.v1") return false;
            _completedJson = json; _completedRequestId = requestId;
            if (_kinds[slot] == 0) localCustomerJson = json;
            UdonBehaviour receiver = _receivers[slot];
            string action = KindName(_kinds[slot]);
            _ids[slot] = ""; _receivers[slot] = null;
            if (Utilities.IsValid(receiver))
            {
                receiver.SetProgramVariable("responseJson", json); receiver.SetProgramVariable("responseRequestId", requestId);
                receiver.SetProgramVariable("responseAction", action); receiver.SendCustomEvent("_OnReceptionResponse");
            }
            return true;
        }

        public override bool OnOwnershipRequest(VRCPlayerApi requestingPlayer, VRCPlayerApi requestedOwner)
        { return Utilities.IsValid(requestedOwner) && IsBridgeName(requestedOwner.displayName); }

        public override void OnPlayerLeft(VRCPlayerApi player)
        {
            if (Utilities.IsValid(player) && player.playerId == bridgePlayerId && Networking.IsMaster)
            { bridgePlayerId = -1; if (Networking.IsOwner(gameObject)) RequestSerialization(); }
        }
    }
}
