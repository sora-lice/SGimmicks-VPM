using UdonSharp;
using UnityEngine;
using VRC.SDKBase;

namespace SGimmicks
{
    [AddComponentMenu("SGimmicks/Intercom Slot")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.Manual)]
    public class SGIntercomSlot : UdonSharpBehaviour
    {
        public SGIntercomController controller;

        [UdonSynced] public int playerId = -1;
        [UdonSynced] public bool joined;
        [UdonSynced] public bool transmitting;
        [UdonSynced] public int transmittingHeartbeatServerTime;

        public override void OnDeserialization()
        {
            if (controller != null) controller.RefreshVoiceRouting();
        }

        public override void OnOwnershipTransferred(VRCPlayerApi player)
        {
            if (controller != null) controller.RefreshVoiceRouting();
        }

        public void ClaimForLocalPlayer()
        {
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(localPlayer) || !Networking.IsOwner(gameObject)) return;
            playerId = localPlayer.playerId;
            joined = true;
            transmitting = false;
            transmittingHeartbeatServerTime = 0;
            RequestSerialization();
            if (controller != null) controller.RefreshVoiceRouting();
        }

        public void SetLocalTransmitting(bool value)
        {
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(localPlayer) || !Networking.IsOwner(gameObject) ||
                playerId != localPlayer.playerId || !joined || transmitting == value) return;
            transmitting = value;
            transmittingHeartbeatServerTime = value ? Networking.GetServerTimeInMilliseconds() : 0;
            RequestSerialization();
            if (controller != null) controller.RefreshVoiceRouting();
        }

        public void RenewLocalTransmission()
        {
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(localPlayer) || !Networking.IsOwner(gameObject) ||
                playerId != localPlayer.playerId || !joined || !transmitting) return;
            transmittingHeartbeatServerTime = Networking.GetServerTimeInMilliseconds();
            RequestSerialization();
        }

        public void LeaveLocalPlayer()
        {
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(localPlayer) || !Networking.IsOwner(gameObject) ||
                playerId != localPlayer.playerId) return;
            joined = false;
            transmitting = false;
            transmittingHeartbeatServerTime = 0;
            RequestSerialization();
            if (controller != null) controller.RefreshVoiceRouting();
        }

        public void ClearIfOwnedAndInvalid()
        {
            if (!Networking.IsOwner(gameObject)) return;
            VRCPlayerApi player = VRCPlayerApi.GetPlayerById(playerId);
            if (!joined || Utilities.IsValid(player)) return;
            playerId = -1;
            joined = false;
            transmitting = false;
            transmittingHeartbeatServerTime = 0;
            RequestSerialization();
            if (controller != null) controller.RefreshVoiceRouting();
        }
    }
}
