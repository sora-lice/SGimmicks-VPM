using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using VRC.SDK3.Components;
using VRC.SDK3.UdonNetworkCalling;
using VRC.Udon.Common.Interfaces;

namespace SGimmicks
{
    [UdonBehaviourSyncMode(BehaviourSyncMode.Manual)]
    public class SGDrinkDeliveryController : UdonSharpBehaviour
    {
        public BoxCollider transferArea;
        public VRC_Pickup[] cargo;
        public VRCObjectSync[] cargoSync;
        public Rigidbody[] cargoBodies;
        public Collider[] cargoColliders;
        public Transform[] destinations;
        public string[] destinationLabels;
        public string[] drinks;
        public SGDrinkDeliveryApp[] apps;
        public string[] makerDisplayNames = new string[0];

        // One writer: the system owner. Clients request operations; they never take
        // ownership of the order queue. State, unlike events, survives late joins.
        [UdonSynced] public int[] orderIds = new int[32];
        [UdonSynced] public int[] orderViews = new int[32];
        [UdonSynced] public int[] orderDrinks = new int[32];
        [UdonSynced] public int[] orderStates = new int[32]; // 1 waiting, 2 moving, 3 delivered, 4 cancelled
        [UdonSynced] public string[] orderNames = new string[32];
        [UdonSynced] public int[] orderPlayers = new int[32];
        [UdonSynced] public int[] orderTokens = new int[32];
        [UdonSynced] public int nextOrderId = 1;
        [UdonSynced] public int revision;
        [UdonSynced] public string lastResult = "注文を受け付けています";
        [UdonSynced] public int[] transferTokens = new int[16];
        [UdonSynced] public int[] transferPlayers = new int[16];
        [UdonSynced] public int[] transferViews = new int[16];
        [UdonSynced] public int[] transferResults = new int[16];
        [UdonSynced] public int[] transferCounts = new int[16];
        [UdonSynced] public int transferHistoryIndex;

        private bool _busy;
        private bool[] _batch;
        private Vector3[] _positions;
        private Quaternion[] _rotations;
        private int _batchSlot = -1;
        private int _batchView;
        private int _batchPlayer;
        private int _batchToken;
        private int _batchDestination;
        private float _started;
        private float _nextCheck;
        private Vector3 _areaOrigin;
        private Quaternion _areaRotation;
        private Vector3 _targetPosition;
        private Quaternion _targetRotation;

        private void Start()
        {
            for (int i = 0; i < orderNames.Length; i++) if (orderNames[i] == null) orderNames[i] = "";
        }

        private VRCPlayerApi Caller()
        {
            return NetworkCalling.InNetworkCall ? NetworkCalling.CallingPlayer : Networking.LocalPlayer;
        }

        private bool ValidView(int index, VRCPlayerApi caller, bool maker)
        {
            if (!Utilities.IsValid(caller) || apps == null || index < 0 || index >= apps.Length ||
                apps[index] == null || apps[index].isMaker != maker) return false;
            VRC_Pickup tablet = apps[index].tabletPickup;
            if (tablet != null && tablet.IsHeld && Networking.GetOwner(tablet.gameObject) != caller) return false;
            return !maker || MakerAllowed(caller.displayName);
        }

        private bool MakerAllowed(string name)
        {
            if (makerDisplayNames == null || makerDisplayNames.Length == 0) return true;
            for (int i = 0; i < makerDisplayNames.Length; i++)
                if (makerDisplayNames[i] == name) return true;
            return false;
        }

        [NetworkCallable]
        public void NetOrder(int view, int drink, int token)
        {
            if (!Networking.IsOwner(gameObject)) return;
            VRCPlayerApi caller = Caller();
            if (!Utilities.IsValid(caller)) return;
            if (!ValidView(view, caller, false) || token <= 0 || drinks == null || drink < 0 || drink >= drinks.Length)
            { Reply(caller.playerId, view, token, -1, 0); return; }
            int slot = StoreOrder(view, drink, token, caller.playerId, caller.displayName);
            if (slot < 0) { Reply(caller.playerId, view, token, -2, 0); return; }
            Publish();
            Reply(caller.playerId, view, token, 1, orderIds[slot]);
        }

        private int StoreOrder(int view, int drink, int token, int player, string playerName)
        {
            for (int i = 0; i < orderIds.Length; i++)
                if (orderIds[i] != 0 && orderViews[i] == view && orderTokens[i] == token && orderPlayers[i] == player) return i;
            int slot = -1;
            int oldest = int.MaxValue;
            for (int i = 0; i < orderIds.Length; i++)
            {
                if (orderIds[i] == 0) { slot = i; break; }
                if (orderStates[i] >= 3 && orderIds[i] < oldest) { oldest = orderIds[i]; slot = i; }
            }
            if (slot < 0 || nextOrderId <= 0 || nextOrderId == int.MaxValue) return -1;
            orderIds[slot] = nextOrderId++;
            orderViews[slot] = view;
            orderDrinks[slot] = drink;
            orderTokens[slot] = token;
            orderPlayers[slot] = player;
            orderNames[slot] = playerName;
            orderStates[slot] = 1;
            return slot;
        }

        [NetworkCallable]
        public void NetTransfer(int view, int orderId, int destination, int token)
        {
            if (!Networking.IsOwner(gameObject)) return;
            VRCPlayerApi caller = Caller();
            if (!Utilities.IsValid(caller)) return;
            if (!ValidView(view, caller, true) || token <= 0) { Reply(caller.playerId, view, token, -1, 0); return; }
            int history = FindTransfer(view, caller.playerId, token);
            if (history >= 0) { Reply(caller.playerId, view, token, transferResults[history], transferCounts[history]); return; }
            if (_busy) { Reply(caller.playerId, view, token, -3, 0); return; }
            int slot = -1;
            if (orderId > 0)
            {
                slot = FindOrder(orderId);
                if (slot < 0 || orderStates[slot] != 1) { Reply(caller.playerId, view, token, -4, 0); return; }
                int sender = orderViews[slot];
                if (apps == null || sender < 0 || sender >= apps.Length || apps[sender] == null) { Reply(caller.playerId, view, token, -1, 0); return; }
                destination = apps[sender].destinationIndex;
            }
            if (destinations == null || destination < 0 || destination >= destinations.Length || destinations[destination] == null)
            { Reply(caller.playerId, view, token, -1, 0); return; }
            int prepared = PrepareBatch();
            if (prepared <= 0) { Reply(caller.playerId, view, token, prepared == -1 ? -5 : -6, 0); return; }
            _busy = true;
            _batchSlot = slot;
            _batchView = view; _batchPlayer = caller.playerId; _batchToken = token;
            _batchDestination = destination;
            _targetPosition = destinations[destination].position;
            _targetRotation = destinations[destination].rotation;
            _started = Time.time; _nextCheck = Time.time + 0.1f;
            if (slot >= 0) orderStates[slot] = 2;
            lastResult = "転送準備中…";
            Publish();
            for (int i = 0; i < cargo.Length; i++)
                if (_batch[i] && !Networking.IsOwner(cargo[i].gameObject)) Networking.SetOwner(Networking.LocalPlayer, cargo[i].gameObject);
        }

        private int PrepareBatch()
        {
            if (transferArea == null || !transferArea.enabled || !transferArea.gameObject.activeInHierarchy || cargo == null) return 0;
            int count = 0;
            _batch = new bool[cargo.Length];
            _positions = new Vector3[cargo.Length];
            _rotations = new Quaternion[cargo.Length];
            _areaOrigin = transferArea.transform.TransformPoint(transferArea.center);
            _areaRotation = transferArea.transform.rotation;
            for (int i = 0; i < cargo.Length; i++)
            {
                if (!CargoInside(i)) continue;
                // Block the whole batch rather than silently delivering half an order.
                if (cargo[i].IsHeld) return -1;
                _batch[i] = true; count++;
                _positions[i] = cargo[i].transform.position;
                _rotations[i] = cargo[i].transform.rotation;
            }
            return count;
        }

        public bool _PointInside(Vector3 point)
        {
            if (transferArea == null) return false;
            Vector3 local = transferArea.transform.InverseTransformPoint(point) - transferArea.center;
            Vector3 half = transferArea.size * 0.5f;
            return Mathf.Abs(local.x) <= half.x && Mathf.Abs(local.y) <= half.y && Mathf.Abs(local.z) <= half.z;
        }

        private bool CargoInside(int i)
        {
            return cargo[i] != null && cargo[i].gameObject.activeInHierarchy &&
                cargoColliders[i] != null && cargoColliders[i].enabled && _PointInside(cargoColliders[i].bounds.center);
        }

        private void Update() { TickTransfer(); }

        private void TickTransfer()
        {
            if (!_busy || Time.time < _nextCheck) return;
            _nextCheck = Time.time + 0.1f;
            if (!Networking.IsOwner(gameObject)) { _busy = false; return; }
            if (!BatchStillValid()) { FinishTransfer(-7, 0); return; }
            bool ready = true;
            for (int i = 0; i < cargo.Length; i++)
            {
                if (!_batch[i]) continue;
                if (!Networking.IsOwner(cargo[i].gameObject)) ready = false;
            }
            if (!ready)
            {
                if (Time.time - _started > 3f) FinishTransfer(-8, 0);
                return;
            }
            int count = CommitBatch();
            FinishTransfer(2, count);
        }

        private bool BatchStillValid()
        {
            if (destinations[_batchDestination] == null || transferArea == null || !transferArea.enabled ||
                !transferArea.gameObject.activeInHierarchy ||
                Vector3.Distance(destinations[_batchDestination].position, _targetPosition) > 0.01f ||
                Quaternion.Angle(destinations[_batchDestination].rotation, _targetRotation) > 0.1f ||
                Vector3.Distance(_areaOrigin, transferArea.transform.TransformPoint(transferArea.center)) > 0.01f ||
                Quaternion.Angle(_areaRotation, transferArea.transform.rotation) > 0.1f) return false;
            for (int i = 0; i < cargo.Length; i++)
                if (_batch[i] && (!CargoInside(i) || cargo[i].IsHeld || cargoSync[i] == null || cargoBodies[i] == null ||
                    Vector3.Distance(cargo[i].transform.position, _positions[i]) > 0.15f)) return false;
            return true;
        }

        private int CommitBatch()
        {
            int count = 0;
            Quaternion rotation = _targetRotation * Quaternion.Inverse(_areaRotation);
            for (int i = 0; i < cargo.Length; i++)
            {
                if (!_batch[i]) continue;
                Vector3 position = _targetPosition + rotation * (_positions[i] - _areaOrigin);
                Quaternion facing = rotation * _rotations[i];
                cargoSync[i].FlagDiscontinuity();
                cargoBodies[i].velocity = Vector3.zero;
                cargoBodies[i].angularVelocity = Vector3.zero;
                cargoBodies[i].position = position;
                cargoBodies[i].rotation = facing;
                cargo[i].transform.SetPositionAndRotation(position, facing);
                count++;
            }
            return count;
        }

        private void FinishTransfer(int code, int count)
        {
            if (_batchSlot >= 0) orderStates[_batchSlot] = code == 2 ? 3 : 1;
            RecordTransfer(_batchView, _batchPlayer, _batchToken, code, count);
            _busy = false;
            lastResult = code == 2 ? count + "個を「" + destinationLabels[_batchDestination] + "」へ転送しました" : "転送を中止しました。小物を置き直して再実行してください";
            Publish();
            Reply(_batchPlayer, _batchView, _batchToken, code, count);
        }

        private int FindTransfer(int view, int player, int token)
        {
            for (int i = 0; i < transferTokens.Length; i++)
                if (transferTokens[i] == token && token > 0 && transferPlayers[i] == player && transferViews[i] == view) return i;
            return -1;
        }

        private void RecordTransfer(int view, int player, int token, int code, int count)
        {
            int h = transferHistoryIndex % transferTokens.Length;
            transferTokens[h] = token; transferPlayers[h] = player;
            transferViews[h] = view; transferResults[h] = code; transferCounts[h] = count;
            transferHistoryIndex = (h + 1) % transferTokens.Length;
        }

        [NetworkCallable]
        public void NetCancel(int view, int orderId, int token)
        {
            if (!Networking.IsOwner(gameObject)) return;
            VRCPlayerApi caller = Caller();
            if (!Utilities.IsValid(caller) || !ValidView(view, caller, true)) return;
            int slot = FindOrder(orderId);
            if (slot >= 0 && orderStates[slot] == 4) { Reply(caller.playerId, view, token, 3, orderId); return; }
            if (slot < 0 || orderStates[slot] != 1) { Reply(caller.playerId, view, token, -4, 0); return; }
            orderStates[slot] = 4; Publish(); Reply(caller.playerId, view, token, 3, orderId);
        }

        public int _FindOrder(int id) { return FindOrder(id); }
        private int FindOrder(int id)
        {
            for (int i = 0; i < orderIds.Length; i++) if (orderIds[i] == id && id > 0) return i;
            return -1;
        }

        private void Publish() { revision++; RequestSerialization(); }
        private void Reply(int player, int view, int token, int code, int detail)
        {
            SendCustomNetworkEvent(NetworkEventTarget.All, nameof(NetReply), player, view, token, code, detail);
        }

        [NetworkCallable(maxEventsPerSecond: 20)]
        public void NetReply(int player, int view, int token, int code, int detail)
        {
            VRCPlayerApi caller = Caller();
            if (!Utilities.IsValid(caller) || caller != Networking.GetOwner(gameObject)) return;
            VRCPlayerApi local = Networking.LocalPlayer;
            if (!Utilities.IsValid(local) || local.playerId != player || apps == null || view < 0 || view >= apps.Length || apps[view] == null) return;
            apps[view]._ReceiveReply(token, code, detail);
        }

        public override void OnOwnershipTransferred(VRCPlayerApi player)
        {
            _busy = false;
            if (!Utilities.IsValid(player) || !player.isLocal) return;
            RecoverOrderStates();
            lastResult = "管理担当が切り替わりました。転送中だった物は現物を確認してください";
            Publish();
        }

        private void RecoverOrderStates()
        {
            for (int i = 0; i < orderStates.Length; i++) if (orderStates[i] == 2) orderStates[i] = 1;
        }

        public override bool OnOwnershipRequest(VRCPlayerApi requestingPlayer, VRCPlayerApi requestedOwner)
        {
            return requestingPlayer == Networking.GetOwner(gameObject);
        }
    }
}
