using UdonSharp;
using UnityEngine;
using UnityEngine.UI;
using VRC.SDK3.Data;
using VRC.Udon;

namespace SGimmicks
{
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class SGReceptionDisplay : UdonSharpBehaviour
    {
        public SGReceptionController controller;
        public UdonBehaviour callbackReceiver;
        public Text titleText;
        public Text nameText;
        public Text countText;
        public Text messageText;
        public string responseJson;
        public string responseRequestId;
        public string responseAction;
        private string _pendingId = "";
        private float _resetAt;
        private float _waitNoticeAt;

        private void Start() { Standby(); }
        private void Update()
        {
            if (_resetAt > 0f && Time.time >= _resetAt) Standby();
            if (_pendingId != "" && Time.time >= _waitNoticeAt && controller != null)
            {
                _waitNoticeAt = Time.time + 2f;
                if (titleText != null) titleText.text = "受付の応答待ち";
                if (messageText != null) messageText.text = controller.GetWaitMessage(controller.IsLocalBridgeUser());
            }
        }

        public void RequestReception()
        {
            if (_pendingId != "") return;
            if (controller == null || callbackReceiver == null) { ShowError(); return; }
            _pendingId = controller.Submit(1, "{}", callbackReceiver);
            if (_pendingId == "") { ShowError(); return; }
            _waitNoticeAt = Time.time + 8f;
            if (titleText != null) titleText.text = "受付中";
            if (nameText != null) nameText.text = "";
            if (countText != null) countText.text = "";
            if (messageText != null) messageText.text = "受付を確認しています。しばらくお待ちください。";
            _resetAt = 0f;
        }

        public void _OnReceptionResponse()
        {
            if (responseAction != "check_in" || responseRequestId != _pendingId) return;
            _pendingId = "";
            if (!ApplyGuestResponse(responseJson)) ShowError();
            _resetAt = Time.time + 30f;
        }

        private bool ApplyGuestResponse(string json)
        {
            DataToken root, ok, customer;
            if (json == null || !VRCJson.TryDeserializeFromJson(json, out root) || root.TokenType != TokenType.DataDictionary ||
                !root.DataDictionary.TryGetValue("ok", TokenType.Boolean, out ok) || !ok.Boolean ||
                !root.DataDictionary.TryGetValue("customer", TokenType.DataDictionary, out customer)) return false;
            DataToken name, count, message;
            if (!customer.DataDictionary.TryGetValue("display_name", TokenType.String, out name) ||
                !customer.DataDictionary.TryGetValue("count", TokenType.Double, out count) ||
                !customer.DataDictionary.TryGetValue("message", TokenType.String, out message)) return false;
            if (titleText != null) titleText.text = "受付が完了しました";
            if (nameText != null) nameText.text = name.String + " さん";
            if (countText != null) countText.text = "累計 " + (int)count.Double + " 回";
            if (messageText != null) messageText.text = message.String;
            return true;
        }

        private void ShowError()
        {
            if (titleText != null) titleText.text = "受付を確認できませんでした";
            if (nameText != null) nameText.text = "";
            if (countText != null) countText.text = "";
            if (messageText != null) messageText.text = "お手数ですが、スタッフにお知らせください。";
            _resetAt = Time.time + 30f;
        }

        private void Standby()
        {
            _resetAt = 0f;
            if (titleText != null) titleText.text = "カード受付";
            if (nameText != null) nameText.text = "";
            if (countText != null) countText.text = "";
            if (messageText != null) messageText.text = "カードを持って、読取機にタッチしてください。";
        }
    }
}
