using UdonSharp;
using UnityEngine;
using VRC.SDKBase;

namespace SGimmicks
{
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class SGReceptionReader : UdonSharpBehaviour
    {
        public VRC_Pickup[] cards;
        public SGReceptionDisplay display;
        public BoxCollider readArea;
        private bool _touching;
        private float _nextTouch;
        private float _nextPoll;

        private bool Contains(Vector3 position)
        {
            Vector3 point = readArea.transform.InverseTransformPoint(position) - readArea.center;
            Vector3 half = readArea.size * .5f;
            return Mathf.Abs(point.x) <= half.x && Mathf.Abs(point.y) <= half.y && Mathf.Abs(point.z) <= half.z;
        }

        private void Update()
        {
            if (Time.time < _nextPoll) return;
            _nextPoll = Time.time + .1f;
            bool inside = false;
            if (readArea != null && readArea.enabled && readArea.gameObject.activeInHierarchy && cards != null)
            {
                for (int i = 0; i < cards.Length; i++)
                {
                    VRC_Pickup card = cards[i];
                    if (card == null || !card.IsHeld || !card.gameObject.activeInHierarchy) continue;
                    VRCPlayerApi owner = Networking.GetOwner(card.gameObject);
                    if (Utilities.IsValid(owner) && owner.isLocal && Contains(card.transform.position)) inside = true;
                }
            }
            if (inside && !_touching && Time.time >= _nextTouch && display != null)
            { _nextTouch = Time.time + 1.5f; display.RequestReception(); }
            _touching = inside;
        }
    }
}
