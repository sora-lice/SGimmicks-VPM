using UdonSharp;
using UnityEngine;
using VRC.SDKBase;

namespace SGimmicks
{
    [AddComponentMenu("SGimmicks/Local Auto Door")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class SGLocalAutoDoorController : UdonSharpBehaviour
    {
        [Header("検知範囲（このコンポーネントと同じオブジェクト）")]
        public BoxCollider detectionArea;
        [Header("扉")]
        public Transform firstDoor;
        public bool doubleDoor;
        public Transform secondDoor;
        [Tooltip("各扉の親オブジェクトの座標系での移動量。親のScaleの影響を受けます。")]
        public Vector3 firstOpenOffset = new Vector3(-1f, 0f, 0f);
        public Vector3 secondOpenOffset = new Vector3(1f, 0f, 0f);
        [Min(0.01f)] public float openingDuration = 0.8f;
        [Min(0.01f)] public float closingDuration = 0.8f;
        [Min(0f)] public float closeDelay = 1f;

        private Vector3 _firstClosedPosition;
        private Vector3 _secondClosedPosition;
        private bool _initialized;
        private bool _inside;
        private float _lastLocalStayTime;
        private float _closeAt;
        private float _openAmount;

        private void Start()
        {
            InitializeDoor();
        }

        private void InitializeDoor()
        {
            if (_initialized) return;
            if (firstDoor != null) _firstClosedPosition = firstDoor.localPosition;
            if (secondDoor != null) _secondClosedPosition = secondDoor.localPosition;
            _initialized = true;
        }

        public override void OnPlayerTriggerEnter(VRCPlayerApi player)
        {
            if (!Utilities.IsValid(player) || !player.isLocal) return;
            SetLocalPresence(true);
        }

        public override void OnPlayerTriggerStay(VRCPlayerApi player)
        {
            if (!Utilities.IsValid(player) || !player.isLocal) return;
            // Stay also recovers entry after a teleport/spawning inside the area.
            SetLocalPresence(true);
        }

        public override void OnPlayerTriggerExit(VRCPlayerApi player)
        {
            if (!Utilities.IsValid(player) || !player.isLocal) return;
            SetLocalPresence(false);
        }

        public override void OnPlayerRespawn(VRCPlayerApi player)
        {
            if (!Utilities.IsValid(player) || !player.isLocal) return;
            SetLocalPresence(false);
        }

        private void SetLocalPresence(bool inside)
        {
            InitializeDoor();
            if (inside) _lastLocalStayTime = Time.time;
            if (_inside == inside) return;
            _inside = inside;
            if (!inside) _closeAt = Time.time + Mathf.Max(0f, closeDelay);
        }

        private void Update()
        {
            TickDoor();
        }

        private void TickDoor()
        {
            if (!_initialized) InitializeDoor();
            // Trigger Exit may be skipped on teleport. Do not leave the door stuck open.
            if (_inside && Time.time - _lastLocalStayTime > 1f)
            {
                if (LocalPlayerStillInArea()) _lastLocalStayTime = Time.time;
                else SetLocalPresence(false);
            }
            AdvanceDoor(Time.deltaTime);
        }

        private bool LocalPlayerStillInArea()
        {
            VRCPlayerApi player = Networking.LocalPlayer;
            if (!Utilities.IsValid(player) || detectionArea == null || !detectionArea.enabled ||
                !detectionArea.gameObject.activeInHierarchy) return false;
            Vector3 feet = player.GetPosition() + Vector3.up * 0.2f;
            Vector3 head = player.GetTrackingData(VRCPlayerApi.TrackingDataType.Head).position;
            Vector3 middle = (feet + head) * 0.5f;
            // Small tolerance approximates the player's capsule; not an avatar mesh test.
            return (detectionArea.ClosestPoint(feet) - feet).sqrMagnitude < 0.0625f ||
                (detectionArea.ClosestPoint(middle) - middle).sqrMagnitude < 0.0625f ||
                (detectionArea.ClosestPoint(head) - head).sqrMagnitude < 0.0625f;
        }

        private void AdvanceDoor(float deltaTime)
        {
            float target = _inside || Time.time < _closeAt ? 1f : 0f;
            float duration = target > _openAmount ? openingDuration : closingDuration;
            float next = Mathf.MoveTowards(_openAmount, target, deltaTime / Mathf.Max(0.01f, duration));
            if (next == _openAmount) return;
            _openAmount = next;
            float eased = Mathf.SmoothStep(0f, 1f, _openAmount);
            if (firstDoor != null) firstDoor.localPosition = _firstClosedPosition + firstOpenOffset * eased;
            if (doubleDoor && secondDoor != null)
                secondDoor.localPosition = _secondClosedPosition + secondOpenOffset * eased;
        }

        private void OnDisable()
        {
            ResetDoor();
        }

        private void ResetDoor()
        {
            if (!_initialized) return;
            if (firstDoor != null) firstDoor.localPosition = _firstClosedPosition;
            if (doubleDoor && secondDoor != null) secondDoor.localPosition = _secondClosedPosition;
            _inside = false;
            _openAmount = 0f;
            _closeAt = 0f;
        }
    }
}
