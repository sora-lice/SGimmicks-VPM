using UdonSharp;
using UnityEngine;
using UnityEngine.UI;
using VRC.SDKBase;
using VRC.Udon.Common.Interfaces;

namespace SGimmicks
{
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class SGDrinkDeliveryApp : UdonSharpBehaviour
    {
        public SGDrinkDeliveryController controller;
        public bool isMaker;
        public string tabletLabel = "注文タブレット";
        public int destinationIndex;
        public int viewIndex;
        public VRC_Pickup tabletPickup;
        public Text titleText;
        public Text selectionText;
        public Text listText;
        public Text modeText;
        public Text statusText;

        private int _drink;
        private int _destination;
        private int _selectedOrder;
        private bool _manual;
        private int _seenRevision = -1;
        private int[] _pendingIds = new int[32];
        private int _pendingCount;
        private int _pendingToken;
        private int _pendingKind;
        private int _argument;
        private int _argumentDestination;
        private float _retryAt;
        private float _messageUntil;
        private float _nextTick;

        private void Start() { _Refresh(); }
        private void OnEnable() { _seenRevision = -1; }
        private void Update()
        {
            if (Time.time < _nextTick) return;
            _nextTick = Time.time + 0.5f;
            if (controller == null) return;
            if (_seenRevision != controller.revision) _Refresh();
            if (_pendingKind != 0 && Time.time >= _retryAt && statusText != null)
                statusText.text = "応答待ちです。同じ実行ボタンで再送できます";
            else if (_pendingKind == 0 && Time.time >= _messageUntil && statusText != null)
                statusText.text = controller.lastResult;
        }

        public void _Previous()
        {
            if (controller == null) return;
            if (!isMaker) _drink = Wrap(_drink - 1, controller.drinks.Length);
            else if (_manual) _destination = Wrap(_destination - 1, controller.destinations.Length);
            else SelectOrder(-1);
            _Refresh();
        }
        public void _Next()
        {
            if (controller == null) return;
            if (!isMaker) _drink = Wrap(_drink + 1, controller.drinks.Length);
            else if (_manual) _destination = Wrap(_destination + 1, controller.destinations.Length);
            else SelectOrder(1);
            _Refresh();
        }
        private int Wrap(int value, int count) { return count <= 0 ? 0 : (value % count + count) % count; }
        private string Short(string value, int length) { return value == null ? "" : value.Length <= length ? value : value.Substring(0, length) + "…"; }
        private void SelectOrder(int direction)
        {
            if (_pendingCount == 0) { _selectedOrder = 0; return; }
            int index = 0;
            for (int i = 0; i < _pendingCount; i++) if (_pendingIds[i] == _selectedOrder) index = i;
            _selectedOrder = _pendingIds[Wrap(index + direction, _pendingCount)];
        }
        public void _ToggleMode() { _manual = !_manual; _Refresh(); }
        public void _Submit()
        {
            if (controller == null) return;
            _Refresh();
            if (!isMaker) BeginRequest(1, _drink, 0);
            else if (_manual) BeginRequest(2, 0, _destination);
            else if (_selectedOrder > 0) BeginRequest(2, _selectedOrder, 0);
            else Message("配送する注文がありません。「手動転送」なら注文なしで送れます");
        }
        public void _CancelOrder()
        {
            if (isMaker && !_manual && _selectedOrder > 0) BeginRequest(3, _selectedOrder, 0);
        }
        private void BeginRequest(int kind, int argument, int destination)
        {
            VRCPlayerApi local = Networking.LocalPlayer;
            if (!Utilities.IsValid(local)) return;
            if (tabletPickup != null && tabletPickup.IsHeld && !Networking.IsOwner(tabletPickup.gameObject))
            { Message("他の人が持っているタブレットは操作できません"); return; }
            if (_pendingKind != 0)
            {
                if (_pendingKind != kind || Time.time < _retryAt) { Message("前の操作の確認待ちです"); return; }
            }
            else
            {
                _pendingKind = kind;
                _pendingToken = Random.Range(1, int.MaxValue);
                _argument = argument; _argumentDestination = destination;
            }
            _retryAt = Time.time + 12f;
            Message("送信・確認中…");
            if (kind == 1) controller.SendCustomNetworkEvent(NetworkEventTarget.Owner, nameof(SGDrinkDeliveryController.NetOrder), viewIndex, _argument, _pendingToken);
            else if (kind == 2) controller.SendCustomNetworkEvent(NetworkEventTarget.Owner, nameof(SGDrinkDeliveryController.NetTransfer), viewIndex, _argument, _argumentDestination, _pendingToken);
            else controller.SendCustomNetworkEvent(NetworkEventTarget.Owner, nameof(SGDrinkDeliveryController.NetCancel), viewIndex, _argument, _pendingToken);
        }

        public void _ReceiveReply(int token, int code, int detail)
        {
            if (_pendingKind == 0 || token != _pendingToken) return;
            _pendingKind = 0;
            if (code == 1) Message("注文 #" + detail + " を受け付けました");
            else if (code == 2) Message(detail + "個を転送しました");
            else if (code == 3) Message("注文 #" + detail + " を取り消しました");
            else if (code == -1) Message("操作権限またはUnityの登録設定を確認してください");
            else if (code == -2) Message("注文が満杯です（未完了32件）。完了後に再注文してください");
            else if (code == -3) Message("別の転送を処理中です。完了後に再実行してください");
            else if (code == -4) Message("その注文は処理済みか、他の担当者が配送中です");
            else if (code == -5) Message("エリア内に持たれている物があります。全部置いてください");
            else if (code == -6) Message("転送エリアに登録済みの小物がありません");
            else if (code == -8) Message("小物の所有権を取得できませんでした。置き直して再実行してください");
            else Message("転送中に小物や範囲が変わりました。確認して再実行してください");
            _Refresh();
        }

        private void Message(string text)
        {
            if (statusText != null) statusText.text = text;
            _messageUntil = Time.time + 8f;
        }

        public void _Refresh()
        {
            if (controller == null) return;
            _seenRevision = controller.revision;
            if (titleText != null) titleText.text = isMaker ? "ドリンク作成・配送" : tabletLabel + " ／ ドリンク注文";
            if (!isMaker)
            {
                if (selectionText != null) selectionText.text = controller.drinks.Length > 0 ? controller.drinks[_drink] : "ドリンク未登録";
                if (modeText != null) modeText.text = "受け取り先：" + controller.destinationLabels[destinationIndex];
                string summary = "このタブレットの未完了注文\n";
                int count = 0;
                for (int i = 0; i < controller.orderIds.Length; i++)
                    if (controller.orderIds[i] > 0 && controller.orderViews[i] == viewIndex && controller.orderStates[i] <= 2)
                    { count++; if (count <= 6) summary += "#" + controller.orderIds[i] + " " + Short(controller.drinks[controller.orderDrinks[i]], 20) + (controller.orderStates[i] == 2 ? "（配送中）" : "（受付済み）") + "\n"; }
                if (listText != null) listText.text = count == 0 ? summary + "まだありません" : summary + (count > 6 ? "ほか " + (count - 6) + "件" : "");
                return;
            }
            _pendingCount = 0;
            // Stable ID ordering even after completed slots have been recycled.
            for (int i = 0; i < controller.orderIds.Length; i++)
            {
                if (controller.orderIds[i] <= 0 || controller.orderStates[i] != 1) continue;
                int id = controller.orderIds[i];
                int at = _pendingCount;
                while (at > 0 && _pendingIds[at - 1] > id) { _pendingIds[at] = _pendingIds[at - 1]; at--; }
                _pendingIds[at] = id; _pendingCount++;
            }
            int selected = controller._FindOrder(_selectedOrder);
            if (selected < 0 || controller.orderStates[selected] != 1) _selectedOrder = _pendingCount > 0 ? _pendingIds[0] : 0;
            selected = controller._FindOrder(_selectedOrder);
            int selectedIndex = 0;
            for (int i = 0; i < _pendingCount; i++) if (_pendingIds[i] == _selectedOrder) selectedIndex = i;
            int page = selectedIndex / 6;
            string list = "未配送 " + _pendingCount + "件（" + (page + 1) + "ページ）\n";
            for (int i = page * 6; i < Mathf.Min(_pendingCount, page * 6 + 6); i++)
            {
                int s = controller._FindOrder(_pendingIds[i]);
                SGDrinkDeliveryApp sender = controller.apps[controller.orderViews[s]];
                list += (_pendingIds[i] == _selectedOrder ? "> " : "  ") + "#" + _pendingIds[i] + " " + Short(sender.tabletLabel, 8) + " / " + Short(controller.orderNames[s], 8) + " / " + Short(controller.drinks[controller.orderDrinks[s]], 10) + "\n";
            }
            if (listText != null) listText.text = _pendingCount == 0 ? "未配送の注文はありません" : list;
            if (modeText != null) modeText.text = _manual ? "手動転送：転送先を選択" : "注文配送：前へ／次へで注文を選択";
            if (selectionText != null)
                selectionText.text = _manual ? controller.destinationLabels[_destination] : selected >= 0 ?
                    "#" + _selectedOrder + " " + controller.apps[controller.orderViews[selected]].tabletLabel + " / " + controller.orderNames[selected] + "\n" + controller.drinks[controller.orderDrinks[selected]] + " → " + controller.destinationLabels[controller.apps[controller.orderViews[selected]].destinationIndex] : "注文未選択";
        }
    }
}
