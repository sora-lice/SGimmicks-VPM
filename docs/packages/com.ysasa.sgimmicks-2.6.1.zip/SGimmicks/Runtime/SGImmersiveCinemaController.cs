using UdonSharp;
using UnityEngine;

namespace SGimmicks
{
    [AddComponentMenu("SGimmicks/Immersive Cinema")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class SGImmersiveCinemaController : UdonSharpBehaviour
    {
        [Header("部屋の範囲（Zプラスが正面）")]
        public BoxCollider roomBounds;
        public UdonSharpBehaviour vizVidCore;
        public GameObject generatedPlayer;
        public UdonSharpBehaviour audioLink;
        [Range(0.2f, 0.98f)] public float screenWidthRatio = 0.9f;
        [Range(0.2f, 0.95f)] public float screenHeightRatio = 0.72f;
        [Range(0.1f, 0.95f)] public float sideLengthRatio = 0.75f;
        [Range(45f, 110f)] public float sideAngle = 90f;
        public float screenHeightOffset;
        [Header("映像の疑似拡張（新しい景色は生成しません）")]
        [Range(0.02f, 0.5f)] public float edgeSampleWidth = 0.18f;
        [Range(0f, 0.05f)] public float sideBlur = 0.006f;
        [Range(0f, 2f)] public float screenBrightness = 1f;
        [Header("3面の外周と背面へぼかした映像を投影")]
        [Range(0.05f, 5f)] public float ambientSpread = 1f;
        [Range(0f, 0.2f)] public float ambientBlur = 0.045f;
        [Range(0f, 2f)] public float ambientBrightness = 0.5f;
        [Range(0f, 1f)] public float audioReactiveStrength = 0.15f;
        [Range(0.2f, 5f)] public float projectionDepth = 1.2f;
        public bool projectOntoWalls = true;
        [Header("疑似立体音響・PC AVPro専用")]
        [Range(0f, 1f)] public float frontVolume = 0.3f;
        [Range(0f, 1f)] public float sideVolume = 0.1f;
        [Range(0f, 1f)] public float rearVolume = 0.07f;
        [Range(0f, 1f)] public float ceilingVolume = 0.03f;

        [HideInInspector] public string assetFolder;
        [HideInInspector] public Renderer[] screens;
        [HideInInspector] public Renderer[] ambientScreens;
        [HideInInspector] public Material[] screenMaterials;
        [HideInInspector] public Material[] ambientMaterials;
        [HideInInspector] public Material[] projectionMaterials;
        [HideInInspector] public Transform[] projectionTransforms;
        [HideInInspector] public AudioSource[] speakers;
        [HideInInspector] public UdonSharpBehaviour[] speakerControllers;
        [HideInInspector] public UdonSharpBehaviour connectedCore;
        [HideInInspector] public AudioSource[] previousCoreSources;
        [HideInInspector] public UdonSharpBehaviour[] previousCoreControllers;
        [HideInInspector] public AudioSource[] mutedOriginalSources;
        [HideInInspector] public bool[] previousSourceEnabled;
        [HideInInspector] public UdonSharpBehaviour[] connectedHandlers;
        [HideInInspector] public AudioSource[] previousPrimaryLeft;
        [HideInInspector] public AudioSource[] previousPrimaryRight;
        [HideInInspector] public UdonSharpBehaviour previousAudioLink;
        [HideInInspector] public UdonSharpBehaviour linkedAudioLink;
        [HideInInspector] public AudioSource previousAudioLinkSource;
        [HideInInspector] public AudioSource previousAudioLinkRightSource;

        private float _nextProjectionUpdate;

        private void Update()
        {
            if (Time.time < _nextProjectionUpdate) return;
            _nextProjectionUpdate = Time.time + 0.25f;
            RefreshProjectionBounds();
        }

        public void RefreshProjectionBounds()
        {
            if (projectionTransforms == null || projectionMaterials == null) return;
            for (int i = 0; i < projectionTransforms.Length && i < projectionMaterials.Length; i++)
            {
                Transform t = projectionTransforms[i];
                Material m = projectionMaterials[i];
                if (t == null || m == null) continue;
                Vector3 p = t.position;
                Vector3 f = t.forward;
                m.SetVector("_ProjectionOrigin", new Vector4(p.x, p.y, p.z, 1f));
                m.SetVector("_ProjectionDirection", new Vector4(f.x, f.y, f.z, 0f));
                m.SetFloat("_ProjectionDepth", projectionDepth + 0.05f);
            }
        }
    }
}
