using UdonSharp;
using UnityEngine;
using VRC.SDK3.Components;

namespace SGimmicks
{
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class SGFixedInstancePortal : UdonSharpBehaviour
    {
        [Tooltip("GameObject全体を非アクティブにしたポータルのテンプレート")]
        public GameObject inactiveTemplate;
        [TextArea(2, 5)] public string destinationRoomId;
        [Tooltip("有効化した後にRefreshPortalを呼びます。OFF/ONを別々に実機検証してください。")]
        public bool refreshAfterActivation;

        private GameObject _portal;

        private void Start()
        {
            RecreatePortal();
        }

        public void RecreatePortal()
        {
            if (inactiveTemplate == null || inactiveTemplate.activeSelf ||
                string.IsNullOrEmpty(destinationRoomId))
            {
                Debug.LogError("[SGimmicks Portal] 非アクティブのテンプレートと完全なRoom IDを設定してください。");
                return;
            }
            string room = destinationRoomId.Trim();
            if (!room.StartsWith("wrld_") || room.IndexOf(":") < 0)
            {
                Debug.LogError("[SGimmicks Portal] 行き先にはワールドIDとインスタンスIDの両方が必要です。");
                return;
            }
            if (inactiveTemplate.GetComponent<VRCPortalMarker>() == null)
            {
                Debug.LogError("[SGimmicks Portal] テンプレートにVRCPortalMarkerがありません。");
                return;
            }
            if (_portal != null)
            {
                _portal.SetActive(false);
                Destroy(_portal);
            }
            // 初期化前に設定するため、GameObject全体が無効なテンプレートを複製します。
            _portal = Instantiate(inactiveTemplate);
            _portal.name = "SGFixedInstancePortal_Local";
            _portal.transform.SetParent(null);
            _portal.transform.SetPositionAndRotation(transform.position, transform.rotation);
            VRCPortalMarker marker = _portal.GetComponent<VRCPortalMarker>();
            marker.roomId = room;
            marker.enabled = true;
            _portal.SetActive(true);
            if (refreshAfterActivation) marker.RefreshPortal();
            Debug.Log("[SGimmicks Portal] 検証用ポータルを生成しました。到着先のインスタンスIDは実機で確認してください。");
        }
    }
}
