using UdonSharp;
using UnityEngine;
using UnityEngine.UI;
using VRC.SDKBase;
using VRC.Udon.Common;

namespace SGimmicks
{
    [AddComponentMenu("SGimmicks/Intercom Controller")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class SGIntercomController : UdonSharpBehaviour
    {
        [Header("同期スロット")]
        public SGIntercomSlot[] slots;

        [Header("右トリガー")]
        [Range(0.2f, 0.8f)] public float doubleTapWindow = 0.45f;

        [Header("内線音声距離")]
        public float intercomVoiceNear = 1000000f;
        public float intercomVoiceFar = 1000000f;
        public float isolatedVoiceNear = 0f;
        public float isolatedVoiceFar = 0f;
        public float normalVoiceNear = 0f;
        public float normalVoiceFar = 25f;

        [Header("操作パネル")]
        public Text membershipButtonText;
        public Text participantCountText;
        public Text statusText;
        public GameObject transmitIndicator;

        [Header("本人専用の右手首表示")]
        public GameObject localWristIndicatorRoot;
        public Transform localWristIndicatorTransform;
        public float wristHeightOffset = 0.15f;

        private SGIntercomSlot _localSlot;
        private bool _localJoined;
        private bool _localTransmitting;
        private bool _rightTriggerHeld;
        private bool _awaitingSecondPress;
        private float _firstTriggerDown;
        private float _nextHeartbeat;
        private float _nextMaintenance;
        private bool _routingEnabled = true;
        private VRCPlayerApi[] _modifiedPlayers = new VRCPlayerApi[80];
        private float[] _previousVoiceNear = new float[80];
        private float[] _previousVoiceFar = new float[80];

        private void Start()
        {
            RefreshVoiceRouting();
            _nextMaintenance = Time.time + 0.5f;
        }

        private void OnEnable()
        {
            _routingEnabled = true;
            _nextMaintenance = Time.time;
        }

        private void OnDisable()
        {
            DisableRouting();
        }

        private void DisableRouting()
        {
            _routingEnabled = false;
            StopLocalTransmission();
            ResetTriggerSequence();
            RestoreAllVoices();
            UpdatePanel();
        }

        private void Update()
        {
            if (_localTransmitting)
            {
                VRCPlayerApi localPlayer = Networking.LocalPlayer;
                if (!_rightTriggerHeld || !_localJoined || _localSlot == null ||
                    !Utilities.IsValid(localPlayer) || !localPlayer.IsUserInVR() ||
                    !_localSlot.joined || !_localSlot.transmitting || _localSlot.playerId != localPlayer.playerId ||
                    !Networking.IsOwner(_localSlot.gameObject))
                {
                    StopLocalTransmission();
                    ResetTriggerSequence();
                }
                else if (Time.time >= _nextHeartbeat)
                {
                    _localSlot.RenewLocalTransmission();
                    _nextHeartbeat = Time.time + 0.75f;
                }
            }
            if (Time.time >= _nextMaintenance)
            {
                _nextMaintenance = Time.time + 0.5f;
                Maintenance();
            }
        }

        private void LateUpdate()
        {
            UpdateWristIndicator();
        }

        private void UpdateWristIndicator()
        {
            if (!_localTransmitting || localWristIndicatorTransform == null) return;
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(localPlayer)) return;
            VRCPlayerApi.TrackingData head = localPlayer.GetTrackingData(VRCPlayerApi.TrackingDataType.Head);
            VRCPlayerApi.TrackingData hand = localPlayer.GetTrackingData(VRCPlayerApi.TrackingDataType.RightHand);
            Vector3 handPosition = localPlayer.GetBonePosition(HumanBodyBones.RightHand);
            Vector3 forearm = handPosition - localPlayer.GetBonePosition(HumanBodyBones.RightLowerArm);
            if (forearm.sqrMagnitude < 0.0025f || forearm.sqrMagnitude > 1f)
            {
                handPosition = hand.position;
                forearm = handPosition - head.position;
            }
            Vector3 position = handPosition - forearm.normalized * 0.04f +
                Vector3.up * Mathf.Max(0f, wristHeightOffset);
            localWristIndicatorTransform.SetPositionAndRotation(position, head.rotation);
        }

        public override void OnPlayerJoined(VRCPlayerApi player)
        {
            SendCustomEventDelayedFrames(nameof(RefreshVoiceRouting), 2);
        }

        public override void OnPlayerLeft(VRCPlayerApi player)
        {
            SendCustomEventDelayedFrames(nameof(Maintenance), 2);
        }

        public override void InputUse(bool value, UdonInputEventArgs args)
        {
            if (args.handType != HandType.RIGHT) return;
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(localPlayer) || !localPlayer.IsUserInVR()) return;

            ProcessRightTrigger(value);
        }

        private void ProcessRightTrigger(bool value)
        {
            // Count physical rising edges, never repeated true events while held.
            if (_rightTriggerHeld == value) return;
            _rightTriggerHeld = value;
            if (!_localJoined || _localSlot == null) return;

            if (!value)
            {
                if (_localTransmitting)
                {
                    StopLocalTransmission();
                    _awaitingSecondPress = false;
                    SetStatus("待機中：2回押しの2回目を長押しで送話");
                }
                UpdatePanel();
                return;
            }

            float now = Time.time;
            if (_awaitingSecondPress && now - _firstTriggerDown <= doubleTapWindow)
            {
                _awaitingSecondPress = false;
                _localSlot.SetLocalTransmitting(true);
                _localTransmitting = _localSlot.transmitting;
                _nextHeartbeat = now + 0.75f;
                SetStatus(_localTransmitting ? "内線中…：参加者全員へ送話" : "送話できません。参加し直してください");
            }
            else
            {
                _awaitingSecondPress = true;
                _firstTriggerDown = now;
                SetStatus("もう一度押し、そのまま長押しで送話");
            }
            UpdatePanel();
        }

        private void StopLocalTransmission()
        {
            _localTransmitting = false;
            if (_localSlot != null) _localSlot.SetLocalTransmitting(false);
            UpdatePanel();
        }

        private void ResetTriggerSequence()
        {
            _rightTriggerHeld = false;
            _awaitingSecondPress = false;
            _firstTriggerDown = -10f;
        }

        public void ToggleParticipation()
        {
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(localPlayer)) return;
            if (!localPlayer.IsUserInVR())
            {
                SetStatus("この内線はPCVR専用です");
                return;
            }

            FindLocalSlot();
            if (_localJoined && _localSlot != null)
            {
                StopLocalTransmission();
                _localSlot.LeaveLocalPlayer();
                _localJoined = false;
                ResetTriggerSequence();
                _localSlot = null;
                SetStatus("内線から退出しました");
                RefreshVoiceRouting();
                return;
            }

            SGIntercomSlot freeSlot = FindAvailableSlot();
            if (freeSlot == null)
            {
                SetStatus("内線の参加枠が満員です");
                return;
            }

            Networking.SetOwner(localPlayer, freeSlot.gameObject);
            freeSlot.ClaimForLocalPlayer();
            _localSlot = freeSlot;
            _localJoined = true;
            _localTransmitting = false;
            ResetTriggerSequence();
            SetStatus("参加しました。2回押しの2回目を長押しで送話");
            RefreshVoiceRouting();
        }

        public void RefreshVoiceRouting()
        {
            if (!_routingEnabled) return;
            FindLocalSlot();
            // Restore from our own cache, not the current membership list. A slot may
            // already be empty/reused when the stop or leave packet arrives.
            for (int i = 0; i < _modifiedPlayers.Length; i++)
            {
                VRCPlayerApi player = _modifiedPlayers[i];
                if (!Utilities.IsValid(player)) { _modifiedPlayers[i] = null; continue; }
                if (!IsPlayerTransmitting(player.playerId)) RestoreVoiceAt(i);
            }
            int participantCount = 0;
            if (slots != null)
            {
                for (int i = 0; i < slots.Length; i++)
                {
                    SGIntercomSlot slot = slots[i];
                    if (!IsValidMember(slot)) continue;
                    VRCPlayerApi speaker = VRCPlayerApi.GetPlayerById(slot.playerId);
                    if (!Utilities.IsValid(speaker)) continue;
                    participantCount++;
                    if (speaker.isLocal) continue;

                    if (IsSlotTransmitting(slot))
                    {
                        if (_localJoined)
                            OverrideVoiceDistance(speaker, intercomVoiceNear, intercomVoiceFar);
                        else
                            OverrideVoiceDistance(speaker, isolatedVoiceNear, isolatedVoiceFar);
                    }
                }
            }
            if (participantCountText != null)
                participantCountText.text = "参加者：" + participantCount + "人";
            UpdatePanel();
        }

        public void Maintenance()
        {
            if (!_routingEnabled) return;
            if (slots != null)
            {
                for (int i = 0; i < slots.Length; i++)
                {
                    if (slots[i] != null) slots[i].ClearIfOwnedAndInvalid();
                }
            }
            RefreshVoiceRouting();
        }

        private void FindLocalSlot()
        {
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            _localSlot = null;
            _localJoined = false;
            if (!Utilities.IsValid(localPlayer) || slots == null) return;
            for (int i = 0; i < slots.Length; i++)
            {
                SGIntercomSlot slot = slots[i];
                if (!IsValidMember(slot) || slot.playerId != localPlayer.playerId) continue;
                _localSlot = slot;
                _localJoined = true;
                return;
            }
            _localTransmitting = false;
            ResetTriggerSequence();
        }

        private bool IsValidMember(SGIntercomSlot slot)
        {
            if (slot == null || !slot.joined) return false;
            VRCPlayerApi owner = Networking.GetOwner(slot.gameObject);
            return Utilities.IsValid(owner) && owner.playerId == slot.playerId &&
                Utilities.IsValid(VRCPlayerApi.GetPlayerById(slot.playerId));
        }

        private bool IsSlotTransmitting(SGIntercomSlot slot)
        {
            if (!IsValidMember(slot) || !slot.transmitting) return false;
            int elapsed = Networking.GetServerTimeInMilliseconds() - slot.transmittingHeartbeatServerTime;
            return elapsed >= -1000 && elapsed <= 3000;
        }

        private bool IsPlayerTransmitting(int playerId)
        {
            if (slots == null) return false;
            for (int i = 0; i < slots.Length; i++)
                if (slots[i] != null && slots[i].playerId == playerId && IsSlotTransmitting(slots[i])) return true;
            return false;
        }

        private SGIntercomSlot FindAvailableSlot()
        {
            if (slots == null) return null;
            for (int i = 0; i < slots.Length; i++)
            {
                SGIntercomSlot slot = slots[i];
                if (slot == null) continue;
                VRCPlayerApi occupant = VRCPlayerApi.GetPlayerById(slot.playerId);
                if (!slot.joined || !Utilities.IsValid(occupant)) return slot;
            }
            return null;
        }

        private void OverrideVoiceDistance(VRCPlayerApi player, float nearDistance, float farDistance)
        {
            if (!Utilities.IsValid(player) || player.isLocal) return;
            int free = -1;
            bool tracked = false;
            for (int i = 0; i < _modifiedPlayers.Length; i++)
            {
                if (Utilities.IsValid(_modifiedPlayers[i]) && _modifiedPlayers[i].playerId == player.playerId)
                { tracked = true; break; }
                if (!Utilities.IsValid(_modifiedPlayers[i]) && free < 0) free = i;
            }
            if (!tracked)
            {
                if (free < 0) return;
                _modifiedPlayers[free] = player;
                _previousVoiceNear[free] = player.GetVoiceDistanceNear();
                _previousVoiceFar[free] = player.GetVoiceDistanceFar();
            }
            player.SetVoiceDistanceNear(nearDistance);
            player.SetVoiceDistanceFar(farDistance);
        }

        private void RestoreVoiceAt(int index)
        {
            VRCPlayerApi player = _modifiedPlayers[index];
            if (Utilities.IsValid(player) && !player.isLocal)
            {
                player.SetVoiceDistanceNear(_previousVoiceNear[index]);
                player.SetVoiceDistanceFar(_previousVoiceFar[index]);
            }
            _modifiedPlayers[index] = null;
        }

        private void RestoreAllVoices()
        {
            for (int i = 0; i < _modifiedPlayers.Length; i++) RestoreVoiceAt(i);
        }

        private void UpdatePanel()
        {
            if (membershipButtonText != null)
                membershipButtonText.text = _localJoined ? "内線から退出" : "内線に参加";
            if (transmitIndicator != null)
                transmitIndicator.SetActive(_localJoined && _localTransmitting && _rightTriggerHeld);
            if (localWristIndicatorRoot != null)
                localWristIndicatorRoot.SetActive(_routingEnabled && _localJoined && _localTransmitting && _rightTriggerHeld);
        }

        private void SetStatus(string value)
        {
            if (statusText != null) statusText.text = value;
        }
    }
}
