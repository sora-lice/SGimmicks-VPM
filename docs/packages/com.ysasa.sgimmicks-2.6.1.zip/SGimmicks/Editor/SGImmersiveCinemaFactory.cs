using System;
using System.Collections.Generic;
using System.Linq;
using UdonSharp;
using UdonSharpEditor;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using VRC.SDK3.Video.Components.AVPro;
using VRC.SDK3.Components;
using VRC.SDKBase;
using Object = UnityEngine.Object;

namespace SGimmicks.Editor
{
    internal static class SGImmersiveCinemaFactory
    {
        internal const string CoreTypeName = "JLChnToZ.VRC.VVMW.Core";
        private const string AudioControllerTypeName = "JLChnToZ.VRC.VVMW.AudioController";
        private static readonly string[] TargetArrays = { "screenTargets", "screenTargetModes", "screenTargetIndeces", "screenTargetPropertyNames", "avProPropertyNames", "screenTargetDefaultTextures", "rtScreenTargetSTs" };

        internal static Type FindType(string fullName)
        {
            foreach (Type type in TypeCache.GetTypesDerivedFrom<MonoBehaviour>())
                if (type.FullName == fullName) return type;
            return null;
        }

        internal static bool DependenciesAvailable => FindType(CoreTypeName) != null && FindType(AudioControllerTypeName) != null &&
            AssetDatabase.LoadAssetAtPath<GameObject>("Packages/com.llealloo.audiolink/Runtime/AudioLink.prefab") != null;

        internal static SGImmersiveCinemaController Configure(SGImmersiveCinemaController rig, BoxCollider room, GameObject selectedPlayer, bool arrange)
        {
            if (EditorApplication.isPlaying) throw new InvalidOperationException("Unityの再生モードを停止してから設置・更新してください。");
            if ((rig != null && EditorUtility.IsPersistent(rig)) || (room != null && EditorUtility.IsPersistent(room)) ||
                (selectedPlayer != null && EditorUtility.IsPersistent(selectedPlayer)))
                throw new InvalidOperationException("Hierarchy上のシーン内オブジェクトを指定してください。Prefabアセットを直接変更することはできません。");
            if (!DependenciesAvailable) throw new InvalidOperationException("VIZVID 1.8.2以降とAudioLinkをVCC／ALCOMから先に導入してください。");
            if (GraphicsSettings.currentRenderPipeline != null) throw new InvalidOperationException("この機能はPC・Built-in Render Pipeline専用です。");
            if (rig == null)
            {
                GameObject root = new GameObject("SGImmersiveCinema");
                Undo.RegisterCreatedObjectUndo(root, "Create SG cinema");
                rig = SGEditorFactory.AddCinemaController(root);
                arrange = true;
            }
            Undo.RecordObject(rig, "Configure SG cinema");
            if (room != null) rig.roomBounds = room;
            if (rig.roomBounds == null)
            {
                GameObject bounds = new GameObject("SGCinemaRoomBounds");
                Undo.RegisterCreatedObjectUndo(bounds, "Create cinema room bounds");
                BoxCollider collider = Undo.AddComponent<BoxCollider>(bounds);
                collider.center = new Vector3(0f, 2.5f, 0f);
                collider.size = new Vector3(12f, 5f, 16f);
                collider.isTrigger = true;
                rig.roomBounds = collider;
            }
            Vector3 size = RoomSize(rig.roomBounds);
            if (Mathf.Min(size.x, Mathf.Min(size.y, size.z)) < 1f) throw new InvalidOperationException("会場範囲の各辺は1m以上にしてください。");
            UdonSharpBehaviour core = selectedPlayer != null ? FindCore(selectedPlayer) : rig.vizVidCore;
            if (core == null)
            {
                GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>("Packages/idv.jlchntoz.vvmw/VVMW (Separated Controls).prefab");
                if (prefab == null) throw new InvalidOperationException("VIZVIDのSeparated Controls Prefabが見つかりません。");
                GameObject player = (GameObject)PrefabUtility.InstantiatePrefab(prefab);
                Undo.RegisterCreatedObjectUndo(player, "Create cinema VizVid");
                player.name = "SGCinema_VizVid";
                player.transform.position = rig.roomBounds.transform.TransformPoint(rig.roomBounds.center) +
                    rig.roomBounds.transform.rotation * new Vector3(-size.x * 0.25f, -size.y * 0.5f + 1.2f, -size.z * 0.28f);
                rig.generatedPlayer = player;
                core = FindCore(player);
                // Only the screen belonging to the newly generated player is hidden;
                // an existing player retains all of its other screens and its UI.
                foreach (Object item in ReadRefs(core, "screenTargets"))
                    if (item is Renderer renderer) { Undo.RecordObject(renderer.gameObject, "Hide default cinema screen"); renderer.gameObject.SetActive(false); }
                // Fresh VizVid prefabs register their Screen Configurator on a deferred
                // editor callback, so the target array can still be empty at this point.
                foreach (MonoBehaviour component in player.GetComponentsInChildren<MonoBehaviour>(true))
                {
                    if (component == null || component.GetType().FullName != "JLChnToZ.VRC.VVMW.Designer.ScreenConfigurator") continue;
                    Renderer renderer = component.GetType().GetProperty("Renderer")?.GetValue(component) as Renderer;
                    if (renderer == null) continue;
                    Undo.RecordObject(renderer.gameObject, "Hide default cinema screen");
                    renderer.gameObject.SetActive(false);
                }
            }
            foreach (SGImmersiveCinemaController other in Object.FindObjectsByType<SGImmersiveCinemaController>(FindObjectsSortMode.None))
                if (other != rig && other.connectedCore == core) throw new InvalidOperationException("このVIZVIDには既に別のシネマが接続されています。別のCoreを指定してください。");
            var avHandlers = ReadRefs(core, "playerHandlers").OfType<UdonSharpBehaviour>()
                .Where(h => h.GetComponent<VRCAVProVideoPlayer>() != null).ToArray();
            if (avHandlers.Length != 1) throw new InvalidOperationException("音響連携には、AVPro Moduleを1つ持つVIZVID Coreが必要です。");
            if (rig.connectedCore != null && rig.connectedCore != core) Disconnect(rig);
            rig.vizVidCore = core;
            EnsureAssets(rig);
            bool first = rig.screens == null || rig.screens.Length != 3 || rig.screens.Any(r => r == null);
            EnsureObjects(rig);
            if (first || arrange) Arrange(rig);
            ApplyMaterials(rig);
            ConnectScreens(rig, core);
            ConnectAudio(rig, core, avHandlers);
            ConnectAudioLink(rig, core);
            rig.RefreshProjectionBounds();
            SaveBehaviour(rig);
            SaveBehaviour(core);
            AssetDatabase.SaveAssets();
            EditorSceneManager.MarkSceneDirty(rig.gameObject.scene);
            Selection.activeGameObject = rig.gameObject;
            return rig;
        }

        internal static UdonSharpBehaviour FindCore(GameObject root)
        {
            var cores = root.GetComponentsInChildren<UdonSharpBehaviour>(true).Where(b => b != null && b.GetType().FullName == CoreTypeName).ToArray();
            if (cores.Length != 1) throw new InvalidOperationException("指定オブジェクト内のVIZVID Coreが1つになるようにしてください。");
            return cores[0];
        }

        internal static Vector3 RoomSize(BoxCollider room)
        {
            Vector3 scale = room.transform.lossyScale;
            return Vector3.Scale(room.size, new Vector3(Mathf.Abs(scale.x), Mathf.Abs(scale.y), Mathf.Abs(scale.z)));
        }

        private static void EnsureAssets(SGImmersiveCinemaController rig)
        {
            EnsureFolder("Assets/SGimmicksGenerated/Cinema");
            if (string.IsNullOrEmpty(rig.assetFolder) || !AssetDatabase.IsValidFolder(rig.assetFolder))
            {
                string name = "Cinema_" + Guid.NewGuid().ToString("N").Substring(0, 10);
                AssetDatabase.CreateFolder("Assets/SGimmicksGenerated/Cinema", name);
                rig.assetFolder = "Assets/SGimmicksGenerated/Cinema/" + name;
            }
            rig.screenMaterials = Materials(rig, rig.screenMaterials, "Screen", "SGimmicks/Cinema Extended Screen");
            rig.ambientMaterials = Materials(rig, rig.ambientMaterials, "Ambient", "SGimmicks/Cinema Blurred Ambient");
            rig.projectionMaterials = Materials(rig, rig.projectionMaterials, "Projection", "SGimmicks/Cinema Blurred Projection");
        }

        private static Material[] Materials(SGImmersiveCinemaController rig, Material[] previous, string label, string shaderName)
        {
            Shader shader = Shader.Find(shaderName);
            if (shader == null) throw new InvalidOperationException("シェーダーが見つかりません: " + shaderName);
            Material[] result = new Material[3];
            for (int i = 0; i < 3; i++)
            {
                result[i] = previous != null && previous.Length > i ? previous[i] : null;
                if (result[i] == null)
                {
                    string path = rig.assetFolder + "/" + label + i + ".mat";
                    result[i] = AssetDatabase.LoadAssetAtPath<Material>(path);
                    if (result[i] == null) { result[i] = new Material(shader); AssetDatabase.CreateAsset(result[i], path); }
                }
            }
            return result;
        }

        private static Transform Node(Transform parent, string name)
        {
            Transform result = parent.Find(name);
            if (result != null) return result;
            GameObject go = new GameObject(name);
            Undo.RegisterCreatedObjectUndo(go, "Create cinema object");
            go.transform.SetParent(parent, false);
            return go.transform;
        }

        private static Renderer Plane(Transform parent, string name, Material material)
        {
            Transform node = parent.Find(name);
            if (node == null)
            {
                GameObject go = GameObject.CreatePrimitive(PrimitiveType.Quad);
                Undo.RegisterCreatedObjectUndo(go, "Create cinema screen");
                go.name = name;
                go.transform.SetParent(parent, false);
                Undo.DestroyObjectImmediate(go.GetComponent<Collider>());
                node = go.transform;
            }
            Renderer renderer = node.GetComponent<Renderer>();
            Undo.RecordObject(renderer, "Configure cinema material");
            renderer.sharedMaterial = material;
            renderer.shadowCastingMode = ShadowCastingMode.Off;
            renderer.receiveShadows = false;
            renderer.lightProbeUsage = LightProbeUsage.Off;
            renderer.reflectionProbeUsage = ReflectionProbeUsage.Off;
            return renderer;
        }

        private static void EnsureObjects(SGImmersiveCinemaController rig)
        {
            Transform screensRoot = Node(rig.transform, "Screens");
            Transform ambientRoot = Node(rig.transform, "Ambient");
            rig.screens = new Renderer[3]; rig.ambientScreens = new Renderer[3]; rig.projectionTransforms = new Transform[3];
            string[] names = { "Center", "Left", "Right" };
            for (int i = 0; i < 3; i++)
            {
                rig.screens[i] = Plane(screensRoot, names[i], rig.screenMaterials[i]);
                rig.ambientScreens[i] = Plane(ambientRoot, names[i] + "BlurredExtension", rig.ambientMaterials[i]);
                Transform projector = Node(ambientRoot, names[i] + "WallProjection");
                if (projector.GetComponent<Projector>() == null) Undo.AddComponent<Projector>(projector.gameObject);
                rig.projectionTransforms[i] = projector;
            }
            Transform speakersRoot = Node(rig.transform, "Speakers");
            rig.speakers = new AudioSource[8]; rig.speakerControllers = new UdonSharpBehaviour[8];
            string[] speakerNames = { "FrontLeft", "FrontRight", "SideLeft", "SideRight", "RearLeft", "RearRight", "CeilingLeft", "CeilingRight" };
            for (int i = 0; i < 8; i++)
            {
                GameObject go = Node(speakersRoot, speakerNames[i]).gameObject;
                AudioSource source = go.GetComponent<AudioSource>();
                if (source == null)
                {
                    source = Undo.AddComponent<AudioSource>(go);
                    source.playOnAwake = false; source.loop = false; source.spatialBlend = 1f; source.spatialize = true; source.dopplerLevel = 0f;
                }
                VRC_SpatialAudioSource spatial = go.GetComponent<VRC_SpatialAudioSource>();
                if (spatial == null)
                {
                    spatial = Undo.AddComponent<VRCSpatialAudioSource>(go);
                    spatial.Gain = 0f;
                    spatial.EnableSpatialization = true;
                }
                UdonSharpBehaviour controller = (UdonSharpBehaviour)go.GetComponent(FindType(AudioControllerTypeName));
                if (controller == null) controller = UdonSharpUndo.AddComponent(go, FindType(AudioControllerTypeName));
                rig.speakers[i] = source; rig.speakerControllers[i] = controller;
            }
        }

        internal static void Arrange(SGImmersiveCinemaController rig)
        {
            BoxCollider room = rig.roomBounds;
            Vector3 size = RoomSize(room);
            Undo.RecordObject(rig.transform, "Arrange cinema");
            rig.transform.SetPositionAndRotation(room.transform.TransformPoint(room.center), room.transform.rotation);
            rig.transform.localScale = Vector3.one;
            float width = Mathf.Min(size.x * rig.screenWidthRatio, size.y * rig.screenHeightRatio * 16f / 9f);
            float height = width * 9f / 16f;
            float y = Mathf.Clamp(rig.screenHeightOffset, -size.y * 0.5f + height * 0.5f + 0.05f, size.y * 0.5f - height * 0.5f - 0.05f);
            float front = size.z * 0.5f - 0.15f;
            float angle = rig.sideAngle * Mathf.Deg2Rad;
            float length = Mathf.Min(size.z * rig.sideLengthRatio, (size.z - 0.3f) / Mathf.Max(0.01f, Mathf.Sin(angle)));
            if (Mathf.Cos(angle) > 0.001f) length = Mathf.Min(length, (size.x - width - 0.1f) * 0.5f / Mathf.Cos(angle));
            else if (Mathf.Cos(angle) < -0.001f) length = Mathf.Min(length, (width - 0.1f) * 0.5f / -Mathf.Cos(angle));
            length = Mathf.Max(0.1f, length);
            Position(rig.screens[0].transform, new Vector3(0f, y, front), Quaternion.identity, new Vector3(width, height, 1f));
            Vector3 leftDirection = new Vector3(-Mathf.Cos(angle), 0f, -Mathf.Sin(angle));
            Vector3 rightDirection = new Vector3(Mathf.Cos(angle), 0f, -Mathf.Sin(angle));
            Position(rig.screens[1].transform, new Vector3(-width * 0.5f, y, front) + leftDirection * length * 0.5f,
                Quaternion.Euler(0f, -rig.sideAngle, 0f), new Vector3(length, height, 1f));
            Position(rig.screens[2].transform, new Vector3(width * 0.5f, y, front) + rightDirection * length * 0.5f,
                Quaternion.Euler(0f, rig.sideAngle, 0f), new Vector3(length, height, 1f));
            Vector3[] points = {
                new Vector3(-width * 0.3f, y, front - 0.4f), new Vector3(width * 0.3f, y, front - 0.4f),
                new Vector3(-size.x * 0.45f, y, 0f), new Vector3(size.x * 0.45f, y, 0f),
                new Vector3(-size.x * 0.35f, y, -size.z * 0.43f), new Vector3(size.x * 0.35f, y, -size.z * 0.43f),
                new Vector3(-size.x * 0.24f, size.y * 0.5f - 0.2f, -size.z * 0.1f), new Vector3(size.x * 0.24f, size.y * 0.5f - 0.2f, -size.z * 0.1f) };
            for (int i = 0; i < 8; i++)
            {
                AudioSource source = rig.speakers[i];
                Position(source.transform, points[i], Quaternion.identity, Vector3.one);
                Undo.RecordObject(source, "Fit cinema audio range");
                source.minDistance = Mathf.Max(1f, size.magnitude * 0.08f);
                source.maxDistance = size.magnitude * 1.2f;
                var spatial = source.GetComponent<VRC_SpatialAudioSource>();
                Undo.RecordObject(spatial, "Fit cinema spatial audio range");
                spatial.Near = source.minDistance; spatial.Far = source.maxDistance; spatial.VolumetricRadius = 0f;
            }
            ArrangeAmbient(rig);
        }

        private static void Position(Transform t, Vector3 position, Quaternion rotation, Vector3 scale)
        {
            Undo.RecordObject(t, "Arrange cinema output");
            t.localPosition = position; t.localRotation = rotation; t.localScale = scale;
        }

        internal static void ArrangeAmbient(SGImmersiveCinemaController rig)
        {
            for (int i = 0; i < 3; i++)
            {
                Transform screen = rig.screens[i].transform;
                Vector3 size = screen.lossyScale;
                Transform glow = rig.ambientScreens[i].transform;
                Undo.RecordObject(glow, "Fit cinema ambient");
                glow.SetPositionAndRotation(screen.position + screen.forward * 0.02f, screen.rotation);
                glow.localScale = new Vector3(Mathf.Abs(size.x) + 2f * rig.ambientSpread, Mathf.Abs(size.y) + 2f * rig.ambientSpread, 1f);
                Transform pt = rig.projectionTransforms[i];
                Undo.RecordObject(pt, "Fit cinema projection");
                pt.SetPositionAndRotation(screen.position - screen.forward * 0.05f, screen.rotation);
                pt.localScale = Vector3.one;
                Projector projector = pt.GetComponent<Projector>();
                Undo.RecordObject(projector, "Configure cinema projection");
                projector.orthographic = true;
                projector.orthographicSize = (Mathf.Abs(size.y) + rig.ambientSpread * 2f) * 0.5f;
                projector.aspectRatio = (Mathf.Abs(size.x) + rig.ambientSpread * 2f) / (projector.orthographicSize * 2f);
                projector.nearClipPlane = 0.08f; projector.farClipPlane = rig.projectionDepth + 0.05f;
                projector.material = rig.projectionMaterials[i]; projector.enabled = rig.projectOntoWalls;
                projector.ignoreLayers = LayerMask.GetMask("Player", "PlayerLocal", "UI");
            }
        }

        private static void ApplyMaterials(SGImmersiveCinemaController rig)
        {
            for (int i = 0; i < 3; i++)
            {
                float side = i == 1 ? -1f : i == 2 ? 1f : 0f;
                Vector3 size = rig.screens[i].transform.lossyScale;
                foreach (Material m in new[] { rig.screenMaterials[i], rig.ambientMaterials[i], rig.projectionMaterials[i] })
                {
                    Undo.RecordObject(m, "Configure cinema appearance");
                    bool main = m == rig.screenMaterials[i];
                    Vector3 glowSize = rig.ambientScreens[i].transform.lossyScale;
                    if (m == rig.projectionMaterials[i])
                    {
                        Projector projection = rig.projectionTransforms[i].GetComponent<Projector>();
                        glowSize = new Vector3(projection.orthographicSize * 2f * projection.aspectRatio, projection.orthographicSize * 2f, 1f);
                    }
                    m.SetFloat("_Side", side); m.SetFloat("_EdgeWidth", rig.edgeSampleWidth);
                    m.SetFloat("_Blur", main ? (i == 0 ? 0f : rig.sideBlur) : rig.ambientBlur);
                    m.SetFloat("_Brightness", main ? rig.screenBrightness : rig.ambientBrightness);
                    m.SetFloat("_AudioReactiveStrength", main ? 0f : rig.audioReactiveStrength);
                    m.SetVector("_GlowUVScale", new Vector4(Mathf.Abs(glowSize.x) / Mathf.Max(0.01f, Mathf.Abs(size.x)),
                        Mathf.Abs(glowSize.y) / Mathf.Max(0.01f, Mathf.Abs(size.y)), 0f, 0f));
                    EditorUtility.SetDirty(m);
                }
                Projector projector = rig.projectionTransforms[i].GetComponent<Projector>();
                Undo.RecordObject(projector, "Update cinema projection settings");
                projector.enabled = rig.projectOntoWalls;
                projector.farClipPlane = rig.projectionDepth + 0.05f;
            }
        }

        private static void ConnectScreens(SGImmersiveCinemaController rig, UdonSharpBehaviour core)
        {
            RemoveScreens(rig, core);
            var targets = rig.screens.Cast<Object>().Concat(rig.ambientScreens).Concat(rig.projectionMaterials).ToArray();
            Undo.RecordObject(core, "Connect cinema video");
            using (SerializedObject so = new SerializedObject(core))
            {
                foreach (string name in TargetArrays) if (so.FindProperty(name) == null) throw new InvalidOperationException("VIZVID画面設定の形式が未対応です: " + name);
                int count = so.FindProperty("screenTargets").arraySize;
                foreach (string name in TargetArrays) so.FindProperty(name).arraySize = count + targets.Length;
                for (int i = 0; i < targets.Length; i++)
                {
                    int n = count + i;
                    so.FindProperty("screenTargets").GetArrayElementAtIndex(n).objectReferenceValue = targets[i];
                    so.FindProperty("screenTargetModes").GetArrayElementAtIndex(n).intValue = targets[i] is Material ? 0 : 1;
                    so.FindProperty("screenTargetIndeces").GetArrayElementAtIndex(n).intValue = -1;
                    so.FindProperty("screenTargetPropertyNames").GetArrayElementAtIndex(n).stringValue = "_MainTex";
                    so.FindProperty("avProPropertyNames").GetArrayElementAtIndex(n).stringValue = "_IsAVProVideo";
                    so.FindProperty("screenTargetDefaultTextures").GetArrayElementAtIndex(n).objectReferenceValue = Texture2D.blackTexture;
                    so.FindProperty("rtScreenTargetSTs").GetArrayElementAtIndex(n).vector4Value = new Vector4(1f, 1f, 0f, 0f);
                }
                so.ApplyModifiedProperties();
            }
        }

        private static void RemoveScreens(SGImmersiveCinemaController rig, UdonSharpBehaviour core)
        {
            if (core == null) return;
            HashSet<Object> ours = new HashSet<Object>();
            if (rig.screens != null) foreach (Renderer item in rig.screens) if (item != null) ours.Add(item);
            if (rig.ambientScreens != null) foreach (Renderer item in rig.ambientScreens) if (item != null) ours.Add(item);
            if (rig.projectionMaterials != null) foreach (Material item in rig.projectionMaterials) if (item != null) ours.Add(item);
            Undo.RecordObject(core, "Unlink cinema screens");
            using (SerializedObject so = new SerializedObject(core))
            {
                SerializedProperty targets = so.FindProperty("screenTargets");
                if (targets == null) return;
                for (int i = targets.arraySize - 1; i >= 0; i--)
                {
                    if (!ours.Contains(targets.GetArrayElementAtIndex(i).objectReferenceValue)) continue;
                    foreach (string name in TargetArrays)
                    {
                        SerializedProperty array = so.FindProperty(name);
                        if (array == null || array.arraySize <= i) continue;
                        int before = array.arraySize;
                        array.DeleteArrayElementAtIndex(i);
                        if (array.arraySize == before) array.DeleteArrayElementAtIndex(i);
                    }
                }
                so.ApplyModifiedProperties();
            }
        }

        private static void ConnectAudio(SGImmersiveCinemaController rig, UdonSharpBehaviour core, UdonSharpBehaviour[] handlers)
        {
            if (rig.connectedCore == null)
            {
                rig.previousCoreSources = ReadRefs(core, "audioSources").OfType<AudioSource>().ToArray();
                rig.previousCoreControllers = ReadRefs(core, "audioControllers").OfType<UdonSharpBehaviour>().ToArray();
                var originals = new HashSet<AudioSource>(rig.previousCoreSources);
                foreach (UdonSharpBehaviour ac in rig.previousCoreControllers)
                    foreach (Object source in ReadRefs(ac, "audioSource", false)) if (source is AudioSource audio) originals.Add(audio);
                rig.mutedOriginalSources = originals.ToArray();
                rig.previousSourceEnabled = rig.mutedOriginalSources.Select(s => s.enabled).ToArray();
                rig.connectedHandlers = handlers;
                rig.previousPrimaryLeft = handlers.Select(h => ReadRefs(h, "primaryAudioSource", false).FirstOrDefault() as AudioSource).ToArray();
                rig.previousPrimaryRight = handlers.Select(h => ReadRefs(h, "primaryAudioSourceR", false).FirstOrDefault() as AudioSource).ToArray();
                rig.previousAudioLink = ReadRefs(core, "audioLink", false).FirstOrDefault() as UdonSharpBehaviour;
                rig.connectedCore = core;
            }
            foreach (AudioSource source in rig.mutedOriginalSources) if (source != null) { Undo.RecordObject(source, "Replace cinema output"); source.enabled = false; }
            var player = handlers[0].GetComponent<VRCAVProVideoPlayer>();
            for (int i = 0; i < 8; i++)
            {
                AudioSource source = rig.speakers[i];
                Undo.RecordObject(source, "Configure cinema sound");
                source.enabled = true;
                VRCAVProVideoSpeaker speaker = source.GetComponent<VRCAVProVideoSpeaker>();
                if (speaker == null) speaker = Undo.AddComponent<VRCAVProVideoSpeaker>(source.gameObject);
                using (var so = new SerializedObject(speaker)) { so.FindProperty("videoPlayer").objectReferenceValue = player; so.FindProperty("mode").intValue = i % 2 == 0 ? 1 : 2; so.ApplyModifiedProperties(); }
                UdonSharpBehaviour ac = rig.speakerControllers[i];
                using (var so = new SerializedObject(ac))
                {
                    so.FindProperty("audioSource").objectReferenceValue = source;
                    so.FindProperty("core").objectReferenceValue = core;
                    float volume = i < 2 ? rig.frontVolume : i < 4 ? rig.sideVolume : i < 6 ? rig.rearVolume : rig.ceilingVolume;
                    so.FindProperty("volume").floatValue = volume;
                    so.ApplyModifiedProperties(); source.volume = volume;
                }
                SaveBehaviour(ac);
            }
            SetRefs(core, "audioSources", Array.Empty<Object>());
            SetRefs(core, "audioControllers", rig.speakerControllers);
            foreach (UdonSharpBehaviour handler in handlers)
            {
                SetRef(handler, "primaryAudioSource", rig.speakers[0]);
                SetRef(handler, "primaryAudioSourceR", rig.speakers[1]);
                SaveBehaviour(handler);
            }
        }

        private static void ConnectAudioLink(SGImmersiveCinemaController rig, UdonSharpBehaviour core)
        {
            if (rig.audioLink == null) rig.audioLink = ReadRefs(core, "audioLink", false).FirstOrDefault() as UdonSharpBehaviour;
            if (rig.audioLink == null)
            {
                Type type = FindType("AudioLink.AudioLink") ?? FindType("VRCAudioLink.AudioLink");
                var found = type == null ? Array.Empty<Object>() : Object.FindObjectsByType(type, FindObjectsSortMode.None);
                if (found.Length > 1) throw new InvalidOperationException("AudioLinkが複数あります。使うAudioLinkをシネマのInspectorで指定してください。");
                if (found.Length == 1) rig.audioLink = found[0] as UdonSharpBehaviour;
                else
                {
                    GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>("Packages/com.llealloo.audiolink/Runtime/AudioLink.prefab");
                    GameObject go = (GameObject)PrefabUtility.InstantiatePrefab(prefab);
                    Undo.RegisterCreatedObjectUndo(go, "Create cinema AudioLink");
                    rig.audioLink = go.GetComponent(type) as UdonSharpBehaviour;
                }
            }
            if (rig.audioLink == null) throw new InvalidOperationException("AudioLinkの接続に失敗しました。");
            if (rig.linkedAudioLink != rig.audioLink)
            {
                RestoreAudioLinkInput(rig);
                rig.previousAudioLinkSource = ReadRefs(rig.audioLink, "audioSource", false).FirstOrDefault() as AudioSource;
                using (var previous = new SerializedObject(rig.audioLink))
                {
                    var right = previous.FindProperty("optionalRightAudioSource");
                    rig.previousAudioLinkRightSource = right != null ? right.objectReferenceValue as AudioSource : null;
                }
                rig.linkedAudioLink = rig.audioLink;
            }
            SetRef(core, "audioLink", rig.audioLink);
            SetRef(rig.audioLink, "audioSource", rig.speakers[0]);
            using (var so = new SerializedObject(rig.audioLink))
            {
                var right = so.FindProperty("optionalRightAudioSource");
                if (right != null) right.objectReferenceValue = rig.speakers[1];
                so.ApplyModifiedProperties();
            }
            SaveBehaviour(rig.audioLink);
        }

        internal static void Disconnect(SGImmersiveCinemaController rig)
        {
            UdonSharpBehaviour core = rig.connectedCore;
            if (core == null) return;
            RemoveScreens(rig, core);
            SetRefs(core, "audioSources", rig.previousCoreSources ?? Array.Empty<AudioSource>());
            SetRefs(core, "audioControllers", rig.previousCoreControllers ?? Array.Empty<UdonSharpBehaviour>());
            SetRef(core, "audioLink", rig.previousAudioLink);
            RestoreAudioLinkInput(rig);
            if (rig.mutedOriginalSources != null)
                for (int i = 0; i < rig.mutedOriginalSources.Length; i++)
                    if (rig.mutedOriginalSources[i] != null) { Undo.RecordObject(rig.mutedOriginalSources[i], "Restore original sound"); rig.mutedOriginalSources[i].enabled = rig.previousSourceEnabled[i]; }
            if (rig.connectedHandlers != null)
                for (int i = 0; i < rig.connectedHandlers.Length; i++)
                {
                    if (rig.connectedHandlers[i] == null) continue;
                    SetRef(rig.connectedHandlers[i], "primaryAudioSource", rig.previousPrimaryLeft[i]);
                    SetRef(rig.connectedHandlers[i], "primaryAudioSourceR", rig.previousPrimaryRight[i]);
                    SaveBehaviour(rig.connectedHandlers[i]);
                }
            if (rig.speakers != null) foreach (AudioSource source in rig.speakers) if (source != null) source.enabled = false;
            SaveBehaviour(core);
            rig.connectedCore = null;
            SaveBehaviour(rig);
            EditorSceneManager.MarkSceneDirty(rig.gameObject.scene);
        }

        private static void RestoreAudioLinkInput(SGImmersiveCinemaController rig)
        {
            UdonSharpBehaviour audioLink = rig.linkedAudioLink;
            if (audioLink == null) return;
            Object current = ReadRefs(audioLink, "audioSource", false).FirstOrDefault();
            if (rig.speakers != null && rig.speakers.Contains(current as AudioSource))
            {
                SetRef(audioLink, "audioSource", rig.previousAudioLinkSource);
                using (var so = new SerializedObject(audioLink))
                {
                    var right = so.FindProperty("optionalRightAudioSource");
                    if (right != null) right.objectReferenceValue = rig.previousAudioLinkRightSource;
                    so.ApplyModifiedProperties();
                }
                SaveBehaviour(audioLink);
            }
            rig.linkedAudioLink = null;
        }

        private static Object[] ReadRefs(Object target, string name, bool array = true)
        {
            using (var so = new SerializedObject(target))
            {
                SerializedProperty property = so.FindProperty(name);
                if (property == null) throw new InvalidOperationException("連携先の設定が見つかりません: " + name);
                if (!array) return new[] { property.objectReferenceValue };
                Object[] refs = new Object[property.arraySize];
                for (int i = 0; i < refs.Length; i++) refs[i] = property.GetArrayElementAtIndex(i).objectReferenceValue;
                return refs;
            }
        }

        private static void SetRefs(Object target, string name, Object[] refs)
        {
            Undo.RecordObject(target, "Configure VizVid cinema");
            using (var so = new SerializedObject(target)) { var p = so.FindProperty(name); if (p == null) throw new InvalidOperationException(name); p.arraySize = refs.Length; for (int i = 0; i < refs.Length; i++) p.GetArrayElementAtIndex(i).objectReferenceValue = refs[i]; so.ApplyModifiedProperties(); }
        }

        private static void SetRef(Object target, string name, Object value)
        {
            Undo.RecordObject(target, "Configure VizVid cinema");
            using (var so = new SerializedObject(target)) { var p = so.FindProperty(name); if (p == null) throw new InvalidOperationException(name); p.objectReferenceValue = value; so.ApplyModifiedProperties(); }
        }

        private static void SaveBehaviour(UdonSharpBehaviour behaviour)
        {
            EditorUtility.SetDirty(behaviour);
            UdonSharpEditorUtility.CopyProxyToUdon(behaviour);
            var backing = UdonSharpEditorUtility.GetBackingUdonBehaviour(behaviour);
            if (backing != null) EditorUtility.SetDirty(backing);
            if (PrefabUtility.IsPartOfPrefabInstance(behaviour)) PrefabUtility.RecordPrefabInstancePropertyModifications(behaviour);
        }

        private static void EnsureFolder(string path)
        {
            if (AssetDatabase.IsValidFolder(path)) return;
            int slash = path.LastIndexOf('/');
            string parent = path.Substring(0, slash); EnsureFolder(parent);
            AssetDatabase.CreateFolder(parent, path.Substring(slash + 1));
        }
    }
}
