using System;
using UnityEditor;
using UnityEngine;

namespace SGimmicks.Editor
{
    public sealed class SGImmersiveCinemaWindow : EditorWindow
    {
        [SerializeField] private SGImmersiveCinemaController _rig;
        [SerializeField] private BoxCollider _room;
        [SerializeField] private GameObject _player;
        private Vector2 _scroll;

        [MenuItem("SGimmicks/シネマ・3面スクリーンを設定", priority = 14)]
        public static void Open()
        {
            var window = GetWindow<SGImmersiveCinemaWindow>("SGimmicks シネマ");
            window.minSize = new Vector2(550f, 540f);
            window.Show();
        }

        private void OnGUI()
        {
            _scroll = EditorGUILayout.BeginScrollView(_scroll);
            EditorGUILayout.LabelField("VIZVID シネマ一括設置", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("正面＋左右の疑似拡張画面、3面の外周にぼかした映像を広げる発光面と壁面投影、前後左右・天井の8音源を生成します。Zプラス方向が正面です。PC・Built-in専用です。", MessageType.Info);
            if (!SGImmersiveCinemaFactory.DependenciesAvailable)
                EditorGUILayout.HelpBox("VIZVID 1.8.2以降とAudioLinkが必要です。VCC／ALCOMで別途導入してください。未導入でもSGimmicksの他機能には影響しません。", MessageType.Warning);
            EditorGUI.BeginChangeCheck();
            _rig = (SGImmersiveCinemaController)EditorGUILayout.ObjectField("既存のシネマ", _rig, typeof(SGImmersiveCinemaController), true);
            if (EditorGUI.EndChangeCheck()) { _room = _rig != null ? _rig.roomBounds : null; _player = null; }
            if (GUILayout.Button("選択中／シーンのシネマを読み込む"))
            {
                _rig = Selection.activeGameObject != null ? Selection.activeGameObject.GetComponentInParent<SGImmersiveCinemaController>() : null;
                if (_rig == null) _rig = FindAnyObjectByType<SGImmersiveCinemaController>();
                if (_rig != null) _room = _rig.roomBounds;
            }
            _room = (BoxCollider)EditorGUILayout.ObjectField(new GUIContent("部屋の範囲", "省略時は12×5×16mの範囲を新規作成します。"), _room, typeof(BoxCollider), true);
            _player = (GameObject)EditorGUILayout.ObjectField(new GUIContent("接続する既存VIZVID", "Coreを1つ含むシーン内オブジェクト。省略時は既存接続を維持し、未接続ならSeparated Controlsを自動生成します。"), _player, typeof(GameObject), true);
            using (new EditorGUI.DisabledScope(!SGImmersiveCinemaFactory.DependenciesAvailable))
            {
                if (GUILayout.Button(_rig == null ? "シネマ一式を自動生成" : "設定を適用・VIZVIDへ再接続（配置を維持）", GUILayout.Height(42f))) Configure(false);
            }
            if (_rig != null)
            {
                using (var so = new SerializedObject(_rig))
                {
                    so.Update();
                    EditorGUILayout.Space(8f);
                    EditorGUILayout.LabelField("範囲から再配置するときの寸法", EditorStyles.boldLabel);
                    Property(so, "screenWidthRatio", "正面幅／部屋幅");
                    Property(so, "screenHeightRatio", "画面高さ／部屋高さの上限");
                    Property(so, "sideLengthRatio", "側面長さ／部屋奥行き");
                    Property(so, "sideAngle", "側面の角度（90度でコの字）");
                    Property(so, "screenHeightOffset", "画面中心の上下位置（m）");
                    EditorGUILayout.LabelField("映像・外周のぼかし", EditorStyles.boldLabel);
                    Property(so, "edgeSampleWidth", "左右に使う映像端の幅");
                    Property(so, "sideBlur", "左右画面のぼかし");
                    Property(so, "screenBrightness", "3画面の明るさ");
                    Property(so, "ambientSpread", "外周の広がり（m）");
                    Property(so, "ambientBlur", "外周のぼかし");
                    Property(so, "ambientBrightness", "外周・背面の光量");
                    Property(so, "audioReactiveStrength", "AudioLinkによる光量変化");
                    Property(so, "projectOntoWalls", "背面の壁にも映像を投影");
                    Property(so, "projectionDepth", "背面への到達距離（m）");
                    Property(so, "audioLink", "使用するAudioLink");
                    EditorGUILayout.LabelField("音響バランス（各1台の音量）", EditorStyles.boldLabel);
                    Property(so, "frontVolume", "前方 L／R"); Property(so, "sideVolume", "側面 L／R");
                    Property(so, "rearVolume", "後方 L／R"); Property(so, "ceilingVolume", "天井 L／R");
                    if (so.ApplyModifiedProperties()) EditorUtility.SetDirty(_rig);
                }
                EditorGUILayout.Space(8f);
                using (new EditorGUI.DisabledScope(!SGImmersiveCinemaFactory.DependenciesAvailable))
                {
                    if (GUILayout.Button("部屋の範囲から画面・音源を再配置", GUILayout.Height(34f)) &&
                        EditorUtility.DisplayDialog("再配置", "画面・音源・外周の光を部屋範囲から並べ直します。手動で調整した位置と大きさは置き換わります。", "再配置", "キャンセル")) Configure(true);
                    if (GUILayout.Button("3画面に外周・背面の光を合わせ直す"))
                    {
                        SGImmersiveCinemaFactory.ArrangeAmbient(_rig);
                        Configure(false);
                    }
                }
                if (_rig.connectedCore != null && GUILayout.Button("VIZVIDとの接続解除・元の音源を復元"))
                    SGImmersiveCinemaFactory.Disconnect(_rig);
            }
            EditorGUILayout.HelpBox("通常の動画から、映っていない景色や独立した5.1／7.1音声は生成できません。左右は映像の端を反転・引き延ばしてつなぐ疑似拡張、音響はL／R音声の分散配置です。音源連携はPCのAVPro再生専用です。", MessageType.Warning);
            EditorGUILayout.HelpBox("光は単色ライトではなく、ぼかした映像の発光面＋背面への加算投影です。壁まで投影が届く位置・距離にしてください。IgnoreProjectorのマテリアルには投影されません。外周の広がりを変更したときは『3画面に外周・背面の光を合わせ直す』を押します。設定変更後は『設定を適用』を押し、シーンを保存して再アップロードしてください。", MessageType.None);
            EditorGUILayout.EndScrollView();
        }

        private static void Property(SerializedObject so, string name, string label)
        {
            EditorGUILayout.PropertyField(so.FindProperty(name), new GUIContent(label));
        }

        private void Configure(bool arrange)
        {
            Undo.IncrementCurrentGroup();
            int group = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName("Configure SGimmicks cinema");
            try
            {
                _rig = SGImmersiveCinemaFactory.Configure(_rig, _room, _player, arrange);
                _room = _rig.roomBounds;
                Undo.CollapseUndoOperations(group);
                ShowNotification(new GUIContent("シネマを設定しました。シーンを保存してください"));
            }
            catch (Exception e)
            {
                Undo.RevertAllDownToGroup(group);
                Debug.LogException(e);
                EditorUtility.DisplayDialog("SGimmicks シネマ", e.Message, "OK");
            }
        }
    }
}
