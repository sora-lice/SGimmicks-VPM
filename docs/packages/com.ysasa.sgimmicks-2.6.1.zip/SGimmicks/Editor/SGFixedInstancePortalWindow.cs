using System;
using UnityEditor;
using UnityEngine;

namespace SGimmicks.Editor
{
    public sealed class SGFixedInstancePortalWindow : EditorWindow
    {
        [SerializeField] private SGFixedInstancePortal _controller;
        [SerializeField] private Transform _placement;
        [SerializeField] private string _destination = "";
        [SerializeField] private bool _refresh;
        private Vector2 _scroll;

        [MenuItem("SGimmicks/固定インスタンスポータル（検証用）", priority = 18)]
        public static void Open()
        {
            var window = GetWindow<SGFixedInstancePortalWindow>("SGimmicks ポータル");
            window.minSize = new Vector2(580f, 490f);
            window.Show();
        }

        private void OnGUI()
        {
            _scroll = EditorGUILayout.BeginScrollView(_scroll);
            EditorGUILayout.LabelField("固定インスタンスポータル（検証用）", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("指定インスタンスへの移動を試す機能です。Publicへ移動する場合があるため、オーナー以外・後から入った人でも到着先のインスタンスIDを確認してください。", MessageType.Warning);
            if (GUILayout.Button("複製・書換えを行わない「直接配置テスト」を開く")) SGBakedPortalTestWindow.Open();
            EditorGUI.BeginChangeCheck();
            _controller = (SGFixedInstancePortal)EditorGUILayout.ObjectField("既存コントローラー", _controller, typeof(SGFixedInstancePortal), true);
            if (EditorGUI.EndChangeCheck() && _controller != null) Load(_controller);
            if (GUILayout.Button("選択中のポータル設定を読み込む"))
            {
                var selected = Selection.activeGameObject != null ? Selection.activeGameObject.GetComponentInParent<SGFixedInstancePortal>() : null;
                if (selected != null) Load(selected);
                else ShowNotification(new GUIContent("HierarchyでSGFixedInstancePortalを選択してください"));
            }
            using (new EditorGUI.DisabledScope(_controller != null))
                _placement = (Transform)EditorGUILayout.ObjectField("初回の配置位置（省略可）", _placement, typeof(Transform), true);
            EditorGUILayout.LabelField("参加URL または 完全なRoom ID");
            _destination = EditorGUILayout.TextArea(_destination, GUILayout.MinHeight(65));
            bool valid = SGFixedInstancePortalFactory.TryResolve(_destination, out var room, out var error);
            if (valid)
            {
                EditorGUILayout.LabelField("設定されるRoom ID（タグを含む）");
                EditorGUILayout.SelectableLabel(room, EditorStyles.textArea, GUILayout.Height(55));
            }
            else EditorGUILayout.HelpBox(error, MessageType.Info);
            _refresh = EditorGUILayout.Toggle(new GUIContent("有効化後にRefreshPortal", "初期値はOFFです。ONも別のBuild & Testで比較してください。"), _refresh);
            EditorGUILayout.HelpBox("初回はSDKポータルの非アクティブなテンプレートも自動生成します。各プレイヤーの入室時にローカルで複製し、Room IDを設定した後に有効化します。更新時はコントローラーとテンプレートの位置・回転・大きさを維持します。", MessageType.None);
            using (new EditorGUI.DisabledScope(!valid || EditorApplication.isPlayingOrWillChangePlaymode))
                if (GUILayout.Button(_controller == null ? "検証用ポータルを作成" : "設定を更新（配置を維持）", GUILayout.Height(40))) Apply();
            if (_controller != null && GUILayout.Button("配置オブジェクトを選択"))
            {
                Selection.activeGameObject = _controller.gameObject;
                SceneView.FrameLastActiveSceneView();
            }
            EditorGUILayout.HelpBox("配置はSGFixedInstancePortal本体を移動します。PortalTemplate_Inactiveは非アクティブのままにしてください。参加URL・Room IDはワールドデータへ保存されるため、そのワールドの参加者へ共有してよい行き先を設定してください。", MessageType.None);
            EditorGUILayout.EndScrollView();
        }

        private void Load(SGFixedInstancePortal value)
        {
            _controller = value;
            _destination = value.destinationRoomId;
            _refresh = value.refreshAfterActivation;
        }

        private void Apply()
        {
            Undo.IncrementCurrentGroup();
            int group = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName("Configure fixed instance portal");
            try
            {
                Load(SGFixedInstancePortalFactory.Configure(_controller, _placement, _destination, _refresh));
                Undo.CollapseUndoOperations(group);
                ShowNotification(new GUIContent("設定しました。シーンを保存してください"));
            }
            catch (Exception e)
            {
                Undo.RevertAllDownToGroup(group);
                Debug.LogException(e);
                EditorUtility.DisplayDialog("SGimmicks ポータル", e.Message, "OK");
            }
        }
    }
}
