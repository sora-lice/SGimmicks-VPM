using System;
using UdonSharpEditor;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using VRC.SDK3.Components;

namespace SGimmicks.Editor
{
    internal static class SGLocalAutoDoorFactory
    {
        internal static SGLocalAutoDoorController Configure(SGLocalAutoDoorController controller,
            BoxCollider area, Transform first, Transform second, bool doubleDoor,
            Vector3 firstOffset, Vector3 secondOffset, float openTime, float closeTime, float delay)
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
                throw new InvalidOperationException("再生モードを停止してから作成・更新してください。");
            ValidateDoor(first);
            if (doubleDoor)
            {
                ValidateDoor(second);
                if (first == second || first.IsChildOf(second) || second.IsChildOf(first))
                    throw new InvalidOperationException("両開きの扉は、互いに親子関係のない別のオブジェクトを指定してください。");
                if (first.gameObject.scene != second.gameObject.scene)
                    throw new InvalidOperationException("扉は同じシーン内に置いてください。");
            }
            if (controller != null)
            {
                if (EditorUtility.IsPersistent(controller)) throw new InvalidOperationException("Hierarchy上のコントローラーを指定してください。");
                if (area == null) area = controller.detectionArea;
                if (area == null || area.gameObject != controller.gameObject)
                    throw new InvalidOperationException("既存の検知範囲はコントローラーと同じオブジェクトのBoxColliderを指定してください。範囲の位置・大きさはHierarchyで変更できます。");
            }
            if (area != null)
            {
                if (EditorUtility.IsPersistent(area) || area.gameObject.scene != first.gameObject.scene)
                    throw new InvalidOperationException("検知範囲は扉と同じシーンのHierarchyから指定してください。");
                if (area.GetComponents<Collider>().Length != 1)
                    throw new InvalidOperationException("検知範囲のオブジェクトにはBoxColliderを1個だけ付けてください。");
                if (area.transform.IsChildOf(first) || (doubleDoor && area.transform.IsChildOf(second)))
                    throw new InvalidOperationException("検知範囲を動く扉の子にはできません。扉とは別のオブジェクトにしてください。");
                var existing = area.GetComponent<SGLocalAutoDoorController>();
                if (existing != null && existing != controller)
                    throw new InvalidOperationException("その範囲には自動ドアが設定済みです。既存コントローラー欄で読み込んでください。");
            }
            foreach (var other in UnityEngine.Object.FindObjectsByType<SGLocalAutoDoorController>(FindObjectsInactive.Include, FindObjectsSortMode.None))
            {
                if (other == controller) continue;
                if (Overlaps(first, other.firstDoor) || (other.doubleDoor && Overlaps(first, other.secondDoor)) ||
                    (doubleDoor && (Overlaps(second, other.firstDoor) || (other.doubleDoor && Overlaps(second, other.secondDoor)))))
                    throw new InvalidOperationException("その扉、または親子オブジェクトは別の自動ドアで使用中です。");
            }
            if (area == null)
            {
                var go = new GameObject("SGLocalAutoDoorArea");
                Undo.RegisterCreatedObjectUndo(go, "Create local auto door area");
                UnityEngine.SceneManagement.SceneManager.MoveGameObjectToScene(go, first.gameObject.scene);
                Vector3 center = first.position;
                Renderer renderer = first.GetComponentInChildren<Renderer>();
                if (renderer != null) center = renderer.bounds.center;
                if (doubleDoor)
                {
                    renderer = second.GetComponentInChildren<Renderer>();
                    center = (center + (renderer != null ? renderer.bounds.center : second.position)) * 0.5f;
                }
                go.transform.SetPositionAndRotation(center, Quaternion.Euler(0f, first.eulerAngles.y, 0f));
                area = Undo.AddComponent<BoxCollider>(go);
                area.size = new Vector3(3f, 2.5f, 3f);
            }
            if (controller == null) controller = SGEditorFactory.AddLocalAutoDoorController(area.gameObject);
            Undo.RecordObject(area, "Configure door detection area");
            area.isTrigger = true;
            Undo.RecordObject(controller, "Configure local auto door");
            controller.detectionArea = area;
            controller.firstDoor = first;
            controller.secondDoor = doubleDoor ? second : null;
            controller.doubleDoor = doubleDoor;
            controller.firstOpenOffset = firstOffset;
            controller.secondOpenOffset = secondOffset;
            controller.openingDuration = Mathf.Max(0.01f, openTime);
            controller.closingDuration = Mathf.Max(0.01f, closeTime);
            controller.closeDelay = Mathf.Max(0f, delay);
            UdonSharpEditorUtility.CopyProxyToUdon(controller);
            EditorUtility.SetDirty(controller);
            EditorUtility.SetDirty(area);
            PrefabUtility.RecordPrefabInstancePropertyModifications(controller);
            PrefabUtility.RecordPrefabInstancePropertyModifications(area);
            EditorSceneManager.MarkSceneDirty(controller.gameObject.scene);
            Selection.activeGameObject = controller.gameObject;
            return controller;
        }

        private static bool Overlaps(Transform a, Transform b)
        {
            return a != null && b != null && (a == b || a.IsChildOf(b) || b.IsChildOf(a));
        }

        private static void ValidateDoor(Transform door)
        {
            if (door == null || EditorUtility.IsPersistent(door) || !door.gameObject.scene.IsValid())
                throw new InvalidOperationException("動かす扉をHierarchyから指定してください。");
            if (door.GetComponentInParent<VRCObjectSync>() != null || door.GetComponentInChildren<VRCObjectSync>(true) != null)
                throw new InvalidOperationException("ローカル動作の扉とその親子にはVRCObjectSyncを付けないでください。");
            foreach (var body in door.GetComponentsInChildren<Rigidbody>(true))
                if (!body.isKinematic) throw new InvalidOperationException("動かす扉のRigidbodyはIs Kinematicを有効にしてください。");
            Rigidbody parentBody = door.GetComponentInParent<Rigidbody>();
            if (parentBody != null && !parentBody.isKinematic)
                throw new InvalidOperationException("扉の親のRigidbodyもIs Kinematicを有効にしてください。");
            foreach (Transform item in door.GetComponentsInChildren<Transform>(true))
                if ((GameObjectUtility.GetStaticEditorFlags(item.gameObject) & StaticEditorFlags.BatchingStatic) != 0)
                    throw new InvalidOperationException("動く扉とその子オブジェクトのBatching Staticを無効にしてください。");
        }
    }
}
