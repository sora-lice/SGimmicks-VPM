using System;
using System.Linq;
using UdonSharp;
using UdonSharpEditor;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;
using VRC.SDK3.Components;
using VRC.SDKBase;

namespace SGimmicks.Editor
{
    internal static class SGReceptionFactory
    {
        internal static SGReceptionController Configure(SGReceptionController controller, string operatorName)
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode) throw new InvalidOperationException("再生モードを停止してください。");
            if (string.IsNullOrWhiteSpace(operatorName) || operatorName.Trim().Length > 64)
                throw new InvalidOperationException("補助ツールを起動する担当者のVRChat表示名を指定してください。");
            if (controller != null && (EditorUtility.IsPersistent(controller) || !controller.gameObject.scene.IsValid()))
                throw new InvalidOperationException("Hierarchy上の受付システムを指定してください。");
            if (controller == null)
            {
                var root = new GameObject("SGReceptionSystem");
                Undo.RegisterCreatedObjectUndo(root, "Create reception system");
                controller = SGEditorFactory.AddBundledComponent<SGReceptionController>(root);
                controller.worldId = "reception_" + Guid.NewGuid().ToString("N");
            }
            if (!controller.gameObject.activeInHierarchy) throw new InvalidOperationException("受付システムは常時有効にしてください。");
            Undo.RecordObject(controller, "Configure reception system");
            controller.bridgeDisplayName = operatorName.Trim();

            var card = controller.transform.Find("ReceptionCard");
            if (card == null) card = CreateCard(controller.transform).transform;
            var display = controller.GetComponentsInChildren<SGReceptionDisplay>(true).FirstOrDefault();
            if (display == null) display = CreateDisplay(controller.transform);
            display.controller = controller;
            display.callbackReceiver = UdonSharpEditorUtility.GetBackingUdonBehaviour(display);
            var reader = controller.GetComponentsInChildren<SGReceptionReader>(true).FirstOrDefault();
            if (reader == null)
            {
                var go = Child(controller.transform, "CardReader", new Vector3(-0.6f, 1f, 0f));
                var trigger = Undo.AddComponent<BoxCollider>(go); trigger.isTrigger = true; trigger.size = new Vector3(.28f, .16f, .2f);
                reader = SGEditorFactory.AddBundledComponent<SGReceptionReader>(go);
                Visual(go.transform, "ReaderVisual", new Vector3(.24f, .08f, .16f));
            }
            reader.display = display;
            if (reader.readArea == null) reader.readArea = reader.GetComponent<BoxCollider>();
            if (reader.cards == null || reader.cards.Length == 0) reader.cards = new[] { card.GetComponent<VRC_Pickup>() };
            Save(display); Save(reader); Save(controller);
            EditorSceneManager.MarkSceneDirty(controller.gameObject.scene);
            Selection.activeGameObject = controller.gameObject;
            return controller;
        }

        private static GameObject CreateCard(Transform parent)
        {
            var go = Child(parent, "ReceptionCard", new Vector3(-.6f, 1.2f, -.4f));
            var collider = Undo.AddComponent<BoxCollider>(go); collider.size = new Vector3(.12f, .075f, .008f);
            var body = Undo.AddComponent<Rigidbody>(go); body.mass = .05f; body.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
            Undo.AddComponent<VRCPickup>(go);
            var sync = Undo.AddComponent<VRCObjectSync>(go); sync.AllowCollisionOwnershipTransfer = false;
            Visual(go.transform, "CardVisual", collider.size);
            return go;
        }

        private static SGReceptionDisplay CreateDisplay(Transform parent)
        {
            var go = new GameObject("GuestDisplay", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(Image));
            Undo.RegisterCreatedObjectUndo(go, "Create reception display"); go.transform.SetParent(parent, false);
            go.transform.localPosition = new Vector3(.15f, 1.45f, .1f); go.transform.localScale = Vector3.one * .001f;
            var rect = go.GetComponent<RectTransform>(); rect.sizeDelta = new Vector2(1000, 650);
            var canvas = go.GetComponent<Canvas>(); canvas.renderMode = RenderMode.WorldSpace;
            go.GetComponent<Image>().color = new Color(.025f, .045f, .075f, 1f);
            var display = SGEditorFactory.AddBundledComponent<SGReceptionDisplay>(go);
            display.titleText = Text(rect, "Title", "カード受付", .75f, .95f, 48);
            display.nameText = Text(rect, "GuestName", "", .55f, .73f, 42);
            display.countText = Text(rect, "VisitCount", "", .37f, .54f, 46);
            display.messageText = Text(rect, "Welcome", "カードを持って、読取機にタッチしてください。", .06f, .34f, 34);
            return display;
        }

        internal static Text Text(RectTransform parent, string name, string value, float bottom, float top, int size)
        {
            var text = SGEditorFactory.CreateTabletText(parent, name, value, new Vector2(.04f, bottom), new Vector2(.96f, top), size, new Color(.92f, .97f, 1f));
            text.supportRichText = false; return text;
        }

        private static GameObject Child(Transform parent, string name, Vector3 position)
        {
            var go = new GameObject(name); Undo.RegisterCreatedObjectUndo(go, "Create reception object");
            go.transform.SetParent(parent, false); go.transform.localPosition = position; return go;
        }

        private static void Visual(Transform parent, string name, Vector3 scale)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube); Undo.RegisterCreatedObjectUndo(go, "Create reception visual");
            go.name = name; go.transform.SetParent(parent, false); go.transform.localScale = scale;
            UnityEngine.Object.DestroyImmediate(go.GetComponent<Collider>());
        }

        internal static void Save(UdonSharpBehaviour component)
        {
            UdonSharpEditorUtility.CopyProxyToUdon(component); EditorUtility.SetDirty(component);
            var backing = UdonSharpEditorUtility.GetBackingUdonBehaviour(component); EditorUtility.SetDirty(backing);
            PrefabUtility.RecordPrefabInstancePropertyModifications(component); PrefabUtility.RecordPrefabInstancePropertyModifications(backing);
        }
    }
}
