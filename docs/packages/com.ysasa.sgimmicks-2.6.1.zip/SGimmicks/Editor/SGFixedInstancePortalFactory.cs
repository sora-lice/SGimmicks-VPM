using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UdonSharpEditor;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using VRC.SDK3.Components;

namespace SGimmicks.Editor
{
    internal static class SGFixedInstancePortalFactory
    {
        internal static bool TryResolve(string input, out string room, out string error)
        {
            room = "";
            error = "参加URL、または完全なRoom IDを入力してください。";
            if (string.IsNullOrWhiteSpace(input)) return false;
            input = input.Trim();
            if (input.Length > 4096) { error = "行き先が長すぎます。"; return false; }
            if (input.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
            {
                if (!Uri.TryCreate(input, UriKind.Absolute, out var uri) ||
                    (uri.Host != "vrchat.com" && uri.Host != "www.vrchat.com") ||
                    uri.AbsolutePath.TrimEnd('/') != "/home/launch" || !uri.IsDefaultPort ||
                    !string.IsNullOrEmpty(uri.UserInfo) || !string.IsNullOrEmpty(uri.Fragment))
                { error = "vrchat.com/home/launch の長い参加URLを使用してください。短縮URLは元の参加URLへ展開してください。"; return false; }
                var values = new Dictionary<string, string>(StringComparer.Ordinal);
                try
                {
                    foreach (string part in uri.Query.TrimStart('?').Split('&'))
                    {
                        int equals = part.IndexOf('=');
                        if (equals < 0) continue;
                        string key = Uri.UnescapeDataString(part.Substring(0, equals).Replace("+", " "));
                        if (key != "worldId" && key != "instanceId") continue;
                        if (values.ContainsKey(key)) { error = "worldIdまたはinstanceIdが重複しています。"; return false; }
                        values.Add(key, Uri.UnescapeDataString(part.Substring(equals + 1).Replace("+", " ")));
                    }
                }
                catch (UriFormatException) { error = "参加URLのエンコード形式を確認してください。"; return false; }
                if (!values.TryGetValue("worldId", out var world) || !values.TryGetValue("instanceId", out var instance))
                { error = "worldIdとinstanceIdの両方を含む参加URLが必要です。"; return false; }
                input = world + ":" + instance;
            }
            if (!Regex.IsMatch(input, @"\Awrld_[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}:[A-Za-z0-9_~().,=+/-]+\z"))
            { error = "完全なRoom IDは wrld_…:インスタンスID~タグ… の形式です。ワールドIDだけでは作成できません。"; return false; }
            int colon = input.IndexOf(':');
            string suffix = input.Substring(colon + 1);
            if (!Regex.IsMatch(suffix, @"\A[A-Za-z0-9_-]+(?:~|\z)"))
            { error = "インスタンス番号の形式を確認してください。"; return false; }
            int depth = 0;
            foreach (char c in suffix)
            {
                if (c == '(' && ++depth > 1) { error = "タグの括弧が不正です。"; return false; }
                if (c == ')' && --depth < 0) { error = "タグの括弧が不正です。"; return false; }
            }
            if (depth != 0) { error = "タグの括弧が閉じていません。"; return false; }
            room = input;
            error = "";
            return true;
        }

        internal static SGFixedInstancePortal Configure(SGFixedInstancePortal controller,
            Transform placement, string destination, bool refresh)
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
                throw new InvalidOperationException("再生モードを停止してください。");
            if (!TryResolve(destination, out var room, out var error)) throw new InvalidOperationException(error);
            if (controller != null && (EditorUtility.IsPersistent(controller) || !controller.gameObject.scene.IsValid()))
                throw new InvalidOperationException("既存コントローラーをHierarchyから指定してください。");
            if (placement != null && (EditorUtility.IsPersistent(placement) || !placement.gameObject.scene.IsValid()))
                throw new InvalidOperationException("配置位置をHierarchyから指定してください。");
            if (controller != null && placement != null && controller.gameObject.scene != placement.gameObject.scene)
                throw new InvalidOperationException("配置位置とコントローラーは同じシーンに置いてください。");
            GameObject template = controller != null ? controller.inactiveTemplate : null;
            if (template != null && (EditorUtility.IsPersistent(template) || template == controller.gameObject ||
                controller.transform.IsChildOf(template.transform) || template.scene != controller.gameObject.scene ||
                template.GetComponent<VRCPortalMarker>() == null))
                throw new InvalidOperationException("テンプレートは同じシーンにある、コントローラーを含まないVRCPortalMarkerにしてください。");
            if (controller == null)
            {
                var root = new GameObject("SGFixedInstancePortal");
                Undo.RegisterCreatedObjectUndo(root, "Create fixed instance portal");
                if (placement != null)
                {
                    UnityEngine.SceneManagement.SceneManager.MoveGameObjectToScene(root, placement.gameObject.scene);
                    root.transform.SetPositionAndRotation(placement.position, placement.rotation);
                }
                else if (SceneView.lastActiveSceneView != null)
                    root.transform.position = SceneView.lastActiveSceneView.pivot;
                controller = SGEditorFactory.AddBundledComponent<SGFixedInstancePortal>(root);
            }
            if (template == null)
            {
                const string path = "Packages/com.vrchat.worlds/Samples/UdonExampleScene/Prefabs/VRCPortalMarker.prefab";
                var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);
                if (prefab == null) throw new InvalidOperationException("SDKのVRCPortalMarkerプレハブが見つかりません。VRChat SDK Worldsを確認してください。");
                template = (GameObject)PrefabUtility.InstantiatePrefab(prefab, controller.gameObject.scene);
                Undo.RegisterCreatedObjectUndo(template, "Create inactive portal template");
                Undo.SetTransformParent(template.transform, controller.transform, "Parent portal template");
                template.name = "PortalTemplate_Inactive";
                template.transform.localPosition = Vector3.zero;
                template.transform.localRotation = Quaternion.identity;
                template.transform.localScale = Vector3.one;
            }
            Undo.RecordObject(template, "Disable portal template");
            template.SetActive(false);
            var marker = template.GetComponent<VRCPortalMarker>();
            Undo.RecordObject(marker, "Configure portal destination");
            // SDKのWorld=Noneを使い、Home/Hubへの上書きを防止します。
            var serialized = new SerializedObject(marker);
            serialized.FindProperty("world").intValue = 0;
            serialized.ApplyModifiedProperties();
            marker.roomId = room;
            marker.enabled = true;
            Undo.RecordObject(controller, "Configure fixed instance portal");
            controller.inactiveTemplate = template;
            controller.destinationRoomId = room;
            controller.refreshAfterActivation = refresh;
            UdonSharpEditorUtility.CopyProxyToUdon(controller);
            foreach (UnityEngine.Object item in new UnityEngine.Object[] { controller, marker, template })
            {
                EditorUtility.SetDirty(item);
                PrefabUtility.RecordPrefabInstancePropertyModifications(item);
            }
            EditorSceneManager.MarkSceneDirty(controller.gameObject.scene);
            Selection.activeGameObject = controller.gameObject;
            return controller;
        }
    }
}
