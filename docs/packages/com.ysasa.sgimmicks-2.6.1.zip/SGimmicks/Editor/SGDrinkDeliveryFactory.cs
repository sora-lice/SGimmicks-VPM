using System;
using System.Collections.Generic;
using System.Linq;
using UdonSharp;
using UdonSharpEditor;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;
using VRC.SDKBase;
using VRC.SDK3.Components;
using Object = UnityEngine.Object;

namespace SGimmicks.Editor
{
    internal static class SGDrinkDeliveryFactory
    {
        internal static SGDrinkDeliveryController Configure(SGDrinkDeliveryController system, BoxCollider area,
            VRC_Pickup[] cargo, Transform[] destinations, string[] labels, string[] drinks,
            Transform[] senderRoots, string[] senderLabels, int[] senderDestinations, Transform[] makerRoots,
            string[] makerNames)
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode) throw new InvalidOperationException("再生モードを停止してください。");
            if (!SGEditorFactory.IsRTabInstalled()) throw new InvalidOperationException("RTabを先にインポートしてください。RTab本体はSGimmicksには含まれません。");
            Validate(area, cargo, destinations, labels, drinks, senderRoots, senderLabels, senderDestinations, makerRoots);
            if (system != null && (EditorUtility.IsPersistent(system) || system.gameObject.scene != area.gameObject.scene))
                throw new InvalidOperationException("同じシーンの既存システムを指定してください。");
            var allRoots = senderRoots.Concat(makerRoots).ToArray();
            foreach (var other in Object.FindObjectsByType<SGDrinkDeliveryController>(FindObjectsInactive.Include, FindObjectsSortMode.None))
            {
                if (other == system) continue;
                if (other.cargo != null && other.cargo.Any(c => cargo.Contains(c)))
                    throw new InvalidOperationException("転送物が別の配送システムで登録済みです。");
            }
            foreach (Transform root in allRoots)
            {
                var old = root.GetComponentsInChildren<SGDrinkDeliveryApp>(true);
                if (old.Any(a => system == null || a.controller != system)) throw new InvalidOperationException("指定したAppsには配送アプリがあります。対応する既存システムを読み込んでください。");
            }
            if (system == null)
            {
                var go = new GameObject("SGDrinkDeliverySystem");
                Undo.RegisterCreatedObjectUndo(go, "Create drink delivery system");
                UnityEngine.SceneManagement.SceneManager.MoveGameObjectToScene(go, area.gameObject.scene);
                system = SGEditorFactory.AddBundledComponent<SGDrinkDeliveryController>(go);
            }
            Undo.RecordObject(system, "Configure drink delivery system");
            if (!system.gameObject.activeInHierarchy || allRoots.Any(t => system.transform.IsChildOf(t)))
                throw new InvalidOperationException("配送システムは常時有効な場所に置き、RTabのAppsの子にはしないでください。");
            Undo.RecordObject(area, "Configure delivery area");
            area.isTrigger = true;
            EditorUtility.SetDirty(area);
            PrefabUtility.RecordPrefabInstancePropertyModifications(area);
            for (int i = 0; i < system.orderNames.Length; i++) if (system.orderNames[i] == null) system.orderNames[i] = "";
            var oldApps = system.apps ?? new SGDrinkDeliveryApp[0];
            var sync = new VRCObjectSync[cargo.Length];
            var bodies = new Rigidbody[cargo.Length];
            var colliders = new Collider[cargo.Length];
            for (int i = 0; i < cargo.Length; i++)
            {
                sync[i] = cargo[i].GetComponent<VRCObjectSync>();
                if (sync[i] == null) sync[i] = Undo.AddComponent<VRCObjectSync>(cargo[i].gameObject);
                // Collision transfers could undo ownership while a batch is being prepared.
                Undo.RecordObject(sync[i], "Prepare delivery object sync");
                sync[i].AllowCollisionOwnershipTransfer = false;
                PrefabUtility.RecordPrefabInstancePropertyModifications(sync[i]);
                bodies[i] = cargo[i].GetComponent<Rigidbody>();
                colliders[i] = cargo[i].GetComponent<Collider>();
            }
            system.transferArea = area; system.cargo = cargo;
            system.cargoSync = sync; system.cargoBodies = bodies; system.cargoColliders = colliders;
            system.destinations = destinations; system.destinationLabels = labels.Select(s => s.Trim()).ToArray();
            system.drinks = drinks.Select(s => s.Trim()).ToArray();
            system.makerDisplayNames = makerNames == null ? new string[0] : makerNames.Where(s => !string.IsNullOrWhiteSpace(s)).Select(s => s.Trim()).Distinct().ToArray();
            var apps = new SGDrinkDeliveryApp[allRoots.Length];
            for (int i = 0; i < allRoots.Length; i++)
            {
                bool maker = i >= senderRoots.Length;
                Transform root = allRoots[i];
                var app = root.GetComponentsInChildren<SGDrinkDeliveryApp>(true).FirstOrDefault(a => a.controller == system && a.transform.parent == root);
                if (app == null)
                {
                    var go = new GameObject(maker ? "SGDrinkMakerApp" : "SGDrinkOrderApp", typeof(RectTransform), typeof(Image), typeof(CanvasGroup));
                    Undo.RegisterCreatedObjectUndo(go, "Create RTab drink app");
                    Undo.SetTransformParent(go.transform, root, "Parent RTab drink app");
                    app = SGEditorFactory.AddBundledComponent<SGDrinkDeliveryApp>(go);
                }
                Undo.RecordObject(app, "Configure drink app");
                app.controller = system; app.viewIndex = i; app.isMaker = maker;
                app.tabletLabel = maker ? "作成者" : senderLabels[i].Trim();
                app.destinationIndex = maker ? 0 : senderDestinations[i];
                app.tabletPickup = root.GetComponentInParent<VRC_Pickup>();
                ConfigureAdapter(app, maker);
                BuildUI(app);
                SGEditorFactory.ConfigureRTabAppRoot(app.gameObject);
                Save(app);
                apps[i] = app;
            }
            // Only obsolete SGimmicks drink apps are removed; unrelated RTab apps are untouched.
            foreach (var app in oldApps)
                if (app != null && !apps.Contains(app)) Undo.DestroyObjectImmediate(app.gameObject);
            system.apps = apps;
            Save(system);
            foreach (var app in apps) { app._Refresh(); Save(app); }
            AssetDatabase.SaveAssets();
            EditorSceneManager.MarkSceneDirty(system.gameObject.scene);
            Selection.activeGameObject = system.gameObject;
            return system;
        }

        private static void Save(UdonSharpBehaviour value)
        {
            UdonSharpEditorUtility.CopyProxyToUdon(value);
            EditorUtility.SetDirty(value);
            var backing = UdonSharpEditorUtility.GetBackingUdonBehaviour(value);
            EditorUtility.SetDirty(backing);
            PrefabUtility.RecordPrefabInstancePropertyModifications(value);
            PrefabUtility.RecordPrefabInstancePropertyModifications(backing);
        }

        private static void Validate(BoxCollider area, VRC_Pickup[] cargo, Transform[] destinations,
            string[] labels, string[] drinks, Transform[] senders, string[] senderLabels, int[] receiverIds, Transform[] makers)
        {
            if (area == null || EditorUtility.IsPersistent(area) || !area.gameObject.scene.IsValid())
                throw new InvalidOperationException("Hierarchyから転送範囲のBoxColliderを指定してください。");
            if (!area.enabled || !area.gameObject.activeInHierarchy || Mathf.Min(area.size.x, Mathf.Min(area.size.y, area.size.z)) <= 0f)
                throw new InvalidOperationException("転送範囲を有効にし、大きさを0より大きくしてください。");
            if (cargo == null || cargo.Length == 0 || cargo.Length > 128 || cargo.Any(p => p == null) || cargo.Distinct().Count() != cargo.Length)
                throw new InvalidOperationException("転送するPickupを1〜128個、重複なく登録してください。");
            if (destinations == null || destinations.Length == 0 || labels == null || labels.Length != destinations.Length ||
                destinations.Any(t => t == null) || labels.Any(string.IsNullOrWhiteSpace))
                throw new InvalidOperationException("転送先を1個以上登録し、各地点と表示名を指定してください。");
            if (drinks == null || drinks.Length == 0 || drinks.Length > 64 || drinks.Any(string.IsNullOrWhiteSpace) || drinks.Select(s => s.Trim()).Distinct().Count() != drinks.Length)
                throw new InvalidOperationException("ドリンク名を1〜64個、空欄・重複なしで登録してください。");
            if (senders == null || makers == null || senders.Length == 0 || makers.Length == 0 ||
                senderLabels == null || senderLabels.Length != senders.Length || senderLabels.Any(string.IsNullOrWhiteSpace) ||
                receiverIds == null || receiverIds.Length != senders.Length || receiverIds.Any(i => i < 0 || i >= destinations.Length))
                throw new InvalidOperationException("注文側・作成者側のAppsをそれぞれ1台以上登録し、注文側の表示名と受け取り先を指定してください。");
            var roots = senders.Concat(makers).ToArray();
            if (roots.Length > 32 || roots.Any(t => t == null) || roots.Distinct().Count() != roots.Length)
                throw new InvalidOperationException("タブレットのAppsは合計32個まで、空欄・重複なしで指定してください。");
            foreach (Transform t in destinations.Concat(roots))
                if (EditorUtility.IsPersistent(t) || t.gameObject.scene != area.gameObject.scene)
                    throw new InvalidOperationException("全て同じシーンのHierarchyから指定してください。");
            foreach (Transform root in roots)
            {
                if (root.name != "Apps" || root.GetComponent<RectTransform>() == null)
                    throw new InvalidOperationException("RTab本体ではなく、配下のApps（RectTransform）を指定してください。");
                if (roots.Any(other => other != root && (other.IsChildOf(root) || root.IsChildOf(other))))
                    throw new InvalidOperationException("Appsを互いの子にしないでください。");
            }
            foreach (var pickup in cargo)
            {
                if (EditorUtility.IsPersistent(pickup) || pickup.gameObject.scene != area.gameObject.scene ||
                    pickup.GetComponent<Rigidbody>() == null || pickup.GetComponent<Collider>() == null)
                    throw new InvalidOperationException("転送するPickupと同じオブジェクトにRigidbodyとColliderが必要です（同じシーン内）。");
                if (cargo.Any(p => p != pickup && (p.transform.IsChildOf(pickup.transform) || pickup.transform.IsChildOf(p.transform))))
                    throw new InvalidOperationException("親子のPickupを二重に登録しないでください。");
                if (roots.Any(t => t.IsChildOf(pickup.transform)) || area.transform.IsChildOf(pickup.transform) || destinations.Any(t => t.IsChildOf(pickup.transform)))
                    throw new InvalidOperationException("タブレット本体・転送範囲・転送先を含む物は転送対象にできません。");
                if (pickup.transform.parent != null && pickup.transform.parent.GetComponentInParent<VRCObjectSync>() != null)
                    throw new InvalidOperationException("転送するPickupは別のObjectSyncの子にしないでください。");
                if (pickup.GetComponentsInChildren<VRCObjectSync>(true).Any(s => s.gameObject != pickup.gameObject))
                    throw new InvalidOperationException("転送物の子に別のObjectSyncがあります。登録する小物は独立させてください。");
                foreach (Transform t in pickup.GetComponentsInChildren<Transform>(true))
                    if ((GameObjectUtility.GetStaticEditorFlags(t.gameObject) & StaticEditorFlags.BatchingStatic) != 0)
                        throw new InvalidOperationException("転送する小物と子のBatching Staticを無効にしてください。");
                foreach (var u in pickup.GetComponents<VRC.Udon.UdonBehaviour>())
                    if (u.SyncMethod == Networking.SyncType.Manual)
                        throw new InvalidOperationException("Manual同期のUdonが同じ小物にあります。ObjectSyncと競合するため、別のルートへ分離してください。");
            }
        }

        private static void ConfigureAdapter(SGDrinkDeliveryApp app, bool maker)
        {
            SGEditorFactory.ConfigureRTabAppRoot(app.gameObject);
            Type type = SGEditorFactory.FindType("Rasta.Tablet.TabletAppBehaviour", "TabletAppBehaviour");
            Component adapter = app.GetComponent(type);
            if (adapter == null) adapter = typeof(UdonSharpBehaviour).IsAssignableFrom(type) ?
                UdonSharpUndo.AddComponent(app.gameObject, type) : Undo.AddComponent(app.gameObject, type);
            SGEditorFactory.SetRTabAppSettings(adapter, Icon(), maker ? "ドリンク作成・転送" : "ドリンク注文", "SGimmicks");
            if (adapter is UdonSharpBehaviour udon) Save(udon);
        }

        private static Texture2D Icon()
        {
            SGEditorFactory.EnsureAssetFolders();
            string path = SGEditorFactory.GeneratedFolder + "/SGDrinkDeliveryIcon.asset";
            var icon = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
            if (icon != null) return icon;
            icon = new Texture2D(64, 64, TextureFormat.RGBA32, false) { name = "SGDrinkDeliveryIcon" };
            var pixels = new Color[4096];
            for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++)
            {
                bool cup = y > 12 && y < 48 && x > 18 && x < 46 && (x < 21 || x > 42 || y < 16 || y > 43);
                bool drink = y > 17 && y < 34 && x > 22 && x < 42;
                bool straw = x > 35 && x < 39 && y > 33 && y < 56;
                pixels[y * 64 + x] = cup || straw ? new Color(0.8f, 1f, 0.98f) : drink ? new Color(0.2f,0.85f,0.65f) : new Color(0.04f,0.1f,0.17f);
            }
            icon.SetPixels(pixels); icon.Apply(); AssetDatabase.CreateAsset(icon, path);
            return icon;
        }

        private static void BuildUI(SGDrinkDeliveryApp app)
        {
            Transform old = app.transform.Find("DrinkDeliveryUI");
            if (old != null) Undo.DestroyObjectImmediate(old.gameObject);
            var go = new GameObject("DrinkDeliveryUI", typeof(RectTransform));
            Undo.RegisterCreatedObjectUndo(go, "Create drink app UI");
            go.transform.SetParent(app.transform, false);
            var rect = go.GetComponent<RectTransform>();
            rect.anchorMin = Vector2.zero; rect.anchorMax = Vector2.one; rect.offsetMin = rect.offsetMax = Vector2.zero;
            app.titleText = Text(rect, "Title", "ドリンク", 0.88f, 0.98f, 42);
            app.modeText = Text(rect, "Mode", "", 0.78f, 0.87f, 30);
            app.selectionText = Text(rect, "Selection", "", 0.64f, 0.77f, 40);
            Button(rect, "Previous", "＜ 前へ", 0.04f, 0.56f, 0.33f, 0.64f, app, "_Previous");
            Button(rect, "Next", "次へ ＞", 0.67f, 0.56f, 0.96f, 0.64f, app, "_Next");
            if (app.isMaker) Button(rect, "ModeSwitch", "注文／手動", 0.34f, 0.56f, 0.66f, 0.64f, app, "_ToggleMode");
            app.listText = Text(rect, "Orders", "", app.isMaker ? 0.26f : 0.28f, 0.55f, 25);
            app.listText.alignment = TextAnchor.UpperLeft;
            app.statusText = Text(rect, "Status", "操作できます", 0.15f, 0.25f, 28);
            Button(rect, "Submit", app.isMaker ? "エリア内の小物を全部転送" : "このドリンクを注文", 0.05f, 0.03f, app.isMaker ? 0.72f : 0.95f, 0.14f, app, "_Submit");
            if (app.isMaker) Button(rect, "Cancel", "注文取消", 0.73f, 0.03f, 0.95f, 0.14f, app, "_CancelOrder");
        }
        private static Text Text(RectTransform p, string name, string value, float bottom, float top, int size)
        {
            var text = SGEditorFactory.CreateTabletText(p, name, value, new Vector2(0.04f,bottom), new Vector2(0.96f,top), size, new Color(0.9f,0.97f,1f));
            text.supportRichText = false; return text;
        }
        private static void Button(RectTransform p, string name, string label, float left, float bottom, float right, float top, SGDrinkDeliveryApp app, string method)
        {
            SGEditorFactory.CreateTabletButton(p, name, label, new Vector2(left,bottom), new Vector2(right,top), app, method, new Color(0.08f,0.3f,0.38f), 30);
        }
    }
}
