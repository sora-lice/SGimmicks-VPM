using System;
using UnityEditor;
using UnityEngine;

namespace SGimmicks.Editor
{
    public sealed class SGLocalAutoDoorWindow : EditorWindow
    {
        [SerializeField] private SGLocalAutoDoorController _controller;
        [SerializeField] private BoxCollider _area;
        [SerializeField] private Transform _first;
        [SerializeField] private Transform _second;
        [SerializeField] private bool _doubleDoor;
        [SerializeField] private Vector3 _firstOffset = new Vector3(-1f, 0f, 0f);
        [SerializeField] private Vector3 _secondOffset = new Vector3(1f, 0f, 0f);
        [SerializeField] private float _openTime = 0.8f;
        [SerializeField] private float _closeTime = 0.8f;
        [SerializeField] private float _delay = 1f;
        private Vector2 _scroll;

        [MenuItem("SGimmicks/ローカル自動ドアを設定", priority = 15)]
        public static void Open()
        {
            var window = GetWindow<SGLocalAutoDoorWindow>("SGimmicks 自動ドア");
            window.minSize = new Vector2(550f, 510f);
            window.Show();
        }

        private void OnGUI()
        {
            _scroll = EditorGUILayout.BeginScrollView(_scroll);
            EditorGUILayout.LabelField("ローカル自動ドア", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("検知範囲に入った本人の画面でだけ開き、本人が出ると閉じます。他のプレイヤーの出入りには反応せず、開閉・扉の当たり判定も他人には同期しません。", MessageType.Info);
            EditorGUI.BeginChangeCheck();
            _controller = (SGLocalAutoDoorController)EditorGUILayout.ObjectField("既存コントローラー", _controller, typeof(SGLocalAutoDoorController), true);
            if (EditorGUI.EndChangeCheck() && _controller != null) Load(_controller);
            if (GUILayout.Button("選択中の自動ドアを読み込む"))
            {
                var selected = Selection.activeGameObject != null ? Selection.activeGameObject.GetComponentInParent<SGLocalAutoDoorController>() : null;
                if (selected != null) Load(selected);
                else ShowNotification(new GUIContent("Hierarchyで検知範囲のオブジェクトを選択してください"));
            }
            _doubleDoor = EditorGUILayout.Popup("開き方", _doubleDoor ? 1 : 0, new[] { "片開き", "両開き" }) == 1;
            _first = (Transform)EditorGUILayout.ObjectField(_doubleDoor ? "扉1（左側など）" : "動かす扉", _first, typeof(Transform), true);
            _firstOffset = EditorGUILayout.Vector3Field("扉1の移動量", _firstOffset);
            if (_doubleDoor)
            {
                _second = (Transform)EditorGUILayout.ObjectField("扉2（右側など）", _second, typeof(Transform), true);
                _secondOffset = EditorGUILayout.Vector3Field("扉2の移動量", _secondOffset);
            }
            _area = (BoxCollider)EditorGUILayout.ObjectField(new GUIContent("検知範囲（省略時は生成）", "既存ドアではコントローラーと同じオブジェクトのBoxColliderを使用します。"), _area, typeof(BoxCollider), true);
            _openTime = Mathf.Max(0.01f, EditorGUILayout.FloatField("開く時間（秒）", _openTime));
            _closeTime = Mathf.Max(0.01f, EditorGUILayout.FloatField("閉じる時間（秒）", _closeTime));
            _delay = Mathf.Max(0f, EditorGUILayout.FloatField("退出後の待ち時間（秒）", _delay));
            EditorGUILayout.HelpBox("移動量は各扉の親の座標系です。Xは左右、Yは上下、Zは前後（親の回転・Scaleに従います）。例：扉1はX=-1、扉2はX=1。Unityでは扉を閉じた位置に配置しておいてください。更新しても扉や範囲の位置・大きさは変更しません。", MessageType.None);
            bool missing = _first == null || (_doubleDoor && _second == null);
            if (missing) EditorGUILayout.HelpBox("作成するには、Hierarchyから動かす扉を指定してください。両開きでは扉を2個指定します。", MessageType.Warning);
            using (new EditorGUI.DisabledScope(missing || EditorApplication.isPlayingOrWillChangePlaymode))
            {
                if (GUILayout.Button(_controller == null ? "ローカル自動ドアを作成" : "設定を更新（配置を維持）", GUILayout.Height(40f))) Apply();
            }
            if (_controller != null && GUILayout.Button("検知範囲を選択して調整"))
            {
                Selection.activeGameObject = _controller.gameObject;
                SceneView.FrameLastActiveSceneView();
            }
            EditorGUILayout.HelpBox("検知範囲はInspectorのBoxCollider → Edit Colliderで調整します。触れる前に開くよう、扉の前後へ十分に広げてください。扉のAnimator、Constraint、ObjectSyncなどで同じ位置を同時に制御しないでください。", MessageType.None);
            EditorGUILayout.EndScrollView();
        }

        private void Load(SGLocalAutoDoorController value)
        {
            _controller = value;
            _area = value.detectionArea;
            _first = value.firstDoor;
            _second = value.secondDoor;
            _doubleDoor = value.doubleDoor;
            _firstOffset = value.firstOpenOffset;
            _secondOffset = value.secondOpenOffset;
            _openTime = value.openingDuration;
            _closeTime = value.closingDuration;
            _delay = value.closeDelay;
        }

        private void Apply()
        {
            Undo.IncrementCurrentGroup();
            int group = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName("Configure SG local auto door");
            try
            {
                Load(SGLocalAutoDoorFactory.Configure(_controller, _area, _first, _second, _doubleDoor,
                    _firstOffset, _secondOffset, _openTime, _closeTime, _delay));
                Undo.CollapseUndoOperations(group);
                ShowNotification(new GUIContent("設定しました。シーンを保存してください"));
            }
            catch (Exception e)
            {
                Undo.RevertAllDownToGroup(group);
                Debug.LogException(e);
                EditorUtility.DisplayDialog("SGimmicks 自動ドア", e.Message, "OK");
            }
        }
    }
}
