using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace SGimmicks.Editor
{
    public sealed class SGBakedPortalTestWindow : EditorWindow
    {
        [SerializeField] private string _destination = "";
        [SerializeField] private string _observed = "";
        private SGBakedPortalTestCase _test;
        private string _status = "";
        private Vector2 _scroll;

        [MenuItem("SGimmicks/ポータル直接配置テスト", priority = 19)]
        public static void Open()
        {
            var window = GetWindow<SGBakedPortalTestWindow>("SGimmicks 直接配置テスト");
            window.minSize = new Vector2(630, 620);
            window.Show();
        }

        private void OnGUI()
        {
            _scroll = EditorGUILayout.BeginScrollView(_scroll);
            EditorGUILayout.LabelField("ポータル直接配置テスト", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("既存Inviteへの固定移動は未確認です。実行時コードを付けず、最初から有効なSDKポータルを2基置く新規の検証専用シーンを作ります。", MessageType.Info);
            EditorGUILayout.LabelField("使い捨てテスト先の参加URL または 完全location");
            _destination = EditorGUILayout.TextArea(_destination, GUILayout.MinHeight(60));
            bool valid = SGFixedInstancePortalFactory.TryResolve(_destination, out var room, out var error);
            if (valid) EditorGUILayout.SelectableLabel(room, EditorStyles.textArea, GUILayout.Height(50));
            else EditorGUILayout.HelpBox(error, MessageType.Info);
            bool dirty = SGBakedPortalTestFactory.HasUnsavedScenes();
            if (dirty) EditorGUILayout.HelpBox("開いているシーンを先に保存してください。新規作成時に保存済みのシーンを閉じ、検証シーンへ切り替えます。", MessageType.Warning);
            using (new EditorGUI.DisabledScope(!valid || dirty || EditorApplication.isPlayingOrWillChangePlaymode))
                if (GUILayout.Button("新規の検証ワールドを作成（A・Bを自動配置）", GUILayout.Height(40)))
                    Run(() => { _test = SGBakedPortalTestFactory.Create(_destination); _status = "検証シーンを作成しました。右のBを先に試してください。"; });
            EditorGUILayout.HelpBox("本番シーンをコピーせず、空のBlueprint IDで新規作成します。SDKの公開先が新規または試験用であることを確認し、非公開でアップロードしてください。入口は新しいインスタンスで開きます。", MessageType.None);
            if (GUILayout.Button("現在の検証シーンを読み込み・点検"))
                Run(() => { _test = SGBakedPortalTestFactory.Load(SceneManager.GetActiveScene()); _destination = _test.expected_location; _status = string.Join("\n", SGBakedPortalTestFactory.Audit(SceneManager.GetActiveScene(), _test)); });
            if (_test != null)
            {
                EditorGUILayout.LabelField("試験ID", _test.case_id);
                EditorGUILayout.SelectableLabel(_test.scene_path, EditorStyles.textField, GUILayout.Height(22));
                if (GUILayout.Button("試験データと結果記入用ファイルを開く"))
                    EditorUtility.RevealInFinder(Path.GetFullPath(Path.GetDirectoryName(_test.scene_path)));
            }
            EditorGUILayout.Space(10);
            EditorGUILayout.LabelField("実機試験後のlocation照合", EditorStyles.boldLabel);
            EditorGUILayout.LabelField("着地した場所の完全location または 参加URL");
            _observed = EditorGUILayout.TextArea(_observed, GUILayout.MinHeight(55));
            using (new EditorGUI.DisabledScope(!valid || string.IsNullOrWhiteSpace(_observed)))
                if (GUILayout.Button("指定先と照合する")) Run(() => _status = SGBakedPortalTestFactory.Compare(_destination, _observed));
            if (!string.IsNullOrEmpty(_status)) EditorGUILayout.HelpBox(_status, MessageType.Info);
            EditorGUILayout.HelpBox("オーナーは行き先に滞在。ゲストは通常招待で同室確認後、入口へ移動します。右Bを試してログ・同室を記録し、入口へ戻って左Aも試します。成功後は別の使い捨てインスタンスで再現確認します。", MessageType.None);
            EditorGUILayout.EndScrollView();
        }

        private void Run(Action action)
        {
            try { action(); }
            catch (Exception e)
            {
                _status = e.Message;
                Debug.LogException(e);
                EditorUtility.DisplayDialog("SGimmicks 直接配置テスト", e.Message, "OK");
            }
        }
    }
}
