using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using VRC.SDKBase;

namespace SGimmicks.Editor
{
    public sealed class SGDrinkDeliveryWindow : EditorWindow
    {
        [SerializeField] private SGDrinkDeliveryController _system;
        [SerializeField] private BoxCollider _area;
        [SerializeField] private List<VRC_Pickup> _cargo = new List<VRC_Pickup> { null };
        [SerializeField] private List<Transform> _destinations = new List<Transform> { null };
        [SerializeField] private List<string> _destinationLabels = new List<string> { "受け取り地点1" };
        [SerializeField] private List<string> _drinks = new List<string> { "お水", "お茶", "コーヒー" };
        [SerializeField] private List<Transform> _senderRoots = new List<Transform> { null };
        [SerializeField] private List<string> _senderLabels = new List<string> { "注文タブレット1" };
        [SerializeField] private List<int> _senderDestinations = new List<int> { 0 };
        [SerializeField] private List<Transform> _makerRoots = new List<Transform> { null };
        [SerializeField] private string _makerNames = "";
        private Vector2 _scroll;

        [MenuItem("SGimmicks/RTabドリンク注文・物体転送を設定", priority = 16)]
        public static void Open()
        {
            var w = GetWindow<SGDrinkDeliveryWindow>("SGimmicks 注文・転送");
            w.minSize = new Vector2(640f, 620f); w.Show();
        }

        private void OnGUI()
        {
            _scroll = EditorGUILayout.BeginScrollView(_scroll);
            EditorGUILayout.LabelField("RTab ドリンク注文・物体一括転送", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("注文側のRTabからドリンクを選択 → 作成者のRTabに注文を表示 → 作成者が手作業で用意した小物を範囲内に置いて一括転送します。受け取り地点は送信タブレットごとに固定登録し、物体の移動を全員へ同期します。", MessageType.Info);
            if (!SGEditorFactory.IsRTabInstalled()) EditorGUILayout.HelpBox("RTabを先にインポートしてください。RTab本体は同梱していません。", MessageType.Warning);
            EditorGUI.BeginChangeCheck();
            _system = (SGDrinkDeliveryController)EditorGUILayout.ObjectField("既存の配送システム", _system, typeof(SGDrinkDeliveryController), true);
            if (EditorGUI.EndChangeCheck() && _system != null) Load(_system);
            if (GUILayout.Button("選択中の配送システムを読み込む"))
            {
                var go = Selection.activeGameObject;
                var found = go != null ? go.GetComponent<SGDrinkDeliveryController>() : null;
                var app = go != null ? go.GetComponentInParent<SGDrinkDeliveryApp>() : null;
                if (found == null && app != null) found = app.controller;
                if (found != null) Load(found);
                else ShowNotification(new GUIContent("システムまたは配送アプリをHierarchyで選択してください"));
            }
            _area = (BoxCollider)EditorGUILayout.ObjectField("転送範囲（BoxCollider）", _area, typeof(BoxCollider), true);
            EditorGUILayout.HelpBox("範囲はIs Triggerに設定します。登録物のColliderの中心が範囲内なら対象です。受け取り地点はこのBoxの中心に対応し、物同士の間隔・向きを保ちます。", MessageType.None);
            EditorGUILayout.LabelField("転送できる小物（Pickup）", EditorStyles.boldLabel);
            for (int i = 0; i < _cargo.Count; i++)
            {
                EditorGUILayout.BeginHorizontal();
                _cargo[i] = (VRC_Pickup)EditorGUILayout.ObjectField("小物 " + (i+1), _cargo[i], typeof(VRC_Pickup), true);
                if (GUILayout.Button("削除", GUILayout.Width(48f))) { _cargo.RemoveAt(i--); }
                EditorGUILayout.EndHorizontal();
            }
            if (GUILayout.Button("＋ 小物を追加")) _cargo.Add(null);
            EditorGUILayout.LabelField("転送先一覧", EditorStyles.boldLabel);
            for (int i = 0; i < _destinations.Count; i++)
            {
                EditorGUILayout.BeginHorizontal();
                _destinationLabels[i] = EditorGUILayout.TextField(_destinationLabels[i], GUILayout.Width(150f));
                _destinations[i] = (Transform)EditorGUILayout.ObjectField(_destinations[i], typeof(Transform), true);
                if (GUILayout.Button("削除", GUILayout.Width(48f)))
                {
                    for (int k = 0; k < _senderDestinations.Count; k++)
                        _senderDestinations[k] = _senderDestinations[k] == i ? 0 : _senderDestinations[k] > i ? _senderDestinations[k]-1 : _senderDestinations[k];
                    _destinations.RemoveAt(i); _destinationLabels.RemoveAt(i--);
                }
                EditorGUILayout.EndHorizontal();
            }
            if (GUILayout.Button("＋ 転送先を追加")) { _destinations.Add(null); _destinationLabels.Add("受け取り地点" + _destinations.Count); }
            EditorGUILayout.LabelField("注文できるドリンク名", EditorStyles.boldLabel);
            for (int i = 0; i < _drinks.Count; i++)
            {
                EditorGUILayout.BeginHorizontal(); _drinks[i] = EditorGUILayout.TextField(_drinks[i]);
                if (GUILayout.Button("削除", GUILayout.Width(48f))) _drinks.RemoveAt(i--);
                EditorGUILayout.EndHorizontal();
            }
            if (GUILayout.Button("＋ ドリンク名を追加")) _drinks.Add("ドリンク" + (_drinks.Count+1));
            EditorGUILayout.LabelField("注文を送るRTab（Appsを指定）", EditorStyles.boldLabel);
            string[] choices = _destinationLabels.Select((s,i) => (i+1)+"："+s).ToArray();
            for (int i = 0; i < _senderRoots.Count; i++)
            {
                EditorGUILayout.BeginVertical(EditorStyles.helpBox);
                _senderLabels[i] = EditorGUILayout.TextField("タブレット名", _senderLabels[i]);
                _senderRoots[i] = (Transform)EditorGUILayout.ObjectField("RTab/Apps", _senderRoots[i], typeof(Transform), true);
                if (choices.Length > 0) _senderDestinations[i] = EditorGUILayout.Popup("このタブレットの受取先", Mathf.Clamp(_senderDestinations[i],0,choices.Length-1), choices);
                if (GUILayout.Button("この注文タブレットを削除")) { _senderRoots.RemoveAt(i); _senderLabels.RemoveAt(i); _senderDestinations.RemoveAt(i--); }
                EditorGUILayout.EndVertical();
            }
            if (GUILayout.Button("＋ 注文タブレットを追加")) { _senderRoots.Add(null); _senderLabels.Add("注文タブレット"+_senderRoots.Count); _senderDestinations.Add(0); }
            EditorGUILayout.LabelField("作成・転送を行うRTab（Appsを指定）", EditorStyles.boldLabel);
            for (int i = 0; i < _makerRoots.Count; i++)
            {
                EditorGUILayout.BeginHorizontal();
                _makerRoots[i] = (Transform)EditorGUILayout.ObjectField("作成者 " + (i+1), _makerRoots[i], typeof(Transform), true);
                if (GUILayout.Button("削除", GUILayout.Width(48f))) _makerRoots.RemoveAt(i--);
                EditorGUILayout.EndHorizontal();
            }
            if (GUILayout.Button("＋ 作成者タブレットを追加")) _makerRoots.Add(null);
            EditorGUILayout.LabelField("作成・転送を許可する表示名（任意・1行1人）");
            _makerNames = EditorGUILayout.TextArea(_makerNames, GUILayout.MinHeight(45f));
            EditorGUILayout.HelpBox("空欄なら作成者タブレットを操作できる全員が転送できます。表示名は大文字・小文字を区別します。注文は未完了32件まで。ドリンクは自動生成しません。小物にはObjectSyncを自動追加し、衝突による所有権移動を無効にします。", MessageType.None);
            bool ready = _area != null && _cargo.Count > 0 && _cargo.All(p => p != null) && _destinations.Count > 0 && _destinations.All(t => t != null) &&
                _drinks.Count > 0 && _senderRoots.Count > 0 && _senderRoots.All(t => t != null) && _makerRoots.Count > 0 && _makerRoots.All(t => t != null);
            if (!ready) EditorGUILayout.HelpBox("作成には範囲・小物・転送先・注文側と作成者側のAppsを全て指定してください。", MessageType.Warning);
            using (new EditorGUI.DisabledScope(!ready || !SGEditorFactory.IsRTabInstalled() || EditorApplication.isPlayingOrWillChangePlaymode))
                if (GUILayout.Button(_system == null ? "注文・転送アプリを一括作成" : "設定・アプリUIを更新（物体配置を維持）", GUILayout.Height(40f))) Apply();
            EditorGUILayout.EndScrollView();
        }

        private void Load(SGDrinkDeliveryController value)
        {
            _system = value; _area = value.transferArea;
            _cargo = new List<VRC_Pickup>(value.cargo ?? new VRC_Pickup[0]);
            _destinations = new List<Transform>(value.destinations ?? new Transform[0]);
            _destinationLabels = new List<string>(value.destinationLabels ?? new string[0]);
            _drinks = new List<string>(value.drinks ?? new string[0]);
            var apps = value.apps ?? new SGDrinkDeliveryApp[0];
            _senderRoots = apps.Where(a => a != null && !a.isMaker).Select(a => a.transform.parent).ToList();
            _senderLabels = apps.Where(a => a != null && !a.isMaker).Select(a => a.tabletLabel).ToList();
            _senderDestinations = apps.Where(a => a != null && !a.isMaker).Select(a => a.destinationIndex).ToList();
            _makerRoots = apps.Where(a => a != null && a.isMaker).Select(a => a.transform.parent).ToList();
            _makerNames = string.Join("\n", value.makerDisplayNames ?? new string[0]);
        }
        private void Apply()
        {
            Undo.IncrementCurrentGroup(); int group = Undo.GetCurrentGroup(); Undo.SetCurrentGroupName("Configure SG drink delivery");
            try
            {
                Load(SGDrinkDeliveryFactory.Configure(_system,_area,_cargo.ToArray(),_destinations.ToArray(),_destinationLabels.ToArray(),_drinks.ToArray(),
                    _senderRoots.ToArray(),_senderLabels.ToArray(),_senderDestinations.ToArray(),_makerRoots.ToArray(),_makerNames.Split(new[]{'\r','\n'},StringSplitOptions.RemoveEmptyEntries)));
                Undo.CollapseUndoOperations(group);
                ShowNotification(new GUIContent("作成・更新しました。シーンを保存してください"));
            }
            catch (Exception e) { Undo.RevertAllDownToGroup(group); Debug.LogException(e); EditorUtility.DisplayDialog("SGimmicks 注文・転送",e.Message,"OK"); }
        }
    }
}
