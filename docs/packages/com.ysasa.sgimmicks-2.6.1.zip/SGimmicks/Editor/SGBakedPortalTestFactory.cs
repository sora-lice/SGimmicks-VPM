using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using VRC.SDK3.Components;
using VRC.Udon;

namespace SGimmicks.Editor
{
    [Serializable]
    public sealed class SGBakedPortalTestCase
    {
        public int schema_version = 1;
        public string method = "scene_baked_active_portals";
        public string case_id;
        public string created_utc;
        public string unity_version;
        public string sdk_version;
        public string scene_path;
        public string expected_location;
        public string world_id;
        public string initial_blueprint_id = "";
    }

    internal static class SGBakedPortalTestFactory
    {
        internal const string OutputRoot = "Assets/SGimmicksPortalTests";
        internal const string ControlName = "Portal_A_WorldOnly";
        internal const string FixedName = "Portal_B_ExactLocation";

        internal static bool HasUnsavedScenes()
        {
            for (int i = 0; i < SceneManager.sceneCount; i++)
                if (SceneManager.GetSceneAt(i).isDirty) return true;
            return false;
        }

        internal static SGBakedPortalTestCase Create(string input)
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
                throw new InvalidOperationException("再生モードを停止してください。");
            if (!SGFixedInstancePortalFactory.TryResolve(input, out var room, out var error))
                throw new InvalidOperationException(error);
            if (HasUnsavedScenes())
                throw new InvalidOperationException("開いているシーンを保存してから作成してください。未保存のシーンは閉じません。");
            string id = Guid.NewGuid().ToString("N");
            EnsureFolder(OutputRoot);
            string folder = OutputRoot + "/Case_" + id;
            AssetDatabase.CreateFolder(OutputRoot, "Case_" + id);
            var test = new SGBakedPortalTestCase
            {
                case_id = id,
                created_utc = DateTime.UtcNow.ToString("o"),
                unity_version = Application.unityVersion,
                sdk_version = UnityEditor.PackageManager.PackageInfo.FindForAssetPath("Packages/com.vrchat.worlds")?.version ?? "unknown",
                scene_path = folder + "/PortalBakeTest_" + id.Substring(0, 8) + ".unity",
                expected_location = room,
                world_id = room.Substring(0, room.IndexOf(':'))
            };
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            var descriptor = new GameObject("VRCWorld_TestOnly").AddComponent<VRCSceneDescriptor>();
            var pipeline = descriptor.GetComponent<VRC.Core.PipelineManager>();
            if (pipeline == null) pipeline = descriptor.gameObject.AddComponent<VRC.Core.PipelineManager>();
            pipeline.blueprintId = "";
            var spawn = new GameObject("TestSpawn").transform;
            spawn.position = new Vector3(0, .05f, -4);
            descriptor.spawns = new[] { spawn };
            descriptor.RespawnHeightY = -20;
            var floorMaterial = new Material(Shader.Find("Standard"));
            floorMaterial.color = new Color(.16f, .19f, .24f);
            AssetDatabase.CreateAsset(floorMaterial, folder + "/Floor.mat");
            var floor = GameObject.CreatePrimitive(PrimitiveType.Cube);
            floor.name = "TestFloor";
            floor.transform.position = new Vector3(0, -.1f, 1);
            floor.transform.localScale = new Vector3(18, .2f, 18);
            floor.GetComponent<Renderer>().sharedMaterial = floorMaterial;
            var light = new GameObject("TestLight").AddComponent<Light>();
            light.type = LightType.Directional;
            light.intensity = 1;
            light.transform.rotation = Quaternion.Euler(50, -30, 0);
            var camera = new GameObject("PreviewCamera").AddComponent<Camera>();
            camera.transform.position = new Vector3(0, 1.6f, -7);
            camera.farClipPlane = 80;
            camera.backgroundColor = new Color(.1f, .14f, .2f);
            camera.clearFlags = CameraClearFlags.SolidColor;
            CreatePortal(scene, ControlName, test.world_id, new Vector3(-3, 0, 3));
            CreatePortal(scene, FixedName, test.expected_location, new Vector3(3, 0, 3));
            string shortId = id.Substring(0, 8);
            AddSign("A_Label", "A：対照\nワールドIDのみ\n試験 " + shortId, new Vector3(-3, 2.65f, 3), new Color(.45f, .8f, 1));
            AddSign("B_Label", "B：実験\n完全なlocation\n試験 " + shortId, new Vector3(3, 2.65f, 3), new Color(1, .8f, .35f));
            AddSign("Instructions", "ポータル直接配置テスト\n先に右のB → 到着先と同室を記録\n入口へ戻り、左のAも確認\n実行時の複製・書換え・Refreshなし", new Vector3(0, 2.8f, 5.5f), Color.white);
            File.WriteAllText(folder + "/case.json", JsonUtility.ToJson(test, true), new System.Text.UTF8Encoding(false));
            File.WriteAllText(folder + "/result-template.md", ResultTemplate(test), new System.Text.UTF8Encoding(false));
            AssetDatabase.Refresh();
            if (!EditorSceneManager.SaveScene(scene, test.scene_path))
                throw new InvalidOperationException("検証シーンを保存できませんでした。新規検証フォルダーを確認してください。");
            AssetDatabase.SaveAssets();
            Audit(scene, test);
            Selection.activeGameObject = scene.GetRootGameObjects().First(go => go.name == FixedName);
            return test;
        }

        private static void CreatePortal(Scene scene, string name, string location, Vector3 position)
        {
            const string prefabPath = "Packages/com.vrchat.worlds/Samples/UdonExampleScene/Prefabs/VRCPortalMarker.prefab";
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath);
            if (prefab == null) throw new InvalidOperationException("SDK標準VRCPortalMarkerプレハブがありません。");
            var portal = (GameObject)PrefabUtility.InstantiatePrefab(prefab, scene);
            // 完全に展開し、初期値をシーンへ直接保存します。実行時コードは追加しません。
            PrefabUtility.UnpackPrefabInstance(portal, PrefabUnpackMode.Completely, InteractionMode.AutomatedAction);
            portal.name = name;
            portal.transform.SetParent(null);
            portal.transform.SetPositionAndRotation(position, Quaternion.identity);
            portal.transform.localScale = Vector3.one;
            portal.SetActive(true);
            var marker = portal.GetComponent<VRCPortalMarker>();
            var serialized = new SerializedObject(marker);
            serialized.FindProperty("world").intValue = 0;
            serialized.ApplyModifiedPropertiesWithoutUndo();
            marker.roomId = location;
            marker.customPortalName = "";
            marker.enabled = true;
            EditorUtility.SetDirty(marker);
        }

        private static void AddSign(string name, string words, Vector3 position, Color color)
        {
            var root = new GameObject(name, typeof(RectTransform), typeof(Canvas));
            root.GetComponent<Canvas>().renderMode = RenderMode.WorldSpace;
            var rect = root.GetComponent<RectTransform>();
            rect.sizeDelta = new Vector2(2600, 750);
            rect.position = position;
            rect.localScale = Vector3.one * .001f;
            var textObject = new GameObject("Text", typeof(RectTransform), typeof(Text));
            textObject.transform.SetParent(root.transform, false);
            var textRect = textObject.GetComponent<RectTransform>();
            textRect.anchorMin = Vector2.zero; textRect.anchorMax = Vector2.one;
            textRect.offsetMin = Vector2.zero; textRect.offsetMax = Vector2.zero;
            var text = textObject.GetComponent<Text>();
            text.font = AssetDatabase.LoadAssetAtPath<Font>(SGEditorFactory.RootFolder + "/Fonts/NotoSansJP-Regular.ttf") ?? Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            text.text = words;
            text.fontSize = 64;
            text.alignment = TextAnchor.MiddleCenter;
            text.color = color;
            text.raycastTarget = false;
        }

        internal static SGBakedPortalTestCase Load(Scene scene)
        {
            if (!scene.IsValid() || string.IsNullOrEmpty(scene.path) || !scene.path.StartsWith(OutputRoot + "/Case_", StringComparison.Ordinal))
                throw new InvalidOperationException("このツールで新規作成した検証シーンを開いてください。");
            string path = Path.GetDirectoryName(scene.path) + "/case.json";
            if (!File.Exists(path) || new FileInfo(path).Length > 16384)
                throw new InvalidOperationException("検証シーンのcase.jsonを確認してください。");
            var test = JsonUtility.FromJson<SGBakedPortalTestCase>(File.ReadAllText(path));
            if (test == null || test.schema_version != 1 || test.method != "scene_baked_active_portals" || test.scene_path != scene.path ||
                !SGFixedInstancePortalFactory.TryResolve(test.expected_location, out var room, out _) || room != test.expected_location ||
                test.world_id != room.Substring(0, room.IndexOf(':')) || !Guid.TryParseExact(test.case_id, "N", out _))
                throw new InvalidOperationException("試験データがシーンと一致しません。");
            return test;
        }

        internal static List<string> Audit(Scene scene, SGBakedPortalTestCase test)
        {
            if (!scene.IsValid() || !scene.isLoaded || scene.path != test.scene_path)
                throw new InvalidOperationException("検証シーンと試験データが一致しません。");
            var roots = scene.GetRootGameObjects();
            if (roots.SelectMany(root => root.GetComponentsInChildren<UdonBehaviour>(true)).Any())
                throw new InvalidOperationException("検証シーン内にUdonBehaviourがあります。旧生成方式を含まない新規シーンで試してください。");
            var markers = roots.SelectMany(root => root.GetComponentsInChildren<VRCPortalMarker>(true)).ToArray();
            if (markers.Length != 2) throw new InvalidOperationException("SDKポータルはA・Bの2基だけにしてください。");
            foreach (var marker in markers)
            {
                string expected = marker.name == ControlName ? test.world_id : marker.name == FixedName ? test.expected_location : null;
                if (expected == null || marker.roomId != expected || marker.transform.parent != null ||
                    !marker.enabled || !marker.gameObject.activeInHierarchy ||
                    new SerializedObject(marker).FindProperty("world").intValue != 0 || PrefabUtility.IsPartOfPrefabInstance(marker))
                    throw new InvalidOperationException("ポータルの初期値・ルート配置・有効状態・World=Noneを確認してください。");
            }
            if (markers.Count(marker => marker.name == ControlName) != 1 || markers.Count(marker => marker.name == FixedName) != 1)
                throw new InvalidOperationException("A・Bがそれぞれ1基必要です。");
            var descriptors = roots.SelectMany(root => root.GetComponentsInChildren<VRCSceneDescriptor>(true)).ToArray();
            var pipelines = roots.SelectMany(root => root.GetComponentsInChildren<VRC.Core.PipelineManager>(true)).ToArray();
            if (descriptors.Length != 1 || pipelines.Length != 1 || descriptors[0].spawns == null || descriptors[0].spawns.Length != 1)
                throw new InvalidOperationException("VRCWorld・PipelineManager・スポーンを確認してください。");
            if (markers.Any(marker => Vector3.Distance(marker.transform.position, descriptors[0].spawns[0].position) < 4))
                throw new InvalidOperationException("ポータルをスポーンから4m以上離してください。");
            return new List<string>
            {
                "A・Bともルート配置／有効／World=None／シーンへ初期値を直接保存",
                "UdonBehaviourなし。実行時の複製・書換え・RefreshPortalなし",
                "スポーンから4m以上。AとBの行き先はcase.jsonと一致",
                string.IsNullOrEmpty(pipelines[0].blueprintId) ? "Blueprint IDは空欄。新規テストワールドとして公開先を確認してください" : "Blueprint IDが設定済み。本番ではなく、この試験用のIDであることを確認してください"
            };
        }

        internal static string Compare(string expected, string observed)
        {
            if (!SGFixedInstancePortalFactory.TryResolve(expected, out var a, out var error)) throw new InvalidOperationException(error);
            if (!SGFixedInstancePortalFactory.TryResolve(observed, out var b, out error)) throw new InvalidOperationException(error);
            if (a == b) return "完全一致。オーナーとの同室確認も一致すれば成功候補です。";
            string[] left = a.Split('~'), right = b.Split('~');
            if (left[0] == right[0] && left.Skip(1).OrderBy(s => s, StringComparer.Ordinal).SequenceEqual(right.Skip(1).OrderBy(s => s, StringComparer.Ordinal)))
                return "タグ順序のみ相違。内容は同等です。オーナーとの同室も確認してください。";
            return "locationの内容が相違。同じ試験時刻の実際の着地先か確認してください。";
        }

        private static void EnsureFolder(string path)
        {
            if (AssetDatabase.IsValidFolder(path)) return;
            string parent = Path.GetDirectoryName(path).Replace('\\', '/');
            EnsureFolder(parent);
            AssetDatabase.CreateFolder(parent, Path.GetFileName(path));
        }

        private static string ResultTemplate(SGBakedPortalTestCase test)
        {
            return "# 直接配置ポータル 実機記録\n\n試験ID: " + test.case_id + "\nUnity: " + test.unity_version + "\nSDK: " + test.sdk_version +
                "\nVRChatクライアント版／通常・Beta:\n試験日時:\n入口のテスト用ワールドID:\n行き先オーナー滞在: はい／いいえ\n通常招待での同室確認: 成功／失敗\n\n" +
                "指定locationは隣のcase.jsonに保存。nonceを含むため、共有時は使い捨てテスト先であることを確認。\n\n" +
                "## B：完全location（先に試す）\n\n入る直前のポータル表示:\n操作時刻:\n着地先location（ログ候補）:\nオーナーと同室: はい／いいえ／不明\n\n" +
                "## A：ワールドIDのみ（入口に戻って試す）\n\n操作時刻:\n着地先location（ログ候補）:\n移動できたか:\n\n" +
                "## 判定\n\n成功／今回条件では失敗／未判定:\n表記差だけでは失敗にしない。参加試行のログだけで着地成功にしない。\nアップロード時のエラー:\n";
        }
    }
}
