using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UdonSharp;
using UdonSharpEditor;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using VRC.SDKBase;
using VRC.Udon;

namespace SGimmicks.Editor
{
    public class SGReceptionWindow : EditorWindow
    {
        private const string DefaultApi = "";
        [SerializeField] private GameObject systemObject;
        [SerializeField] private UdonBehaviour systemBacking;
        [SerializeField] private string operatorName = "";
        [SerializeField] private string apiUrl = DefaultApi;
        [SerializeField] private List<Transform> tabletRoots = new List<Transform>();
        private Vector2 _scroll;
        private string _message;

        [MenuItem("SGimmicks/カード受付・来店管理")]
        public static void Open() { GetWindow<SGReceptionWindow>("カード受付・来店管理"); }

        private SGReceptionController Controller()
        {
            if (systemBacking != null)
            {
                var proxy = UdonSharpEditorUtility.GetProxyBehaviour(systemBacking) as SGReceptionController;
                if (proxy != null) { systemObject = proxy.gameObject; return proxy; }
            }
            if (systemObject == null) return null;
            var controller = FindProxy<SGReceptionController>(systemObject);
            if (controller != null) systemBacking = UdonSharpEditorUtility.GetBackingUdonBehaviour(controller);
            return controller;
        }

        private static T FindProxy<T>(GameObject root) where T : UdonSharpBehaviour
        {
            foreach (var backing in root.GetComponentsInChildren<UdonBehaviour>(true))
            {
                var proxy = UdonSharpEditorUtility.GetProxyBehaviour(backing) as T;
                if (proxy != null) return proxy;
            }
            return null;
        }

        private void OnGUI()
        {
            _scroll = EditorGUILayout.BeginScrollView(_scroll);
            EditorGUILayout.LabelField("カード受付・来店管理", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("持ったカードを読取範囲へ入れると本人を受付し、横の固定画面へ本人だけ30秒表示します。台帳はGoogleスプレッドシートに保存します。", MessageType.Info);
            var selected = (GameObject)EditorGUILayout.ObjectField("既存の受付システム", systemObject, typeof(GameObject), true);
            if (selected != systemObject)
            {
                systemObject = selected; systemBacking = null;
                var loaded = Controller(); if (loaded != null) operatorName = loaded.bridgeDisplayName;
            }
            if (GUILayout.Button("選択中のシステムを読み込む"))
            {
                systemObject = Selection.activeGameObject; systemBacking = null;
                var loaded = Controller();
                if (loaded == null) _message = "受付システムのルートをHierarchyで選択してください。";
                else { operatorName = loaded.bridgeDisplayName; _message = "設定を読み込みました。"; }
            }
            var controller = Controller();
            EditorGUILayout.Space();
            operatorName = EditorGUILayout.TextField(new GUIContent("連携担当者の表示名", "補助ツールを起動するVRChatプレイヤーの表示名。大文字小文字を含め完全一致。"), operatorName);
            EditorGUILayout.HelpBox("担当者一人が同じインスタンスに参加し、Windows補助ツールを起動します。連携キーは補助ツールだけに入力してください。", MessageType.None);
            using (new EditorGUI.DisabledScope(EditorApplication.isPlayingOrWillChangePlaymode))
            {
                if (GUILayout.Button(controller == null ? "カード・読取機・本人用画面を自動作成" : "受付システムを更新（手動配置を維持）", GUILayout.Height(36)))
                {
                    try
                    {
                        if (systemObject != null && controller == null) throw new InvalidOperationException("指定したオブジェクトには受付システムがありません。新規作成は欄を空にしてください。");
                        controller = SGReceptionFactory.Configure(controller, operatorName);
                        systemObject = controller.gameObject; systemBacking = UdonSharpEditorUtility.GetBackingUdonBehaviour(controller);
                        _message = "作成・更新しました。CardReaderの範囲とGuestDisplayをHierarchyで配置してください。";
                    }
                    catch (Exception exception) { _message = exception.Message; }
                }
            }
            if (controller != null) DrawSystem(controller);
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("スタッフ用RTab", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("RTab配下のAppsを登録します。複数台可。スタッフ権限はスプシの「スタッフ」で指定します。", MessageType.None);
            for (int i = 0; i < tabletRoots.Count; i++)
            {
                EditorGUILayout.BeginHorizontal();
                tabletRoots[i] = (Transform)EditorGUILayout.ObjectField("Apps " + (i + 1), tabletRoots[i], typeof(Transform), true);
                if (GUILayout.Button("削除", GUILayout.Width(48))) { tabletRoots.RemoveAt(i); EditorGUILayout.EndHorizontal(); break; }
                EditorGUILayout.EndHorizontal();
            }
            if (GUILayout.Button("＋ RTabを追加")) tabletRoots.Add(null);
            if (GUILayout.Button("登録したRTabへ受付アプリを追加・更新"))
            {
                try
                {
                    if (controller == null) throw new InvalidOperationException("先に受付システムを作成してください。");
                    if (tabletRoots.Count == 0 || tabletRoots.Count > 32 || tabletRoots.Any(t => t == null) || tabletRoots.Distinct().Count() != tabletRoots.Count)
                        throw new InvalidOperationException("RTabのAppsを1～32台、空欄・重複なしで登録してください。");
                    if (!SGEditorFactory.IsRTabInstalled()) throw new InvalidOperationException("RTab本体を先にインポートしてください。");
                    foreach (var root in tabletRoots)
                        if (root.name != "Apps" || root.GetComponent<RectTransform>() == null || root.gameObject.scene != controller.gameObject.scene)
                            throw new InvalidOperationException("同じシーンのRTab配下のAppsを指定してください。");
                    foreach (var root in tabletRoots) SGReceptionStaffFactory.Configure(controller, root);
                    _message = "受付アプリを追加・更新しました。共有メモの編集画面も自動生成済みです。";
                }
                catch (Exception exception) { _message = exception.Message; }
            }
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("補助ツールへの設定書き出し", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("別のシーンへ切り替えた場合は、そのシーンの受付システムを読み込み、profile.jsonを書き出し直してください。補助ツールを停止し、新しいファイルを選択して連携を再開します。", MessageType.Info);
            apiUrl = EditorGUILayout.TextField("Apps Script公開URL", apiUrl);
            if (GUILayout.Button("補助ツール用のprofile.jsonを書き出す"))
            {
                try
                {
                    if (controller == null) throw new InvalidOperationException("先に受付システムを作成してください。");
                    var profile = CreateProfile(controller, apiUrl);
                    string path = EditorUtility.SaveFilePanel("補助ツール用プロファイル", "", "profile.json", "json");
                    if (path != "") { File.WriteAllText(path, JsonUtility.ToJson(profile, true), new System.Text.UTF8Encoding(false)); _message = "profile.jsonを書き出しました。補助ツールでこのファイルを選択してください。"; }
                }
                catch (Exception exception) { _message = exception.Message; }
            }
            if (!string.IsNullOrEmpty(_message)) EditorGUILayout.HelpBox(_message, MessageType.Info);
            EditorGUILayout.EndScrollView();
        }

        private void DrawSystem(SGReceptionController controller)
        {
            EditorGUILayout.LabelField("システムID", controller.worldId);
            var reader = FindProxy<SGReceptionReader>(controller.gameObject);
            if (reader == null) return;
            EditorGUI.BeginChangeCheck();
            var area = (BoxCollider)EditorGUILayout.ObjectField("カード読取範囲", reader.readArea, typeof(BoxCollider), true);
            int count = Mathf.Clamp(EditorGUILayout.IntField("登録カード数", reader.cards == null ? 0 : reader.cards.Length), 1, 32);
            var cards = new VRC_Pickup[count];
            for (int i = 0; i < count; i++)
            {
                var old = reader.cards != null && i < reader.cards.Length ? reader.cards[i] : null;
                cards[i] = (VRC_Pickup)EditorGUILayout.ObjectField("カード " + (i + 1), old, typeof(VRC_Pickup), true);
            }
            if (EditorGUI.EndChangeCheck())
            {
                if (area != null && !EditorUtility.IsPersistent(area) && area.gameObject.scene == controller.gameObject.scene && cards.All(c => c == null || !EditorUtility.IsPersistent(c) && c.gameObject.scene == controller.gameObject.scene))
                {
                    Undo.RecordObject(reader, "Configure reception cards"); reader.readArea = area; reader.cards = cards;
                    SGReceptionFactory.Save(reader); EditorSceneManager.MarkSceneDirty(controller.gameObject.scene);
                }
                else _message = "読取範囲とカードは同じシーンのHierarchyから指定してください。";
            }
            EditorGUILayout.HelpBox("読取判定はカードの中心がBoxCollider内へ入った時です。BoxColliderの中心・大きさ・回転・拡大縮小に追従します。追加カードにはPickup・Rigidbody・ObjectSyncを設定してください。", MessageType.None);
        }

        [Serializable]
        internal class PublicProfile
        {
            public int schema_version = 1;
            public string name = "SGimmicks カード受付";
            public string world_id;
            public string backend_url;
            public string bridge_display_name;
        }
        internal static PublicProfile CreateProfile(SGReceptionController controller, string url)
        {
            Uri uri;
            if (!Uri.TryCreate(url, UriKind.Absolute, out uri) || uri.Scheme != "https" || uri.Host != "script.google.com" ||
                !uri.AbsolutePath.StartsWith("/macros/s/") || !uri.AbsolutePath.EndsWith("/exec") || uri.Query != "" || uri.Fragment != "" || !uri.IsDefaultPort || uri.UserInfo != "")
                throw new InvalidOperationException("Apps Scriptのhttps://script.google.com/macros/s/…/execのURLを指定してください。");
            return new PublicProfile { world_id = controller.worldId, backend_url = url, bridge_display_name = controller.bridgeDisplayName };
        }
    }
}
