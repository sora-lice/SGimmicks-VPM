using System;
using System.Linq;
using UdonSharp;
using UdonSharpEditor;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;
using VRC.SDK3.Components;

namespace SGimmicks.Editor
{
    internal static class SGReceptionStaffFactory
    {
        internal static SGReceptionStaffApp Configure(SGReceptionController controller, Transform appsRoot)
        {
            if (controller == null || appsRoot == null || appsRoot.name != "Apps" || appsRoot.GetComponent<RectTransform>() == null)
                throw new InvalidOperationException("受付システムとRTab配下のAppsをHierarchyから指定してください。");
            if (EditorApplication.isPlayingOrWillChangePlaymode || EditorUtility.IsPersistent(appsRoot) || controller.gameObject.scene != appsRoot.gameObject.scene)
                throw new InvalidOperationException("再生を停止し、同じシーン上のAppsを指定してください。");
            Type adapterType = SGEditorFactory.FindType("Rasta.Tablet.TabletAppBehaviour", "TabletAppBehaviour");
            if (adapterType == null) throw new InvalidOperationException("RTab本体を先にインポートしてください。");
            var app = appsRoot.GetComponentsInChildren<SGReceptionStaffApp>(true).FirstOrDefault(a => a.transform.parent == appsRoot);
            if (app != null && app.controller != controller) throw new InvalidOperationException("別の受付システムのアプリがあります。");
            if (app == null)
            {
                var go = new GameObject("SGReceptionStaffApp", typeof(RectTransform), typeof(Image), typeof(CanvasGroup));
                Undo.RegisterCreatedObjectUndo(go, "Create reception RTab app"); go.transform.SetParent(appsRoot, false);
                app = SGEditorFactory.AddBundledComponent<SGReceptionStaffApp>(go);
            }
            SGEditorFactory.ConfigureRTabAppRoot(app.gameObject);
            var adapter = app.GetComponent(adapterType);
            if (adapter == null) adapter = typeof(UdonSharpBehaviour).IsAssignableFrom(adapterType)
                ? UdonSharpUndo.AddComponent(app.gameObject, adapterType) : Undo.AddComponent(app.gameObject, adapterType);
            SGEditorFactory.SetRTabAppSettings(adapter, Icon(), "受付・来店管理", "SGimmicks");
            if (adapter is UdonSharpBehaviour udon) SGReceptionFactory.Save(udon);
            app.controller = controller; app.callbackReceiver = UdonSharpEditorUtility.GetBackingUdonBehaviour(app);
            BuildUI(app);
            SGReceptionFactory.Save(app);
            EditorSceneManager.MarkSceneDirty(controller.gameObject.scene);
            return app;
        }

        internal static void BuildUI(SGReceptionStaffApp app)
        {
            if (app.transform.Find("ReceptionUI") == null)
            {
                var ui = Rect(app.transform, "ReceptionUI", Vector2.zero, Vector2.one);
                SGReceptionFactory.Text(ui, "Title", "受付・来店管理", .89f, .99f, 42);
                app.pageText = Label(ui, "Page", "", .03f, .81f, .33f, .89f, 28);
                app.rowLabels = new Text[6]; app.rowButtons = new Button[6];
                for (int i = 0; i < 6; i++)
                {
                    float top = .80f - i * .09f;
                    var button = Button(ui, "Customer" + i, "", .03f, top - .08f, .33f, top, app, "_Select" + i);
                    app.rowButtons[i] = button; app.rowLabels[i] = button.GetComponentInChildren<Text>();
                }
                Button(ui, "Previous", "前へ", .03f, .18f, .17f, .26f, app, "_PreviousPage");
                Button(ui, "Next", "次へ", .18f, .18f, .33f, .26f, app, "_NextPage");
                Button(ui, "Refresh", "一覧更新", .03f, .08f, .33f, .17f, app, "_Refresh");
                var viewport = Rect(ui, "DetailsViewport", new Vector2(.36f, .25f), new Vector2(.97f, .87f));
                viewport.gameObject.AddComponent<Image>().color = new Color(.04f, .07f, .10f);
                viewport.gameObject.AddComponent<RectMask2D>();
                var content = Rect(viewport, "Detail", new Vector2(0, 1), Vector2.one);
                content.pivot = new Vector2(.5f, 1f); content.sizeDelta = new Vector2(0, 1500f);
                var text = content.gameObject.AddComponent<Text>();
                text.font = AssetDatabase.LoadAssetAtPath<Font>(SGEditorFactory.RootFolder + "/Fonts/NotoSansJP-Regular.ttf");
                text.fontSize = 28; text.color = Color.white; text.supportRichText = false; text.raycastTarget = false;
                text.alignment = TextAnchor.UpperLeft; text.verticalOverflow = VerticalWrapMode.Overflow;
                app.detailText = text;
                var scroll = viewport.gameObject.AddComponent<ScrollRect>(); scroll.viewport = viewport; scroll.content = content;
                scroll.horizontal = false; scroll.vertical = true; scroll.movementType = ScrollRect.MovementType.Clamped;
                Button(ui, "EditMemo", "共有メモを編集", .36f, .12f, .97f, .23f, app, "_EditMemo");
                app.statusText = Label(ui, "Status", "台帳を取得してください。", .04f, .01f, .96f, .08f, 24);
            }
            if (app.memoPanel == null) CreateMemoPanel(app);
        }

        private static void CreateMemoPanel(SGReceptionStaffApp app)
        {
            var go = new GameObject("ReceptionMemoEditor", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster), typeof(VRCUiShape), typeof(Image));
            Undo.RegisterCreatedObjectUndo(go, "Create local memo editor"); go.transform.SetParent(app.controller.transform, false);
            var rect = go.GetComponent<RectTransform>(); rect.sizeDelta = new Vector2(1000, 700); rect.localScale = Vector3.one * .001f;
            go.GetComponent<Canvas>().renderMode = RenderMode.WorldSpace; go.GetComponent<Image>().color = new Color(.025f, .045f, .075f, 1f);
            SGReceptionFactory.Text(rect, "Title", "共有メモの編集（1000文字まで）", .89f, .99f, 36);
            var fieldRect = Rect(rect, "MemoInput", new Vector2(.04f, .24f), new Vector2(.96f, .87f));
            fieldRect.gameObject.AddComponent<Image>().color = new Color(.10f, .14f, .20f);
            var field = fieldRect.gameObject.AddComponent<InputField>();
            var text = Label(fieldRect, "Text", "", .02f, .02f, .98f, .98f, 30);
            text.resizeTextForBestFit = false; text.fontStyle = FontStyle.Normal; text.alignment = TextAnchor.UpperLeft;
            field.textComponent = text; field.characterLimit = 1000; field.lineType = InputField.LineType.MultiLineNewline;
            field.targetGraphic = fieldRect.GetComponent<Image>();
            app.memoInput = field; app.memoPanel = go;
            app.memoStatus = Label(rect, "Status", "", .04f, .13f, .96f, .23f, 26);
            Button(rect, "Cancel", "編集を取消", .04f, .02f, .32f, .12f, app, "_CancelMemo");
            Button(rect, "LoadLatest", "最新を読込", .36f, .02f, .64f, .12f, app, "_LoadLatest");
            Button(rect, "Save", "保存", .68f, .02f, .96f, .12f, app, "_SaveMemo");
            go.SetActive(false);
        }

        private static RectTransform Rect(Transform parent, string name, Vector2 min, Vector2 max)
        {
            var go = new GameObject(name, typeof(RectTransform)); Undo.RegisterCreatedObjectUndo(go, "Create reception UI");
            go.transform.SetParent(parent, false); var rect = go.GetComponent<RectTransform>();
            rect.anchorMin = min; rect.anchorMax = max; rect.offsetMin = rect.offsetMax = Vector2.zero; return rect;
        }
        private static Text Label(RectTransform parent, string name, string value, float left, float bottom, float right, float top, int size)
        {
            var label = SGEditorFactory.CreateTabletText(parent, name, value, new Vector2(left, bottom), new Vector2(right, top), size, Color.white);
            label.supportRichText = false; return label;
        }
        private static Button Button(RectTransform parent, string name, string label, float left, float bottom, float right, float top, SGReceptionStaffApp app, string eventName)
        { return SGEditorFactory.CreateTabletButton(parent, name, label, new Vector2(left, bottom), new Vector2(right, top), app, eventName, new Color(.08f, .26f, .32f), 28); }
        private static Texture2D Icon()
        {
            SGEditorFactory.EnsureAssetFolders(); string path = SGEditorFactory.GeneratedFolder + "/SGReceptionIcon.asset";
            var icon = AssetDatabase.LoadAssetAtPath<Texture2D>(path); if (icon != null) return icon;
            icon = new Texture2D(64, 64, TextureFormat.RGBA32, false) { name = "SGReceptionIcon" };
            var pixels = new Color[4096];
            for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++)
            {
                bool card = x > 9 && x < 54 && y > 16 && y < 48;
                bool line = card && x > 17 && x < 46 && (y == 25 || y == 26 || y == 34 || y == 35);
                pixels[y * 64 + x] = line ? new Color(.1f, .6f, .6f) : card ? Color.white : new Color(.025f, .08f, .12f);
            }
            icon.SetPixels(pixels); icon.Apply(); AssetDatabase.CreateAsset(icon, path); return icon;
        }
    }
}
