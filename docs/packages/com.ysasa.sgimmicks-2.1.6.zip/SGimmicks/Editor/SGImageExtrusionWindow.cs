using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;

namespace SGimmicks.Editor
{
    public sealed class SGImageExtrusionWindow : EditorWindow
    {
        private const string OutputRoot = "Assets/SGimmicksGenerated/ImageExtrusions";
        private const int MaximumQuads = 50000;

        [SerializeField] private Texture2D _image;
        [SerializeField] private string _objectName = "画像オブジェクト";
        [SerializeField] private float _widthMeters = 1.5f;
        [SerializeField] private float _thicknessMeters = 0.08f;
        [SerializeField] private float _alphaThreshold = 0.5f;
        [SerializeField] private int _maxResolution = 256;
        [SerializeField] private Color _sideColor = new Color(0.16f, 0.16f, 0.18f, 1f);
        [SerializeField] private bool _unlitFront = true;
        [SerializeField] private bool _collider;

        [MenuItem("SGimmicks/透過画像を3Dオブジェクト化", priority = 12)]
        public static void Open()
        {
            SGImageExtrusionWindow window = GetWindow<SGImageExtrusionWindow>();
            window.titleContent = new GUIContent("透過画像の立体化");
            window.minSize = new Vector2(460f, 410f);
            window.Show();
        }

        private void OnGUI()
        {
            EditorGUILayout.LabelField("透過PNGから厚みのある切り抜きを作成", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "キャラクター展示パネルやロゴ向けです。PNGの透明部分は除き、画像を前面・背面へ貼り、輪郭に側面を付けます。生成したPrefabはワールドへ配置できます。",
                MessageType.Info);

            _image = (Texture2D)EditorGUILayout.ObjectField("透過PNG", _image, typeof(Texture2D), false);
            _objectName = EditorGUILayout.TextField("オブジェクト名", _objectName);
            _widthMeters = EditorGUILayout.Slider("切り抜きの横幅（m）", _widthMeters, 0.05f, 10f);
            _thicknessMeters = EditorGUILayout.Slider("厚み（m）", _thicknessMeters, 0.005f, 1f);
            _alphaThreshold = EditorGUILayout.Slider(
                new GUIContent("輪郭の透明度しきい値", "高いほど半透明の縁を除外します。"),
                _alphaThreshold, 0.05f, 0.95f);
            _maxResolution = EditorGUILayout.IntSlider(
                new GUIContent("輪郭の細かさ", "大きいほど輪郭が滑らかになりますが、ポリゴン数が増えます。"),
                _maxResolution, 64, 512);
            _sideColor = EditorGUILayout.ColorField("側面の色", _sideColor);
            _unlitFront = EditorGUILayout.Toggle("画像の明るさを固定", _unlitFront);
            _collider = EditorGUILayout.Toggle("Mesh Colliderを追加", _collider);

            EditorGUILayout.Space(10f);
            EditorGUI.BeginDisabledGroup(_image == null);
            if (GUILayout.Button("メッシュ・Prefabを生成してシーンに配置", GUILayout.Height(42f)))
            {
                try
                {
                    GameObject created = Create(_image, _objectName, _widthMeters,
                        _thicknessMeters, _alphaThreshold, _maxResolution,
                        _sideColor, _unlitFront, _collider);
                    Selection.activeGameObject = created;
                    EditorGUIUtility.PingObject(created);
                    ShowNotification(new GUIContent("立体オブジェクトを生成しました"));
                }
                catch (Exception exception)
                {
                    Debug.LogException(exception);
                    EditorUtility.DisplayDialog("SGimmicks", exception.Message, "OK");
                }
            }
            EditorGUI.EndDisabledGroup();
            EditorGUILayout.HelpBox(
                "出力先: Assets/SGimmicksGenerated/ImageExtrusions。裏側から見る画像は鏡像になります。細い線が欠ける場合は輪郭の細かさを上げるか、しきい値を下げてください。",
                MessageType.None);
        }

        internal static GameObject Create(Texture2D source, string requestedName,
            float widthMeters, float thicknessMeters, float alphaThreshold,
            int maxResolution, Color sideColor, bool unlitFront, bool addCollider)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            string path = AssetDatabase.GetAssetPath(source);
            string projectRoot = Directory.GetParent(Application.dataPath)?.FullName;
            string absolutePath = string.IsNullOrEmpty(projectRoot) || string.IsNullOrEmpty(path)
                ? null : Path.Combine(projectRoot, path);
            if (string.IsNullOrEmpty(path) || !path.StartsWith("Assets/", StringComparison.Ordinal) ||
                !path.EndsWith(".png", StringComparison.OrdinalIgnoreCase) ||
                string.IsNullOrEmpty(absolutePath) || !File.Exists(absolutePath))
                throw new InvalidOperationException("Assets内の透過PNGを指定してください。");

            widthMeters = Mathf.Clamp(widthMeters, 0.05f, 10f);
            thicknessMeters = Mathf.Clamp(thicknessMeters, 0.005f, 1f);
            alphaThreshold = Mathf.Clamp(alphaThreshold, 0.05f, 0.95f);
            maxResolution = Mathf.Clamp(maxResolution, 64, 512);

            Texture2D decoded = new Texture2D(2, 2, TextureFormat.RGBA32, false);
            Mesh mesh;
            try
            {
                if (!ImageConversion.LoadImage(decoded, File.ReadAllBytes(absolutePath), false))
                    throw new InvalidOperationException("PNGを読み込めませんでした。");
                mesh = BuildMesh(decoded.GetPixels32(), decoded.width, decoded.height,
                    widthMeters, thicknessMeters, alphaThreshold, maxResolution);
            }
            finally
            {
                DestroyImmediate(decoded);
            }

            Shader frontShader = Shader.Find(unlitFront ? "Unlit/Transparent Cutout" : "Standard");
            Shader sideShader = Shader.Find("Standard");
            if (frontShader == null || sideShader == null)
                throw new InvalidOperationException("必要なBuilt-inシェーダーが見つかりません。");

            string safeName = MakeSafeName(requestedName, source.name);
            EnsureFolder(OutputRoot);
            string uniqueFolder = AssetDatabase.GenerateUniqueAssetPath(OutputRoot + "/" + safeName);
            string folderName = Path.GetFileName(uniqueFolder);
            if (string.IsNullOrEmpty(AssetDatabase.CreateFolder(OutputRoot, folderName)))
                throw new InvalidOperationException("出力フォルダーを作成できませんでした。");

            string meshPath = uniqueFolder + "/" + safeName + ".asset";
            string frontPath = uniqueFolder + "/" + safeName + "_画像.mat";
            string sidePath = uniqueFolder + "/" + safeName + "_側面.mat";
            string prefabPath = uniqueFolder + "/" + safeName + ".prefab";
            mesh.name = safeName;
            AssetDatabase.CreateAsset(mesh, meshPath);

            Material front = new Material(frontShader) { name = safeName + "_画像", mainTexture = source };
            front.color = Color.white;
            if (front.HasProperty("_Cutoff")) front.SetFloat("_Cutoff", alphaThreshold);
            if (frontShader.name == "Standard") ConfigureStandardCutout(front);
            AssetDatabase.CreateAsset(front, frontPath);

            Material side = new Material(sideShader) { name = safeName + "_側面", color = sideColor };
            AssetDatabase.CreateAsset(side, sidePath);

            GameObject temporary = new GameObject(safeName);
            try
            {
                temporary.AddComponent<MeshFilter>().sharedMesh = mesh;
                temporary.AddComponent<MeshRenderer>().sharedMaterials = new[] { front, side };
                if (addCollider) temporary.AddComponent<MeshCollider>().sharedMesh = mesh;
                GameObject prefab = PrefabUtility.SaveAsPrefabAsset(temporary, prefabPath);
                if (prefab == null)
                    throw new InvalidOperationException("Prefabを保存できませんでした。");
            }
            finally
            {
                DestroyImmediate(temporary);
            }

            AssetDatabase.SaveAssets();
            GameObject prefabAsset = AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath);
            GameObject instance = PrefabUtility.InstantiatePrefab(prefabAsset) as GameObject;
            if (instance == null)
                throw new InvalidOperationException("Prefabをシーンへ配置できませんでした。");
            SceneView view = SceneView.lastActiveSceneView;
            if (view != null && view.camera != null)
            {
                Transform cameraTransform = view.camera.transform;
                instance.transform.position = cameraTransform.position + cameraTransform.forward * 3f;
                instance.transform.rotation = Quaternion.LookRotation(-cameraTransform.forward, Vector3.up);
            }
            Undo.RegisterCreatedObjectUndo(instance, "Create 3D Image Cutout");
            EditorSceneManager.MarkSceneDirty(instance.scene);
            return instance;
        }

        internal static Mesh BuildMesh(Color32[] pixels, int imageWidth, int imageHeight,
            float widthMeters, float thicknessMeters, float alphaThreshold, int maxResolution)
        {
            if (pixels == null || imageWidth < 1 || imageHeight < 1 ||
                pixels.Length != imageWidth * imageHeight)
                throw new ArgumentException("画像のピクセルデータが正しくありません。");

            float scale = Mathf.Min(1f, maxResolution / (float)Mathf.Max(imageWidth, imageHeight));
            int gridWidth = Mathf.Max(1, Mathf.RoundToInt(imageWidth * scale));
            int gridHeight = Mathf.Max(1, Mathf.RoundToInt(imageHeight * scale));
            bool[,] solid = new bool[gridWidth, gridHeight];
            int minX = gridWidth, minY = gridHeight, maxX = -1, maxY = -1;
            byte cutoff = (byte)Mathf.RoundToInt(alphaThreshold * 255f);
            for (int y = 0; y < gridHeight; y++)
            {
                int fromY = y * imageHeight / gridHeight;
                int toY = Mathf.CeilToInt((y + 1) * imageHeight / (float)gridHeight);
                for (int x = 0; x < gridWidth; x++)
                {
                    int fromX = x * imageWidth / gridWidth;
                    int toX = Mathf.CeilToInt((x + 1) * imageWidth / (float)gridWidth);
                    bool filled = false;
                    for (int sourceY = fromY; sourceY < toY && !filled; sourceY++)
                        for (int sourceX = fromX; sourceX < toX; sourceX++)
                            if (pixels[sourceY * imageWidth + sourceX].a >= cutoff)
                            {
                                filled = true;
                                break;
                            }
                    if (!filled) continue;
                    solid[x, y] = true;
                    minX = Mathf.Min(minX, x);
                    minY = Mathf.Min(minY, y);
                    maxX = Mathf.Max(maxX, x);
                    maxY = Mathf.Max(maxY, y);
                }
            }
            if (maxX < minX)
                throw new InvalidOperationException("指定したしきい値以上の不透明なピクセルがありません。");

            float cellSize = widthMeters / (maxX - minX + 1);
            float heightMeters = (maxY - minY + 1) * cellSize;
            float halfDepth = thicknessMeters * 0.5f;
            List<Vector3> vertices = new List<Vector3>();
            List<Vector2> uvs = new List<Vector2>();
            List<int> imageTriangles = new List<int>();
            List<int> sideTriangles = new List<int>();
            bool[,] consumed = new bool[gridWidth, gridHeight];

            for (int y = minY; y <= maxY; y++)
            {
                for (int x = minX; x <= maxX; x++)
                {
                    if (!solid[x, y] || consumed[x, y]) continue;
                    int endX = x + 1;
                    while (endX <= maxX && solid[endX, y] && !consumed[endX, y]) endX++;
                    int endY = y + 1;
                    bool canGrow = true;
                    while (endY <= maxY && canGrow)
                    {
                        for (int scanX = x; scanX < endX; scanX++)
                            if (!solid[scanX, endY] || consumed[scanX, endY])
                            {
                                canGrow = false;
                                break;
                            }
                        if (canGrow) endY++;
                    }
                    for (int fillY = y; fillY < endY; fillY++)
                        for (int fillX = x; fillX < endX; fillX++)
                            consumed[fillX, fillY] = true;

                    float left = (x - minX) * cellSize - widthMeters * 0.5f;
                    float right = (endX - minX) * cellSize - widthMeters * 0.5f;
                    float bottom = (y - minY) * cellSize - heightMeters * 0.5f;
                    float top = (endY - minY) * cellSize - heightMeters * 0.5f;
                    float u0 = x / (float)gridWidth, u1 = endX / (float)gridWidth;
                    float v0 = y / (float)gridHeight, v1 = endY / (float)gridHeight;
                    AddQuad(vertices, uvs, imageTriangles,
                        new Vector3(left, bottom, halfDepth), new Vector3(right, bottom, halfDepth),
                        new Vector3(right, top, halfDepth), new Vector3(left, top, halfDepth),
                        new Vector2(u0, v0), new Vector2(u1, v0),
                        new Vector2(u1, v1), new Vector2(u0, v1));
                    // Keep UVs aligned with the silhouette; viewed from behind, the art is mirrored.
                    AddQuad(vertices, uvs, imageTriangles,
                        new Vector3(right, bottom, -halfDepth), new Vector3(left, bottom, -halfDepth),
                        new Vector3(left, top, -halfDepth), new Vector3(right, top, -halfDepth),
                        new Vector2(u1, v0), new Vector2(u0, v0),
                        new Vector2(u0, v1), new Vector2(u1, v1));
                    CheckQuadLimit(vertices);
                }
            }

            Vector2 sideUv0 = Vector2.zero, sideUv1 = Vector2.right;
            Vector2 sideUv2 = Vector2.one, sideUv3 = Vector2.up;
            for (int y = minY; y <= maxY; y++)
            {
                for (int x = minX; x <= maxX; x++)
                {
                    if (!solid[x, y]) continue;
                    float left = (x - minX) * cellSize - widthMeters * 0.5f;
                    float right = left + cellSize;
                    float bottom = (y - minY) * cellSize - heightMeters * 0.5f;
                    float top = bottom + cellSize;
                    if (x == 0 || !solid[x - 1, y])
                        AddQuad(vertices, uvs, sideTriangles,
                            new Vector3(left, bottom, halfDepth), new Vector3(left, top, halfDepth),
                            new Vector3(left, top, -halfDepth), new Vector3(left, bottom, -halfDepth),
                            sideUv0, sideUv1, sideUv2, sideUv3);
                    if (x == gridWidth - 1 || !solid[x + 1, y])
                        AddQuad(vertices, uvs, sideTriangles,
                            new Vector3(right, bottom, halfDepth), new Vector3(right, bottom, -halfDepth),
                            new Vector3(right, top, -halfDepth), new Vector3(right, top, halfDepth),
                            sideUv0, sideUv1, sideUv2, sideUv3);
                    if (y == 0 || !solid[x, y - 1])
                        AddQuad(vertices, uvs, sideTriangles,
                            new Vector3(left, bottom, halfDepth), new Vector3(left, bottom, -halfDepth),
                            new Vector3(right, bottom, -halfDepth), new Vector3(right, bottom, halfDepth),
                            sideUv0, sideUv1, sideUv2, sideUv3);
                    if (y == gridHeight - 1 || !solid[x, y + 1])
                        AddQuad(vertices, uvs, sideTriangles,
                            new Vector3(left, top, halfDepth), new Vector3(right, top, halfDepth),
                            new Vector3(right, top, -halfDepth), new Vector3(left, top, -halfDepth),
                            sideUv0, sideUv1, sideUv2, sideUv3);
                    CheckQuadLimit(vertices);
                }
            }

            Mesh mesh = new Mesh { name = "SG Image Extrusion" };
            if (vertices.Count > 65535) mesh.indexFormat = IndexFormat.UInt32;
            mesh.SetVertices(vertices);
            mesh.SetUVs(0, uvs);
            mesh.subMeshCount = 2;
            mesh.SetTriangles(imageTriangles, 0, false);
            mesh.SetTriangles(sideTriangles, 1, false);
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();
            return mesh;
        }

        private static void AddQuad(List<Vector3> vertices, List<Vector2> uvs, List<int> triangles,
            Vector3 a, Vector3 b, Vector3 c, Vector3 d,
            Vector2 uvA, Vector2 uvB, Vector2 uvC, Vector2 uvD)
        {
            int first = vertices.Count;
            vertices.Add(a); vertices.Add(b); vertices.Add(c); vertices.Add(d);
            uvs.Add(uvA); uvs.Add(uvB); uvs.Add(uvC); uvs.Add(uvD);
            triangles.Add(first); triangles.Add(first + 1); triangles.Add(first + 2);
            triangles.Add(first); triangles.Add(first + 2); triangles.Add(first + 3);
        }

        private static void CheckQuadLimit(List<Vector3> vertices)
        {
            if (vertices.Count / 4 > MaximumQuads)
                throw new InvalidOperationException(
                    "輪郭が複雑すぎます。『輪郭の細かさ』を下げて再生成してください。");
        }

        private static void ConfigureStandardCutout(Material material)
        {
            material.SetFloat("_Mode", 1f);
            material.SetInt("_SrcBlend", (int)BlendMode.One);
            material.SetInt("_DstBlend", (int)BlendMode.Zero);
            material.SetInt("_ZWrite", 1);
            material.EnableKeyword("_ALPHATEST_ON");
            material.DisableKeyword("_ALPHABLEND_ON");
            material.DisableKeyword("_ALPHAPREMULTIPLY_ON");
            material.renderQueue = (int)RenderQueue.AlphaTest;
        }

        private static string MakeSafeName(string requested, string fallback)
        {
            string value = string.IsNullOrWhiteSpace(requested) ? fallback : requested.Trim();
            foreach (char invalid in Path.GetInvalidFileNameChars()) value = value.Replace(invalid, '_');
            return string.IsNullOrWhiteSpace(value) ? "画像オブジェクト" : value;
        }

        private static void EnsureFolder(string path)
        {
            if (AssetDatabase.IsValidFolder(path)) return;
            string parent = Path.GetDirectoryName(path)?.Replace('\\', '/');
            if (string.IsNullOrEmpty(parent)) throw new InvalidOperationException("出力先が無効です。");
            EnsureFolder(parent);
            AssetDatabase.CreateFolder(parent, Path.GetFileName(path));
        }
    }
}
