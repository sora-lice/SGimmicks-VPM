using UdonSharp;
using UnityEngine;
using VRC.SDKBase;

namespace SGimmicks
{
    [AddComponentMenu("SGimmicks/Whisper Seat")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.Manual)]
    public class SGWhisperSeat : UdonSharpBehaviour
    {
        public SGWhisperAudienceManager manager;
        public VRC.SDK3.Components.VRCStation station;
        public int seatIndex;

        [Header("囁き声判定")]
        [UdonSynced, Range(0.05f, 0.95f)] public float voiceThreshold = 0.65f;
        [Range(0.05f, 2f)] public float holdDuration = 0.08f;
        [Tooltip("Voice=1で左足が移動する想定距離です。自動生成Animatorの値と合わせます。")]
        public float footTravelMeters = 0.22f;

        [Header("固定座席")]
        [Range(0.2f, 5f)] public float fixedEyeHeightMeters = 1.45f;

        [Header("本人だけに表示")]
        public GameObject outDisplay;
        public float outDisplayDistance = 0.7f;

        [UdonSynced] public int occupantPlayerId = -1;
        [UdonSynced] public string occupantDisplayName = "";
        [UdonSynced] public bool isOut;

        private bool _localSeated;
        private bool _calibrated;
        private bool _previousManualScalingAllowed;
        private float _previousEyeHeight;
        private float _baselineFootLocalX;
        private float _overThresholdSince = -1f;

        private void Start()
        {
            if (outDisplay != null) outDisplay.SetActive(false);
        }

        public override void Interact()
        {
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(localPlayer)) return;
            if (manager != null && manager.IsCastDisplayName(localPlayer.displayName)) return;
            localPlayer.UseAttachedStation();
        }

        public override void OnStationEntered(VRCPlayerApi player)
        {
            if (!Utilities.IsValid(player) || !player.isLocal) return;
            if (manager != null && manager.IsCastDisplayName(player.displayName))
            {
                if (station != null) station.ExitStation(player);
                return;
            }

            _localSeated = true;
            _calibrated = false;
            _overThresholdSince = -1f;
            _previousManualScalingAllowed = player.GetManualAvatarScalingAllowed();
            _previousEyeHeight = player.GetAvatarEyeHeightAsMeters();
            player.SetManualAvatarScalingAllowed(false);
            player.SetAvatarEyeHeightByMeters(fixedEyeHeightMeters);

            Networking.SetOwner(player, gameObject);
            occupantPlayerId = player.playerId;
            occupantDisplayName = player.displayName;
            isOut = false;
            RequestSerialization();
            if (outDisplay != null) outDisplay.SetActive(false);
            SendCustomEventDelayedSeconds(nameof(CalibrateFoot), 0.75f);
            if (manager != null) manager.RefreshPanel();
        }

        public override void OnStationExited(VRCPlayerApi player)
        {
            if (!Utilities.IsValid(player) || !player.isLocal || !_localSeated) return;
            _localSeated = false;
            _calibrated = false;
            _overThresholdSince = -1f;
            if (outDisplay != null) outDisplay.SetActive(false);
            player.SetAvatarEyeHeightByMeters(_previousEyeHeight);
            player.SetManualAvatarScalingAllowed(_previousManualScalingAllowed);

            Networking.SetOwner(player, gameObject);
            occupantPlayerId = -1;
            occupantDisplayName = "";
            isOut = false;
            RequestSerialization();
            if (manager != null) manager.RefreshPanel();
        }

        public void CalibrateFoot()
        {
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!_localSeated || !Utilities.IsValid(localPlayer)) return;
            Vector3 footWorld = localPlayer.GetBonePosition(HumanBodyBones.LeftFoot);
            if (footWorld == Vector3.zero)
            {
                SendCustomEventDelayedSeconds(nameof(CalibrateFoot), 0.5f);
                return;
            }
            _baselineFootLocalX = transform.InverseTransformPoint(footWorld).x;
            _calibrated = true;
        }

        private void Update()
        {
            if (!_localSeated || !_calibrated || isOut) return;
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(localPlayer)) return;
            Vector3 footWorld = localPlayer.GetBonePosition(HumanBodyBones.LeftFoot);
            float displacement = Mathf.Abs(transform.InverseTransformPoint(footWorld).x - _baselineFootLocalX);
            float normalizedVoice = displacement / Mathf.Max(0.01f, footTravelMeters);

            if (normalizedVoice >= voiceThreshold)
            {
                if (_overThresholdSince < 0f) _overThresholdSince = Time.time;
                if (Time.time - _overThresholdSince >= holdDuration) TriggerOut();
            }
            else
            {
                _overThresholdSince = -1f;
            }
        }

        public override void PostLateUpdate()
        {
            if (!_localSeated || !isOut || outDisplay == null) return;
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(localPlayer)) return;
            VRCPlayerApi.TrackingData head =
                localPlayer.GetTrackingData(VRCPlayerApi.TrackingDataType.Head);
            outDisplay.transform.position = head.position + head.rotation *
                new Vector3(0f, 0.02f, outDisplayDistance);
            outDisplay.transform.rotation = head.rotation * Quaternion.Euler(0f, 180f, 0f);
        }

        public void SetThresholdFromStaff(float value)
        {
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(localPlayer)) return;
            Networking.SetOwner(localPlayer, gameObject);
            voiceThreshold = Mathf.Clamp(value, 0.05f, 0.95f);
            RequestSerialization();
            if (manager != null) manager.RefreshPanel();
        }

        public void SetOutFromStaff(bool value)
        {
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(localPlayer)) return;
            Networking.SetOwner(localPlayer, gameObject);
            isOut = value;
            RequestSerialization();
            ApplyLocalOutDisplay();
            if (manager != null) manager.RefreshPanel();
        }

        public override void OnDeserialization()
        {
            ApplyLocalOutDisplay();
            if (manager != null) manager.RefreshPanel();
        }

        private void TriggerOut()
        {
            if (isOut) return;
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(localPlayer)) return;
            Networking.SetOwner(localPlayer, gameObject);
            isOut = true;
            RequestSerialization();
            ApplyLocalOutDisplay();
            if (manager != null) manager.RefreshPanel();
        }

        private void ApplyLocalOutDisplay()
        {
            if (outDisplay == null) return;
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            bool belongsToLocalPlayer = _localSeated && Utilities.IsValid(localPlayer) &&
                                        occupantPlayerId == localPlayer.playerId;
            outDisplay.SetActive(belongsToLocalPlayer && isOut);
            if (!isOut) _overThresholdSince = -1f;
        }
    }
}
