using UdonSharp;
using UnityEngine;

namespace CastTimerGimmick
{
    [UdonBehaviourSyncMode(BehaviourSyncMode.NoVariableSync)]
    public class StaffControlButton : UdonSharpBehaviour
    {
        public const int AddTenMinutesAction = 0;
        public const int SubtractTenMinutesAction = 1;
        public const int AddOneMinuteAction = 2;
        public const int SubtractOneMinuteAction = 3;
        public const int AddTenSecondsAction = 4;
        public const int SubtractTenSecondsAction = 5;
        public const int StartAction = 6;
        public const int PauseAction = 7;
        public const int ResetAction = 8;
        public const int BellAction = 9;

        public CastTimerManager manager;
        public int action;

        public override void Interact()
        {
            Press();
        }

        public void Press()
        {
            if (manager == null)
            {
                return;
            }

            if (action == AddTenMinutesAction)
            {
                manager.AddTenMinutes();
            }
            else if (action == SubtractTenMinutesAction)
            {
                manager.SubtractTenMinutes();
            }
            else if (action == AddOneMinuteAction)
            {
                manager.AddOneMinute();
            }
            else if (action == SubtractOneMinuteAction)
            {
                manager.SubtractOneMinute();
            }
            else if (action == AddTenSecondsAction)
            {
                manager.AddTenSeconds();
            }
            else if (action == SubtractTenSecondsAction)
            {
                manager.SubtractTenSeconds();
            }
            else if (action == StartAction)
            {
                manager.StartTimer();
            }
            else if (action == PauseAction)
            {
                manager.TogglePause();
            }
            else if (action == ResetAction)
            {
                manager.ResetTimer();
            }
            else if (action == BellAction)
            {
                manager.RingBellNow();
            }
        }
    }
}
