using TMPro;
using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using VRC.Udon.Common;
using VRC.Udon.Common.Interfaces;

namespace CastTimerGimmick
{
    [UdonBehaviourSyncMode(BehaviourSyncMode.Manual)]
    public class CastTimerManager : UdonSharpBehaviour
    {
        private const int StateReady = 0;
        private const int StateRunning = 1;
        private const int StatePaused = 2;
        private const int StateFinished = 3;
        private const int MaximumSeconds = (99 * 60) + 59;
        private const int BellVolumeStepPercent = 10;
        private const int MaximumBellVolumePercent = 300;
        private const float WristTowardForearmDistance = 0.04f;
        private const float WristVerticalOffset = 0.15f;

        [Header("キャスト本人のタイマー表示")]
        public GameObject wristTimerRoot;
        public Transform wristTimerTransform;
        public TextMeshProUGUI wristTimerText;
        [Range(0.1f, 1f)] public float doubleTriggerWindow = 0.5f;

        [Header("キャスト登録パネル")]
        public TextMeshProUGUI registrationStatusText;
        public TextMeshProUGUI registrationVolumeText;

        [Header("スタッフ用表示")]
        public TextMeshProUGUI staffTimerText;
        public TextMeshProUGUI staffStateText;

        [Header("キャスト本人だけに聞こえるベル")]
        public AudioSource bellSource;

        [Header("初期時間")]
        [Range(1, MaximumSeconds)] public int initialSeconds = 300;

        [UdonSynced] private int syncedConfiguredSeconds = 300;
        [UdonSynced] private int syncedRemainingSeconds = 300;
        [UdonSynced] private double syncedStateServerTime;
        [UdonSynced] private int syncedTimerState;

        private VRCPlayerApi _localPlayer;
        private bool _localIsCast;
        private bool _localTimerVisible;
        private bool _localPlayerIsInVr;
        private int _localBellVolumePercent = 100;
        private float _lastLeftTriggerPress = -100f;
        private int _lastDisplayedSeconds = -1;
        private int _lastDisplayedState = -1;

        private void Start()
        {
            RefreshLocalPlayerState();

            if (Networking.IsOwner(gameObject) && syncedConfiguredSeconds <= 0)
            {
                syncedConfiguredSeconds = Mathf.Clamp(initialSeconds, 1, MaximumSeconds);
                syncedRemainingSeconds = syncedConfiguredSeconds;
                syncedTimerState = StateReady;
                syncedStateServerTime = Networking.GetServerTimeInSeconds();
                RequestSerialization();
            }

            if (wristTimerRoot != null)
            {
                wristTimerRoot.SetActive(false);
            }

            ApplyLocalBellVolume();
            UpdateRegistrationFeedback();
            UpdateBellVolumeFeedback();
            RefreshDisplays(true);
        }

        private void Update()
        {
            int remaining = GetCurrentRemainingSeconds();

            if (syncedTimerState == StateRunning && remaining <= 0 && Networking.IsOwner(gameObject))
            {
                syncedRemainingSeconds = 0;
                syncedTimerState = StateFinished;
                syncedStateServerTime = Networking.GetServerTimeInSeconds();
                RequestSerialization();
                SendCustomNetworkEvent(NetworkEventTarget.All, nameof(PlayBellForCasts));
            }

            RefreshDisplays(false);
        }

        public override void PostLateUpdate()
        {
            RefreshLocalPlayerState();
            if (!_localIsCast || !_localTimerVisible || !_localPlayerIsInVr || !Utilities.IsValid(_localPlayer))
            {
                return;
            }

            UpdateWristTimerTransform();
        }

        private void UpdateWristTimerTransform()
        {
            if (wristTimerTransform == null || !Utilities.IsValid(_localPlayer))
            {
                return;
            }

            VRCPlayerApi.TrackingData head = _localPlayer.GetTrackingData(VRCPlayerApi.TrackingDataType.Head);
            VRCPlayerApi.TrackingData leftHandTracking = _localPlayer.GetTrackingData(VRCPlayerApi.TrackingDataType.LeftHand);
            Vector3 handPosition = _localPlayer.GetBonePosition(HumanBodyBones.LeftHand);
            Vector3 lowerArmPosition = _localPlayer.GetBonePosition(HumanBodyBones.LeftLowerArm);
            Vector3 forearmDirection = handPosition - lowerArmPosition;

            float forearmLengthSquared = forearmDirection.sqrMagnitude;
            if (forearmLengthSquared < 0.0025f || forearmLengthSquared > 1f)
            {
                handPosition = leftHandTracking.position;
                forearmDirection = handPosition - head.position;
                if (forearmDirection.sqrMagnitude < 0.0001f)
                {
                    forearmDirection = -(head.rotation * Vector3.up);
                }
            }

            forearmDirection.Normalize();
            Vector3 wristPosition = handPosition - (forearmDirection * WristTowardForearmDistance);
            Vector3 displayPosition = wristPosition + (Vector3.up * WristVerticalOffset);
            Quaternion displayRotation = head.rotation;

            wristTimerTransform.SetPositionAndRotation(displayPosition, displayRotation);
        }

        public override void InputUse(bool value, UdonInputEventArgs args)
        {
            RefreshLocalPlayerState();

            if (!value || !_localIsCast || !_localPlayerIsInVr || args.handType != HandType.LEFT)
            {
                return;
            }

            float now = Time.time;
            if (now - _lastLeftTriggerPress <= doubleTriggerWindow)
            {
                _localTimerVisible = !_localTimerVisible;
                ApplyLocalTimerVisibility();
                if (_localTimerVisible)
                {
                    UpdateWristTimerTransform();
                }
                UpdateRegistrationFeedback();
                _lastLeftTriggerPress = -100f;
                return;
            }

            _lastLeftTriggerPress = now;
        }

        public void ToggleLocalCast()
        {
            RefreshLocalPlayerState();
            if (!_localPlayerIsInVr)
            {
                _localIsCast = false;
                _localTimerVisible = false;
                ApplyLocalTimerVisibility();
                UpdateRegistrationFeedback();
                return;
            }

            _localIsCast = !_localIsCast;
            if (!_localIsCast)
            {
                _localTimerVisible = false;
                ApplyLocalTimerVisibility();
            }

            UpdateRegistrationFeedback();
        }

        public void DecreaseLocalBellVolume()
        {
            AdjustLocalBellVolume(-BellVolumeStepPercent);
        }

        public void IncreaseLocalBellVolume()
        {
            AdjustLocalBellVolume(BellVolumeStepPercent);
        }

        public void AddTenMinutes()
        {
            AdjustConfiguredTime(600);
        }

        public void SubtractTenMinutes()
        {
            AdjustConfiguredTime(-600);
        }

        public void AddOneMinute()
        {
            AdjustConfiguredTime(60);
        }

        public void SubtractOneMinute()
        {
            AdjustConfiguredTime(-60);
        }

        public void AddTenSeconds()
        {
            AdjustConfiguredTime(10);
        }

        public void SubtractTenSeconds()
        {
            AdjustConfiguredTime(-10);
        }

        public void StartTimer()
        {
            TakeOwnership();
            syncedRemainingSeconds = Mathf.Clamp(syncedConfiguredSeconds, 1, MaximumSeconds);
            syncedStateServerTime = Networking.GetServerTimeInSeconds();
            syncedTimerState = StateRunning;
            RequestSerialization();
            RefreshDisplays(true);
        }

        public void TogglePause()
        {
            TakeOwnership();

            if (syncedTimerState == StateRunning)
            {
                syncedRemainingSeconds = GetCurrentRemainingSeconds();
                syncedStateServerTime = Networking.GetServerTimeInSeconds();
                syncedTimerState = syncedRemainingSeconds <= 0 ? StateFinished : StatePaused;
            }
            else if (syncedTimerState == StatePaused && syncedRemainingSeconds > 0)
            {
                syncedStateServerTime = Networking.GetServerTimeInSeconds();
                syncedTimerState = StateRunning;
            }
            else
            {
                return;
            }

            RequestSerialization();
            RefreshDisplays(true);
        }

        public void ResetTimer()
        {
            TakeOwnership();
            syncedRemainingSeconds = Mathf.Clamp(syncedConfiguredSeconds, 1, MaximumSeconds);
            syncedStateServerTime = Networking.GetServerTimeInSeconds();
            syncedTimerState = StateReady;
            RequestSerialization();
            RefreshDisplays(true);
        }

        public void RingBellNow()
        {
            SendCustomNetworkEvent(NetworkEventTarget.All, nameof(PlayBellForCasts));
        }

        public void PlayBellForCasts()
        {
            if (_localIsCast && bellSource != null && bellSource.clip != null)
            {
                bellSource.Play();
            }
        }

        public override void OnDeserialization()
        {
            RefreshDisplays(true);
        }

        private void AdjustConfiguredTime(int amount)
        {
            if (syncedTimerState == StateRunning)
            {
                return;
            }

            TakeOwnership();
            syncedConfiguredSeconds = Mathf.Clamp(syncedConfiguredSeconds + amount, 1, MaximumSeconds);
            syncedRemainingSeconds = syncedConfiguredSeconds;
            syncedStateServerTime = Networking.GetServerTimeInSeconds();
            syncedTimerState = StateReady;
            RequestSerialization();
            RefreshDisplays(true);
        }

        private void TakeOwnership()
        {
            if (!Networking.IsOwner(gameObject) && Utilities.IsValid(Networking.LocalPlayer))
            {
                Networking.SetOwner(Networking.LocalPlayer, gameObject);
            }
        }

        private int GetCurrentRemainingSeconds()
        {
            if (syncedTimerState != StateRunning)
            {
                return Mathf.Clamp(syncedRemainingSeconds, 0, MaximumSeconds);
            }

            double elapsed = Networking.GetServerTimeInSeconds() - syncedStateServerTime;
            if (elapsed < 0d)
            {
                elapsed = 0d;
            }

            int elapsedWholeSeconds = Mathf.FloorToInt((float)elapsed);
            return Mathf.Clamp(syncedRemainingSeconds - elapsedWholeSeconds, 0, MaximumSeconds);
        }

        private void RefreshDisplays(bool force)
        {
            int remaining = GetCurrentRemainingSeconds();
            if (force || remaining != _lastDisplayedSeconds)
            {
                string formatted = FormatTime(remaining);
                if (wristTimerText != null)
                {
                    wristTimerText.text = formatted;
                }

                if (staffTimerText != null)
                {
                    staffTimerText.text = formatted;
                }

                _lastDisplayedSeconds = remaining;
            }

            if (force || syncedTimerState != _lastDisplayedState)
            {
                if (staffStateText != null)
                {
                    if (syncedTimerState == StateRunning)
                    {
                        staffStateText.text = "実行中";
                    }
                    else if (syncedTimerState == StatePaused)
                    {
                        staffStateText.text = "一時停止";
                    }
                    else if (syncedTimerState == StateFinished)
                    {
                        staffStateText.text = "終了";
                    }
                    else
                    {
                        staffStateText.text = "待機中";
                    }
                }

                _lastDisplayedState = syncedTimerState;
            }
        }

        private string FormatTime(int totalSeconds)
        {
            int minutes = totalSeconds / 60;
            int seconds = totalSeconds % 60;
            string minuteText = minutes < 10 ? "0" + minutes.ToString() : minutes.ToString();
            string secondText = seconds < 10 ? "0" + seconds.ToString() : seconds.ToString();
            return minuteText + ":" + secondText;
        }

        private void ApplyLocalTimerVisibility()
        {
            if (wristTimerRoot != null)
            {
                wristTimerRoot.SetActive(_localIsCast && _localTimerVisible && _localPlayerIsInVr);
            }
        }

        private void RefreshLocalPlayerState()
        {
            if (!Utilities.IsValid(_localPlayer))
            {
                _localPlayer = Networking.LocalPlayer;
            }
            _localPlayerIsInVr = Utilities.IsValid(_localPlayer) && _localPlayer.IsUserInVR();
        }

        private void AdjustLocalBellVolume(int amount)
        {
            _localBellVolumePercent = Mathf.Clamp(_localBellVolumePercent + amount, 0, MaximumBellVolumePercent);
            ApplyLocalBellVolume();
            UpdateBellVolumeFeedback();
        }

        private void ApplyLocalBellVolume()
        {
            if (bellSource != null)
            {
                bellSource.volume = (float)_localBellVolumePercent / MaximumBellVolumePercent;
            }
        }

        private void UpdateBellVolumeFeedback()
        {
            if (registrationVolumeText != null)
            {
                registrationVolumeText.text = "ベル音量：" + _localBellVolumePercent.ToString() + "%";
            }
        }

        private void UpdateRegistrationFeedback()
        {
            if (registrationStatusText == null)
            {
                return;
            }

            if (!_localPlayerIsInVr)
            {
                registrationStatusText.text = "VRモード専用";
            }
            else if (_localIsCast)
            {
                registrationStatusText.text = _localTimerVisible
                    ? "キャスト：登録済み\nタイマー：表示中"
                    : "キャスト：登録済み\nタイマー：非表示（左トリガー2回）";
            }
            else
            {
                registrationStatusText.text = "キャスト：未登録\nボタンで登録";
            }
        }
    }
}
