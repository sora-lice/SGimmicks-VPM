using UdonSharp;
using UnityEngine;

namespace CastTimerGimmick
{
    [UdonBehaviourSyncMode(BehaviourSyncMode.NoVariableSync)]
    public class CastRegistrationButton : UdonSharpBehaviour
    {
        public const int ToggleCastAction = 0;
        public const int DecreaseBellVolumeAction = 1;
        public const int IncreaseBellVolumeAction = 2;

        public CastTimerManager manager;
        public int action;

        public override void Interact()
        {
            Press();
        }

        public void Press()
        {
            if (manager == null)
            {
                return;
            }

            if (action == DecreaseBellVolumeAction)
            {
                manager.DecreaseLocalBellVolume();
            }
            else if (action == IncreaseBellVolumeAction)
            {
                manager.IncreaseLocalBellVolume();
            }
            else
            {
                manager.ToggleLocalCast();
            }
        }
    }
}
