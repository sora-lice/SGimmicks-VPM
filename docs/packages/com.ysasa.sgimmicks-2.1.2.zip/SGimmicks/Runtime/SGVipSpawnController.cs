using UdonSharp;
using UnityEngine;
using VRC.SDKBase;

namespace SGimmicks
{
    [AddComponentMenu("SGimmicks/VIP Spawn Controller")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class SGVipSpawnController : UdonSharpBehaviour
    {
        [Header("VIP Spawn")]
        [Tooltip("VIP players are moved to this Transform after joining and after respawning.")]
        public Transform vipSpawnPoint;

        [Tooltip("Exact, case-sensitive VRChat display names. Login usernames are not available to Udon.")]
        public string[] vipDisplayNames;

        [Tooltip("If enabled, matching players return to the VIP point after Respawn.")]
        public bool useVipPointOnRespawn = true;

        private VRCPlayerApi _localPlayer;
        private bool _isLocalVip;
        private int _initializationAttempts;

        private void Start()
        {
            TryInitialVipSpawn();
        }

        public void TryInitialVipSpawn()
        {
            _localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(_localPlayer))
            {
                _initializationAttempts++;
                if (_initializationAttempts < 120)
                {
                    SendCustomEventDelayedFrames(nameof(TryInitialVipSpawn), 1);
                }
                return;
            }

            _isLocalVip = IsVipDisplayName(_localPlayer.displayName);
            if (_isLocalVip)
            {
                SendCustomEventDelayedFrames(nameof(MoveLocalVipToSpawn), 1);
            }
        }

        public override void OnPlayerRespawn(VRCPlayerApi player)
        {
            if (!useVipPointOnRespawn || !_isLocalVip || !Utilities.IsValid(player) || !player.isLocal)
            {
                return;
            }

            SendCustomEventDelayedFrames(nameof(MoveLocalVipToSpawn), 1);
        }

        public void MoveLocalVipToSpawn()
        {
            if (!_isLocalVip || vipSpawnPoint == null || !Utilities.IsValid(_localPlayer))
            {
                return;
            }

            _localPlayer.TeleportTo(vipSpawnPoint.position, vipSpawnPoint.rotation);
        }

        private bool IsVipDisplayName(string displayName)
        {
            if (vipDisplayNames == null)
            {
                return false;
            }

            for (int i = 0; i < vipDisplayNames.Length; i++)
            {
                if (displayName == vipDisplayNames[i])
                {
                    return true;
                }
            }

            return false;
        }
    }
}
