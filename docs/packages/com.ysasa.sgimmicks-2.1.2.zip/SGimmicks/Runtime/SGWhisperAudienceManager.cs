using UdonSharp;
using UnityEngine;
using UnityEngine.UI;
using VRC.SDKBase;

namespace SGimmicks
{
    [AddComponentMenu("SGimmicks/Whisper Audience Manager")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class SGWhisperAudienceManager : UdonSharpBehaviour
    {
        [Header("観客席")]
        public SGWhisperSeat[] seats;

        [Header("判定対象外（表示名の完全一致・大文字小文字を区別）")]
        public string[] castDisplayNames;

        [Header("スタッフ操作盤を使える人")]
        public string[] operatorDisplayNames;
        public bool allowInstanceMaster = true;

        [Header("スタッフ操作盤")]
        public Text selectedSeatText;
        public Text occupantText;
        public Text thresholdText;
        public Text resultText;
        public Text statusText;

        private int _selectedSeatIndex;

        private void Start()
        {
            RefreshPanel();
        }

        public override void OnPlayerJoined(VRCPlayerApi player)
        {
            SendCustomEventDelayedFrames(nameof(RefreshPanel), 2);
        }

        public override void OnPlayerLeft(VRCPlayerApi player)
        {
            SendCustomEventDelayedFrames(nameof(RefreshPanel), 2);
        }

        public bool IsCastDisplayName(string displayName)
        {
            if (string.IsNullOrEmpty(displayName) || castDisplayNames == null) return false;
            for (int i = 0; i < castDisplayNames.Length; i++)
            {
                if (displayName == castDisplayNames[i]) return true;
            }
            return false;
        }

        public void PreviousSeat()
        {
            if (!CanOperate() || seats == null || seats.Length == 0) return;
            _selectedSeatIndex--;
            if (_selectedSeatIndex < 0) _selectedSeatIndex = seats.Length - 1;
            RefreshPanel();
        }

        public void NextSeat()
        {
            if (!CanOperate() || seats == null || seats.Length == 0) return;
            _selectedSeatIndex++;
            if (_selectedSeatIndex >= seats.Length) _selectedSeatIndex = 0;
            RefreshPanel();
        }

        public void ThresholdDown()
        {
            ChangeThreshold(-0.05f);
        }

        public void ThresholdUp()
        {
            ChangeThreshold(0.05f);
        }

        public void ResetSelectedOut()
        {
            if (!CanOperate()) return;
            SGWhisperSeat seat = GetSelectedSeat();
            if (seat == null) return;
            seat.SetOutFromStaff(false);
            SetStatus("座席 " + (seat.seatIndex + 1) + " のOUTを解除しました");
            RefreshPanel();
        }

        public void RefreshPanel()
        {
            SGWhisperSeat seat = GetSelectedSeat();
            if (seat == null)
            {
                if (selectedSeatText != null) selectedSeatText.text = "座席なし";
                if (occupantText != null) occupantText.text = "着席者：---";
                if (thresholdText != null) thresholdText.text = "閾値：---";
                if (resultText != null) resultText.text = "状態：---";
                return;
            }

            if (selectedSeatText != null)
                selectedSeatText.text = "座席 " + (seat.seatIndex + 1).ToString("00");
            if (occupantText != null)
                occupantText.text = "着席者：" +
                                    (string.IsNullOrEmpty(seat.occupantDisplayName)
                                        ? "---"
                                        : seat.occupantDisplayName);
            if (thresholdText != null)
                thresholdText.text = "声量閾値：" + seat.voiceThreshold.ToString("0.00");
            if (resultText != null)
            {
                resultText.text = seat.isOut ? "状態：OUT" : "状態：SAFE";
                resultText.color = seat.isOut
                    ? new Color(1f, 0.24f, 0.18f, 1f)
                    : new Color(0.2f, 0.9f, 0.75f, 1f);
            }
        }

        private void ChangeThreshold(float delta)
        {
            if (!CanOperate()) return;
            SGWhisperSeat seat = GetSelectedSeat();
            if (seat == null) return;
            seat.SetThresholdFromStaff(Mathf.Clamp(seat.voiceThreshold + delta, 0.05f, 0.95f));
            SetStatus("座席 " + (seat.seatIndex + 1) + " の閾値を変更しました");
            RefreshPanel();
        }

        private SGWhisperSeat GetSelectedSeat()
        {
            if (seats == null || seats.Length == 0) return null;
            if (_selectedSeatIndex < 0 || _selectedSeatIndex >= seats.Length) _selectedSeatIndex = 0;
            return seats[_selectedSeatIndex];
        }

        private bool CanOperate()
        {
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(localPlayer)) return false;
            if (allowInstanceMaster && localPlayer.isMaster) return true;
            if (IsCastDisplayName(localPlayer.displayName)) return true;
            if (operatorDisplayNames != null)
            {
                for (int i = 0; i < operatorDisplayNames.Length; i++)
                {
                    if (localPlayer.displayName == operatorDisplayNames[i]) return true;
                }
            }
            SetStatus("この操作盤を使う権限がありません");
            return false;
        }

        private void SetStatus(string value)
        {
            if (statusText != null) statusText.text = value;
        }
    }
}
