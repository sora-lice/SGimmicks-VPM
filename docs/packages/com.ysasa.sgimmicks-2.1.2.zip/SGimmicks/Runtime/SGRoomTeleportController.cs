using UdonSharp;
using UnityEngine;
using UnityEngine.UI;
using VRC.SDKBase;

namespace SGimmicks
{
    [AddComponentMenu("SGimmicks/Room Number Teleport Controller")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.Manual)]
    public class SGRoomTeleportController : UdonSharpBehaviour
    {
        [Header("4桁の部屋番号と移動先")]
        public string[] roomCodes;
        public Transform[] roomDestinations;

        [Header("RTab表示")]
        public Text inputDisplayText;
        public Text statusText;

        [Header("共有タブレット（任意）")]
        [Tooltip("RTabがPickupの場合に自動設定されます。テレポート前に利用者の手から離します。")]
        public VRC_Pickup sharedTabletPickup;

        [Header("グローバル表示切替")]
        [Tooltip("表示／非表示をインスタンス内の全員へ同期するオブジェクトです。")]
        public GameObject globalToggleObject;
        [Tooltip("この4桁を入力してEを押すと、対象オブジェクトを全員に表示します。")]
        public string globalShowCode = "9001";
        [Tooltip("この4桁を入力してEを押すと、対象オブジェクトを全員から非表示にします。")]
        public string globalHideCode = "9000";

        [UdonSynced] private bool _globalObjectVisible;

        private string _inputCode = "";
        private bool _sessionActive;
        private Transform _pendingDestination;

        private void Start()
        {
            _inputCode = "";
            _sessionActive = false;
            if (globalToggleObject != null)
                _globalObjectVisible = globalToggleObject.activeSelf;
            UpdateDisplay();
            SetStatus("利用開始を押してください");
        }

        public override void OnDeserialization()
        {
            ApplyGlobalObjectState();
        }

        public void BeginOrSwitchUser()
        {
            _inputCode = "";
            _sessionActive = true;
            UpdateDisplay();
            SetStatus("4桁の部屋番号を入力してください");
        }

        public void Press0() { AppendDigit("0"); }
        public void Press1() { AppendDigit("1"); }
        public void Press2() { AppendDigit("2"); }
        public void Press3() { AppendDigit("3"); }
        public void Press4() { AppendDigit("4"); }
        public void Press5() { AppendDigit("5"); }
        public void Press6() { AppendDigit("6"); }
        public void Press7() { AppendDigit("7"); }
        public void Press8() { AppendDigit("8"); }
        public void Press9() { AppendDigit("9"); }

        public void ClearInput()
        {
            if (!_sessionActive) _sessionActive = true;
            _inputCode = "";
            UpdateDisplay();
            SetStatus("入力を消去しました");
        }

        public void EnterCode()
        {
            if (!_sessionActive)
            {
                SetStatus("利用開始を押してください");
                return;
            }

            if (_inputCode.Length != 4)
            {
                SetStatus("4桁入力してからEを押してください");
                return;
            }

            string enteredCode = _inputCode;
            if (TrySetGlobalObjectState(enteredCode))
            {
                _inputCode = "";
                _sessionActive = false;
                UpdateDisplay();
                return;
            }

            int destinationIndex = FindDestinationIndex(enteredCode);
            if (destinationIndex < 0)
            {
                SetStatus("該当する番号がありません");
                _inputCode = "";
                UpdateDisplay();
                return;
            }

            if (roomDestinations == null || destinationIndex >= roomDestinations.Length ||
                roomDestinations[destinationIndex] == null)
            {
                SetStatus("移動先が設定されていません");
                return;
            }

            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(localPlayer))
            {
                SetStatus("ローカルプレイヤーを取得できません");
                return;
            }

            Transform destination = roomDestinations[destinationIndex];
            SetStatus("部屋 " + enteredCode + " へ移動します");
            _inputCode = "";
            _sessionActive = false;
            UpdateDisplay();

            if (DropSharedTabletIfHeld(localPlayer))
            {
                _pendingDestination = destination;
                SendCustomEventDelayedFrames(nameof(CompletePendingTeleport), 1);
                return;
            }

            localPlayer.TeleportTo(destination.position, destination.rotation);
        }

        public void CompletePendingTeleport()
        {
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(localPlayer) || _pendingDestination == null) return;

            Transform destination = _pendingDestination;
            _pendingDestination = null;
            localPlayer.TeleportTo(destination.position, destination.rotation);
        }

        private void AppendDigit(string digit)
        {
            if (!_sessionActive) BeginOrSwitchUser();
            if (_inputCode.Length >= 4)
            {
                SetStatus("Eで決定、Cで消去できます");
                return;
            }

            _inputCode += digit;
            UpdateDisplay();
            SetStatus(_inputCode.Length == 4
                ? "Eを押して実行します"
                : "残り " + (4 - _inputCode.Length) + " 桁");
        }

        private bool TrySetGlobalObjectState(string code)
        {
            if (globalToggleObject == null) return false;

            bool show = !string.IsNullOrEmpty(globalShowCode) && code == globalShowCode;
            bool hide = !string.IsNullOrEmpty(globalHideCode) && code == globalHideCode;
            if (!show && !hide) return false;

            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(localPlayer))
            {
                SetStatus("ローカルプレイヤーを取得できません");
                return true;
            }

            if (!Networking.IsOwner(gameObject))
                Networking.SetOwner(localPlayer, gameObject);

            _globalObjectVisible = show;
            ApplyGlobalObjectState();
            RequestSerialization();
            SetStatus(show
                ? "オブジェクトを全員に表示しました"
                : "オブジェクトを全員から非表示にしました");
            return true;
        }

        private void ApplyGlobalObjectState()
        {
            if (globalToggleObject != null)
                globalToggleObject.SetActive(_globalObjectVisible);
        }

        private int FindDestinationIndex(string code)
        {
            if (roomCodes == null) return -1;
            for (int i = 0; i < roomCodes.Length; i++)
            {
                if (roomCodes[i] == code) return i;
            }
            return -1;
        }

        private bool DropSharedTabletIfHeld(VRCPlayerApi localPlayer)
        {
            if (sharedTabletPickup == null || !Utilities.IsValid(localPlayer)) return false;

            VRC_Pickup leftPickup = localPlayer.GetPickupInHand(VRC_Pickup.PickupHand.Left);
            VRC_Pickup rightPickup = localPlayer.GetPickupInHand(VRC_Pickup.PickupHand.Right);
            if (leftPickup != sharedTabletPickup && rightPickup != sharedTabletPickup) return false;

            sharedTabletPickup.Drop();
            return true;
        }

        private void UpdateDisplay()
        {
            if (inputDisplayText == null) return;
            string display = _inputCode;
            while (display.Length < 4) display += "－";
            inputDisplayText.text = display;
        }

        private void SetStatus(string value)
        {
            if (statusText != null) statusText.text = value;
        }
    }
}
