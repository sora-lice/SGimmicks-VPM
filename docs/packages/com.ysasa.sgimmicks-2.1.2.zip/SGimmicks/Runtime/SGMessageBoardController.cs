using TMPro;
using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using VRC.Udon.Common.Interfaces;

namespace SGimmicks
{
    [AddComponentMenu("SGimmicks/Message Board Controller")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.Manual)]
    public class SGMessageBoardController : UdonSharpBehaviour
    {
        [Header("ローカル入力パネル")]
        public GameObject inputPanelRoot;
        public TMP_InputField inputField;
        public TMP_Text previewText;
        public TMP_Text fontSizeText;
        [Range(1, 100)] public int maximumCharacters = 100;
        public bool keepInputPanelVisible = true;

        [Header("同期表示画面")]
        public TMP_Text[] outputTexts;
        [Range(12f, 200f)] public float outputFontSize = 52f;
        [Range(1f, 20f)] public float fontSizeStep = 4f;
        [Range(12f, 200f)] public float minimumOutputFontSize = 12f;
        [Range(12f, 200f)] public float maximumOutputFontSize = 200f;
        [TextArea] public string emptyMessage = "お題を入力してください";

        [Header("確定音（任意）")]
        public AudioSource submitAudioSource;
        public AudioSource[] outputAudioSources;

        [UdonSynced] private string _syncedText = "";
        [UdonSynced] public float syncedFontSize = 52f;

        private void Start()
        {
            if (inputPanelRoot != null) inputPanelRoot.SetActive(keepInputPanelVisible);
            if (syncedFontSize < minimumOutputFontSize) syncedFontSize = outputFontSize;
            ApplySyncedText();
        }

        public override void Interact()
        {
            if (inputPanelRoot == null) return;
            inputPanelRoot.SetActive(true);
            if (inputField != null)
                inputField.SetTextWithoutNotify(_syncedText == null ? "" : _syncedText);
            UpdatePreview();
        }

        public void UpdatePreview()
        {
            if (previewText == null) return;
            string value = GetLimitedInput();
            previewText.text = value == "" ? emptyMessage : value;
        }

        public void SubmitMessage()
        {
            string value = GetLimitedInput();
            TakeOwnership();

            _syncedText = value;
            ApplySyncedText();
            RequestSerialization();
            SendCustomNetworkEvent(NetworkEventTarget.All, nameof(PlaySubmitSound));
            if (inputPanelRoot != null && !keepInputPanelVisible) inputPanelRoot.SetActive(false);
        }

        public void ClearInput()
        {
            if (inputField != null) inputField.SetTextWithoutNotify("");
            UpdatePreview();
        }

        public void DecreaseFontSize()
        {
            ChangeFontSize(-fontSizeStep);
        }

        public void IncreaseFontSize()
        {
            ChangeFontSize(fontSizeStep);
        }

        public void CancelInput()
        {
            if (keepInputPanelVisible)
            {
                if (inputField != null)
                    inputField.SetTextWithoutNotify(_syncedText == null ? "" : _syncedText);
                UpdatePreview();
            }
            else if (inputPanelRoot != null)
            {
                inputPanelRoot.SetActive(false);
            }
        }

        public void PlaySubmitSound()
        {
            if (submitAudioSource != null && submitAudioSource.clip != null)
                submitAudioSource.Play();
            if (outputAudioSources == null) return;
            for (int i = 0; i < outputAudioSources.Length; i++)
            {
                AudioSource outputAudio = outputAudioSources[i];
                if (outputAudio == null || outputAudio == submitAudioSource || outputAudio.clip == null) continue;
                outputAudio.Play();
            }
        }

        public override void OnDeserialization()
        {
            ApplySyncedText();
        }

        private string GetLimitedInput()
        {
            if (inputField == null || inputField.text == null) return "";
            string value = inputField.text;
            int limit = Mathf.Clamp(maximumCharacters, 1, 100);
            if (value.Length > limit) value = value.Substring(0, limit);
            return value;
        }

        private void ApplySyncedText()
        {
            string value = _syncedText == null || _syncedText == "" ? emptyMessage : _syncedText;
            float appliedSize = Mathf.Clamp(syncedFontSize, minimumOutputFontSize, maximumOutputFontSize);
            outputFontSize = appliedSize;
            if (fontSizeText != null) fontSizeText.text = "本文サイズ " + appliedSize.ToString("F0");
            if (outputTexts == null) return;
            for (int i = 0; i < outputTexts.Length; i++)
            {
                TMP_Text output = outputTexts[i];
                if (output == null) continue;
                output.richText = false;
                output.enableWordWrapping = true;
                output.fontSize = appliedSize;
                output.text = value;
            }
        }

        private void ChangeFontSize(float amount)
        {
            TakeOwnership();
            syncedFontSize = Mathf.Clamp(syncedFontSize + amount,
                minimumOutputFontSize, maximumOutputFontSize);
            ApplySyncedText();
            RequestSerialization();
        }

        private void TakeOwnership()
        {
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (Utilities.IsValid(localPlayer) && !Networking.IsOwner(gameObject))
                Networking.SetOwner(localPlayer, gameObject);
        }
    }
}
