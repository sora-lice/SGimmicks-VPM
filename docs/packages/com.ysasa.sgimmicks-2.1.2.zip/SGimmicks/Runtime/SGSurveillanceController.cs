using UdonSharp;
using UnityEngine;
using UnityEngine.UI;
using VRC.SDKBase;

namespace SGimmicks
{
    [AddComponentMenu("SGimmicks/Surveillance Controller")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class SGSurveillanceController : UdonSharpBehaviour
    {
        [Header("Cameras")]
        public Camera[] surveillanceCameras;
        public string[] cameraLabels;
        public Renderer monitorRenderer;
        public Text cameraStatusText;
        public int initialCameraIndex;

        [Header("監視モニター壁")]
        public GameObject monitorWallRoot;
        public Renderer[] monitorRenderers;
        public int monitorColumns = 2;
        public int monitorRows = 2;

        [Header("描画負荷の軽減")]
        [Tooltip("一覧表示では同時に1台だけ描画し、このフレーム数ごとに次のカメラへ切り替えます。")]
        [Range(1, 10)] public int overviewFramesPerCamera = 1;

        [Header("ローカル拡大表示")]
        public GameObject focusMonitorRoot;
        public GameObject[] focusMonitorScreens;
        public GameObject overviewTabContent;
        public GameObject focusTabContent;
        public GameObject voiceTabContent;
        public GameObject overviewTabIndicator;
        public GameObject focusTabIndicator;
        public GameObject voiceTabIndicator;
        [Range(1, 8)] public int camerasPerPage = 8;
        public Text[] focusCameraButtonTexts;
        public GameObject[] focusCameraSelectionIndicators;
        public Text focusCameraPageText;
        public Text overviewSummaryText;

        [Header("操作パネル表示")]
        [Range(28, 52)] public int operationPanelFontSize = 40;

        [Header("Local camera controls")]
        [Range(0.5f, 30f)] public float panStep = 5f;
        [Range(0.5f, 30f)] public float tiltStep = 5f;
        [Range(0.5f, 30f)] public float zoomStep = 5f;
        public float minimumPan = -180f;
        public float maximumPan = 180f;
        public float minimumTilt = -75f;
        public float maximumTilt = 75f;
        public float minimumFieldOfView = 20f;
        public float maximumFieldOfView = 90f;

        [Header("Player list")]
        [Range(1, 8)] public int playersPerPage = 8;
        public Text[] playerRowTexts;
        public GameObject[] playerSelectionIndicators;
        public Text playerPageText;

        [Header("Remote voice for selected players")]
        [Tooltip("The selected players' voices stay at full volume up to this distance.")]
        public float monitoredVoiceNear = 1000000f;
        [Tooltip("The selected players' voices can be heard up to this distance.")]
        public float monitoredVoiceFar = 1000000f;
        [Tooltip("Values restored when a player is deselected. These are VRChat's standard defaults.")]
        public float normalVoiceNear = 0f;
        public float normalVoiceFar = 25f;

        private int _cameraIndex;
        private Quaternion[] _baseCameraRotations;
        private float[] _panValues;
        private float[] _tiltValues;
        private float[] _initialFieldOfView;
        private int _cameraPage;
        private bool _focusMode;
        private int _renderCameraIndex = -1;
        private int _overviewFrameCounter;

        private VRCPlayerApi[] _displayPlayers;
        private VRCPlayerApi[] _selectedPlayers;
        private int _displayPlayerCount;
        private int _selectedPlayerCount;
        private int _playerPage;

        private void Start()
        {
            InitializeCameras();
            _selectedPlayers = new VRCPlayerApi[80];
            RefreshPlayers();
            ShowOverviewTab();
        }

        private void OnDisable()
        {
            DisableAllCameras();
            RestoreAllSelectedVoices();
        }

        private void LateUpdate()
        {
            int cameraCount = GetCameraCount();
            if (cameraCount <= 0) return;

            if (_focusMode)
            {
                SetRenderedCamera(_cameraIndex);
                return;
            }

            _overviewFrameCounter++;
            if (_renderCameraIndex >= 0 &&
                _overviewFrameCounter < Mathf.Max(1, overviewFramesPerCamera)) return;

            _overviewFrameCounter = 0;
            int nextIndex = _renderCameraIndex;
            for (int i = 0; i < cameraCount; i++)
            {
                nextIndex++;
                if (nextIndex >= cameraCount) nextIndex = 0;
                if (surveillanceCameras[nextIndex] != null)
                {
                    SetRenderedCamera(nextIndex);
                    return;
                }
            }
        }

        public override void OnPlayerJoined(VRCPlayerApi player)
        {
            SendCustomEventDelayedFrames(nameof(RefreshPlayers), 1);
        }

        public override void OnPlayerLeft(VRCPlayerApi player)
        {
            RemoveInvalidSelectedPlayers();
            SendCustomEventDelayedFrames(nameof(RefreshPlayers), 1);
        }

        public void PreviousCamera()
        {
            int cameraCount = GetCameraCount();
            if (cameraCount == 0) return;
            _cameraIndex--;
            if (_cameraIndex < 0) _cameraIndex = cameraCount - 1;
            ApplySelectedCamera();
        }

        public void NextCamera()
        {
            int cameraCount = GetCameraCount();
            if (cameraCount == 0) return;
            _cameraIndex++;
            if (_cameraIndex >= cameraCount) _cameraIndex = 0;
            ApplySelectedCamera();
        }

        public void ShowOverviewTab()
        {
            _focusMode = false;
            SetTabState(true, false, false);
            UpdateFocusMonitor();
        }

        public void ShowFocusTab()
        {
            _focusMode = true;
            SetTabState(false, true, false);
            DrawCameraPage();
            UpdateFocusMonitor();
        }

        public void ShowVoiceTab()
        {
            _focusMode = false;
            SetTabState(false, false, true);
            DrawPlayerPage();
            UpdateFocusMonitor();
        }

        public void PreviousCameraPage()
        {
            int pageCount = GetCameraPageCount();
            if (pageCount <= 1) return;
            _cameraPage--;
            if (_cameraPage < 0) _cameraPage = pageCount - 1;
            DrawCameraPage();
        }

        public void NextCameraPage()
        {
            int pageCount = GetCameraPageCount();
            if (pageCount <= 1) return;
            _cameraPage++;
            if (_cameraPage >= pageCount) _cameraPage = 0;
            DrawCameraPage();
        }

        public void SelectCameraSlot0() { SelectCameraSlot(0); }
        public void SelectCameraSlot1() { SelectCameraSlot(1); }
        public void SelectCameraSlot2() { SelectCameraSlot(2); }
        public void SelectCameraSlot3() { SelectCameraSlot(3); }
        public void SelectCameraSlot4() { SelectCameraSlot(4); }
        public void SelectCameraSlot5() { SelectCameraSlot(5); }
        public void SelectCameraSlot6() { SelectCameraSlot(6); }
        public void SelectCameraSlot7() { SelectCameraSlot(7); }

        public void PanLeft() { ChangePan(-panStep); }
        public void PanRight() { ChangePan(panStep); }
        public void TiltUp() { ChangeTilt(-tiltStep); }
        public void TiltDown() { ChangeTilt(tiltStep); }
        public void ZoomIn() { ChangeZoom(-zoomStep); }
        public void ZoomOut() { ChangeZoom(zoomStep); }

        public void ResetCameraView()
        {
            if (!HasCurrentCamera()) return;
            _panValues[_cameraIndex] = 0f;
            _tiltValues[_cameraIndex] = 0f;
            Camera cameraComponent = surveillanceCameras[_cameraIndex];
            cameraComponent.transform.localRotation = _baseCameraRotations[_cameraIndex];
            cameraComponent.fieldOfView = _initialFieldOfView[_cameraIndex];
            UpdateCameraStatus();
        }

        public void PreviousPlayerPage()
        {
            int pageCount = GetPlayerPageCount();
            if (pageCount <= 1) return;
            _playerPage--;
            if (_playerPage < 0) _playerPage = pageCount - 1;
            DrawPlayerPage();
        }

        public void NextPlayerPage()
        {
            int pageCount = GetPlayerPageCount();
            if (pageCount <= 1) return;
            _playerPage++;
            if (_playerPage >= pageCount) _playerPage = 0;
            DrawPlayerPage();
        }

        public void TogglePlayerSlot0() { TogglePlayerSlot(0); }
        public void TogglePlayerSlot1() { TogglePlayerSlot(1); }
        public void TogglePlayerSlot2() { TogglePlayerSlot(2); }
        public void TogglePlayerSlot3() { TogglePlayerSlot(3); }
        public void TogglePlayerSlot4() { TogglePlayerSlot(4); }
        public void TogglePlayerSlot5() { TogglePlayerSlot(5); }
        public void TogglePlayerSlot6() { TogglePlayerSlot(6); }
        public void TogglePlayerSlot7() { TogglePlayerSlot(7); }

        public void StopAllVoiceMonitoring()
        {
            RestoreAllSelectedVoices();
            DrawPlayerPage();
        }

        public void RefreshPlayers()
        {
            int playerCount = VRCPlayerApi.GetPlayerCount();
            VRCPlayerApi[] allPlayers = new VRCPlayerApi[playerCount];
            VRCPlayerApi.GetPlayers(allPlayers);

            _displayPlayers = new VRCPlayerApi[playerCount];
            _displayPlayerCount = 0;
            for (int i = 0; i < allPlayers.Length; i++)
            {
                VRCPlayerApi player = allPlayers[i];
                if (Utilities.IsValid(player) && !player.isLocal)
                {
                    _displayPlayers[_displayPlayerCount] = player;
                    _displayPlayerCount++;
                }
            }

            RemoveInvalidSelectedPlayers();
            int pageCount = GetPlayerPageCount();
            if (_playerPage >= pageCount) _playerPage = pageCount - 1;
            if (_playerPage < 0) _playerPage = 0;
            DrawPlayerPage();
        }

        private void InitializeCameras()
        {
            int cameraCount = GetCameraCount();
            _baseCameraRotations = new Quaternion[cameraCount];
            _panValues = new float[cameraCount];
            _tiltValues = new float[cameraCount];
            _initialFieldOfView = new float[cameraCount];

            for (int i = 0; i < cameraCount; i++)
            {
                Camera cameraComponent = surveillanceCameras[i];
                if (cameraComponent == null) continue;
                _baseCameraRotations[i] = cameraComponent.transform.localRotation;
                _initialFieldOfView[i] = cameraComponent.fieldOfView;
                cameraComponent.enabled = false;
            }

            _cameraIndex = Mathf.Clamp(initialCameraIndex, 0, Mathf.Max(0, cameraCount - 1));
            _cameraPage = _cameraIndex / Mathf.Max(1, camerasPerPage);
            ApplySelectedCamera();
            if (overviewSummaryText != null)
                overviewSummaryText.text = "全 " + cameraCount + " 台を省負荷で順次更新中";
        }

        private void SetRenderedCamera(int cameraIndex)
        {
            if (_renderCameraIndex == cameraIndex) return;
            if (_renderCameraIndex >= 0 && _renderCameraIndex < GetCameraCount())
            {
                Camera previous = surveillanceCameras[_renderCameraIndex];
                if (previous != null) previous.enabled = false;
            }

            _renderCameraIndex = cameraIndex;
            if (_renderCameraIndex >= 0 && _renderCameraIndex < GetCameraCount())
            {
                Camera current = surveillanceCameras[_renderCameraIndex];
                if (current != null) current.enabled = true;
            }
        }

        private void DisableAllCameras()
        {
            int cameraCount = GetCameraCount();
            for (int i = 0; i < cameraCount; i++)
            {
                Camera cameraComponent = surveillanceCameras[i];
                if (cameraComponent != null) cameraComponent.enabled = false;
            }
            _renderCameraIndex = -1;
        }

        private int GetCameraCount()
        {
            return surveillanceCameras == null ? 0 : surveillanceCameras.Length;
        }

        private bool HasCurrentCamera()
        {
            return _cameraIndex >= 0 && _cameraIndex < GetCameraCount() && surveillanceCameras[_cameraIndex] != null;
        }

        private void ApplySelectedCamera()
        {
            UpdateCameraStatus();
            DrawCameraPage();
            UpdateFocusMonitor();
        }

        private void SetTabState(bool overview, bool focus, bool voice)
        {
            if (overviewTabContent != null) overviewTabContent.SetActive(overview);
            if (focusTabContent != null) focusTabContent.SetActive(focus);
            if (voiceTabContent != null) voiceTabContent.SetActive(voice);
            if (overviewTabIndicator != null) overviewTabIndicator.SetActive(overview);
            if (focusTabIndicator != null) focusTabIndicator.SetActive(focus);
            if (voiceTabIndicator != null) voiceTabIndicator.SetActive(voice);
        }

        private int GetCameraPageCount()
        {
            int countPerPage = Mathf.Max(1, camerasPerPage);
            return Mathf.Max(1, Mathf.CeilToInt((float)GetCameraCount() / countPerPage));
        }

        private void SelectCameraSlot(int slot)
        {
            int cameraIndex = _cameraPage * Mathf.Max(1, camerasPerPage) + slot;
            if (cameraIndex < 0 || cameraIndex >= GetCameraCount()) return;
            if (surveillanceCameras[cameraIndex] == null) return;
            _cameraIndex = cameraIndex;
            _focusMode = true;
            ApplySelectedCamera();
        }

        private void DrawCameraPage()
        {
            if (focusCameraButtonTexts == null) return;
            int countPerPage = Mathf.Max(1, camerasPerPage);
            for (int slot = 0; slot < focusCameraButtonTexts.Length; slot++)
            {
                int cameraIndex = _cameraPage * countPerPage + slot;
                bool hasCamera = cameraIndex >= 0 && cameraIndex < GetCameraCount() &&
                                 surveillanceCameras[cameraIndex] != null;
                if (focusCameraButtonTexts[slot] != null)
                {
                    focusCameraButtonTexts[slot].text = hasCamera
                        ? "カメラ " + (cameraIndex + 1)
                        : "---";
                }
                if (focusCameraSelectionIndicators != null &&
                    slot < focusCameraSelectionIndicators.Length &&
                    focusCameraSelectionIndicators[slot] != null)
                {
                    focusCameraSelectionIndicators[slot].SetActive(hasCamera && cameraIndex == _cameraIndex);
                }
            }

            if (focusCameraPageText != null)
                focusCameraPageText.text = (_cameraPage + 1) + " / " + GetCameraPageCount();
        }

        private void UpdateFocusMonitor()
        {
            if (focusMonitorRoot != null) focusMonitorRoot.SetActive(_focusMode);
            if (focusMonitorScreens == null) return;
            for (int i = 0; i < focusMonitorScreens.Length; i++)
            {
                if (focusMonitorScreens[i] != null)
                    focusMonitorScreens[i].SetActive(_focusMode && i == _cameraIndex);
            }
        }

        private void ChangePan(float amount)
        {
            if (!HasCurrentCamera()) return;
            _panValues[_cameraIndex] = Mathf.Clamp(_panValues[_cameraIndex] + amount, minimumPan, maximumPan);
            ApplyCameraRotation();
        }

        private void ChangeTilt(float amount)
        {
            if (!HasCurrentCamera()) return;
            _tiltValues[_cameraIndex] = Mathf.Clamp(_tiltValues[_cameraIndex] + amount, minimumTilt, maximumTilt);
            ApplyCameraRotation();
        }

        private void ApplyCameraRotation()
        {
            Camera cameraComponent = surveillanceCameras[_cameraIndex];
            cameraComponent.transform.localRotation = _baseCameraRotations[_cameraIndex] *
                                                      Quaternion.Euler(_tiltValues[_cameraIndex], _panValues[_cameraIndex], 0f);
            UpdateCameraStatus();
        }

        private void ChangeZoom(float amount)
        {
            if (!HasCurrentCamera()) return;
            Camera cameraComponent = surveillanceCameras[_cameraIndex];
            cameraComponent.fieldOfView = Mathf.Clamp(cameraComponent.fieldOfView + amount,
                minimumFieldOfView, maximumFieldOfView);
            UpdateCameraStatus();
        }

        private void UpdateCameraStatus()
        {
            if (cameraStatusText == null) return;
            if (!HasCurrentCamera())
            {
                cameraStatusText.text = "カメラが設定されていません";
                return;
            }

            string label = "カメラ " + (_cameraIndex + 1);
            if (cameraLabels != null && _cameraIndex < cameraLabels.Length && cameraLabels[_cameraIndex] != "")
            {
                label = cameraLabels[_cameraIndex];
            }
            cameraStatusText.text = label + "　画角 " + surveillanceCameras[_cameraIndex].fieldOfView.ToString("F0") + "°";
        }

        private int GetPlayerPageCount()
        {
            int countPerPage = Mathf.Max(1, playersPerPage);
            return Mathf.Max(1, Mathf.CeilToInt((float)_displayPlayerCount / countPerPage));
        }

        private void DrawPlayerPage()
        {
            if (playerRowTexts == null) return;
            int countPerPage = Mathf.Max(1, playersPerPage);
            for (int slot = 0; slot < playerRowTexts.Length; slot++)
            {
                int playerIndex = _playerPage * countPerPage + slot;
                bool hasPlayer = playerIndex >= 0 && playerIndex < _displayPlayerCount &&
                                 Utilities.IsValid(_displayPlayers[playerIndex]);
                if (playerRowTexts[slot] != null)
                {
                    playerRowTexts[slot].text = hasPlayer ? _displayPlayers[playerIndex].displayName : "---";
                }
                if (playerSelectionIndicators != null && slot < playerSelectionIndicators.Length &&
                    playerSelectionIndicators[slot] != null)
                {
                    playerSelectionIndicators[slot].SetActive(hasPlayer && IsPlayerSelected(_displayPlayers[playerIndex]));
                }
            }

            if (playerPageText != null)
            {
                playerPageText.text = (_playerPage + 1) + " / " + GetPlayerPageCount();
            }
        }

        private void TogglePlayerSlot(int slot)
        {
            int playerIndex = _playerPage * Mathf.Max(1, playersPerPage) + slot;
            if (playerIndex < 0 || playerIndex >= _displayPlayerCount) return;
            VRCPlayerApi player = _displayPlayers[playerIndex];
            if (!Utilities.IsValid(player)) return;

            int selectedIndex = FindSelectedPlayer(player);
            if (selectedIndex >= 0)
            {
                RestoreNormalVoice(player);
                RemoveSelectedAt(selectedIndex);
            }
            else
            {
                AddSelectedPlayer(player);
                ApplyMonitoredVoice(player);
            }
            DrawPlayerPage();
        }

        private void AddSelectedPlayer(VRCPlayerApi player)
        {
            if (_selectedPlayers == null) _selectedPlayers = new VRCPlayerApi[80];
            if (_selectedPlayerCount >= _selectedPlayers.Length) return;
            _selectedPlayers[_selectedPlayerCount] = player;
            _selectedPlayerCount++;
        }

        private bool IsPlayerSelected(VRCPlayerApi player)
        {
            return FindSelectedPlayer(player) >= 0;
        }

        private int FindSelectedPlayer(VRCPlayerApi player)
        {
            if (!Utilities.IsValid(player) || _selectedPlayers == null) return -1;
            for (int i = 0; i < _selectedPlayerCount; i++)
            {
                VRCPlayerApi selected = _selectedPlayers[i];
                if (Utilities.IsValid(selected) && selected.playerId == player.playerId)
                {
                    return i;
                }
            }
            return -1;
        }

        private void RemoveSelectedAt(int index)
        {
            if (index < 0 || index >= _selectedPlayerCount) return;
            for (int i = index; i < _selectedPlayerCount - 1; i++)
            {
                _selectedPlayers[i] = _selectedPlayers[i + 1];
            }
            _selectedPlayerCount--;
            _selectedPlayers[_selectedPlayerCount] = null;
        }

        private void RemoveInvalidSelectedPlayers()
        {
            if (_selectedPlayers == null) return;
            for (int i = _selectedPlayerCount - 1; i >= 0; i--)
            {
                if (!Utilities.IsValid(_selectedPlayers[i]))
                {
                    RemoveSelectedAt(i);
                }
            }
        }

        private void ApplyMonitoredVoice(VRCPlayerApi player)
        {
            if (!Utilities.IsValid(player) || player.isLocal) return;
            player.SetVoiceDistanceNear(monitoredVoiceNear);
            player.SetVoiceDistanceFar(monitoredVoiceFar);
        }

        private void RestoreNormalVoice(VRCPlayerApi player)
        {
            if (!Utilities.IsValid(player) || player.isLocal) return;
            player.SetVoiceDistanceNear(normalVoiceNear);
            player.SetVoiceDistanceFar(normalVoiceFar);
        }

        private void RestoreAllSelectedVoices()
        {
            if (_selectedPlayers == null) return;
            for (int i = 0; i < _selectedPlayerCount; i++)
            {
                RestoreNormalVoice(_selectedPlayers[i]);
                _selectedPlayers[i] = null;
            }
            _selectedPlayerCount = 0;
        }
    }
}
