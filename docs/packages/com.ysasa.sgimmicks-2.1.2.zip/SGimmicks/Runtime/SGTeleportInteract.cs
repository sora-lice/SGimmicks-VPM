using UdonSharp;
using UnityEngine;
using VRC.SDKBase;

namespace SGimmicks
{
    [AddComponentMenu("SGimmicks/Teleport Interact")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class SGTeleportInteract : UdonSharpBehaviour
    {
        [Header("Teleport")]
        [Tooltip("The local player is teleported to this Transform.")]
        public Transform destination;

        [Tooltip("Text displayed by VRChat when this object can be used.")]
        public string interactionPrompt = "テレポート";

        private void Start()
        {
            InteractionText = interactionPrompt;
            DisableInteractive = destination == null;
        }

        public override void Interact()
        {
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(localPlayer) || destination == null)
            {
                return;
            }

            localPlayer.TeleportTo(destination.position, destination.rotation);
        }
    }
}
