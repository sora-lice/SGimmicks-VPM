using UdonSharp;
using UnityEngine;
using UnityEngine.UI;
using VRC.SDKBase;

namespace SGimmicks
{
    [AddComponentMenu("SGimmicks/Concert Lighting Controller")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.Manual)]
    public class SGConcertLightingController : UdonSharpBehaviour
    {
        [Header("ステージ位置")]
        public Transform ceilingLightPoint;
        public Transform stageTargetPoint;
        [Range(5f, 100f)] public float coneAngle = 38f;
        [Range(0f, 3f)] public float rangePadding = 0.8f;

        [Header("実ライト")]
        public Light stageSpotLight;
        public float stageBrightIntensity = 4f;
        public Color stageLightColor = new Color(1f, 0.88f, 0.68f, 1f);

        [Header("暗転Projector")]
        public BoxCollider darknessVolume;
        [Range(0f, 5f)] public float darknessBoundsPadding = 0.5f;
        public Material darknessMaterial;
        [Range(0f, 1f)] public float audienceBrightness = 0.08f;
        [Range(0.01f, 1f)] public float coneEdgeSoftness = 0.18f;

        [Header("光の筋")]
        public Transform beamTransform;
        public Material beamMaterial;
        [Range(0f, 1f)] public float beamOpacity = 0.16f;

        [Header("演出")]
        [Range(0.1f, 20f)] public float transitionDuration = 3f;
        public AudioSource startAudioSource;
        public Text statusText;

        [UdonSynced] private bool _concertMode;
        [UdonSynced] private int _transitionSequence;
        [UdonSynced] private int _transitionStartServerTime;
        [UdonSynced] private float _transitionStartFactor;

        private int _lastSequence;
        private float _currentFactor;
        private bool _transitionActive;

        private void Start()
        {
            _lastSequence = _transitionSequence;
            _currentFactor = _concertMode ? 1f : 0f;
            ApplyFactor(_currentFactor);
            UpdateStatus();
        }

        public override void Interact()
        {
            ToggleConcertLighting();
        }

        public void ToggleConcertLighting()
        {
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(localPlayer)) return;
            if (!Networking.IsOwner(gameObject)) Networking.SetOwner(localPlayer, gameObject);

            _transitionStartFactor = GetCurrentFactor();
            _concertMode = !_concertMode;
            _transitionStartServerTime = Networking.GetServerTimeInMilliseconds();
            _transitionSequence++;
            if (_transitionSequence <= 0) _transitionSequence = 1;
            RequestSerialization();
            BeginTransition(_concertMode);
        }

        public override void OnDeserialization()
        {
            if (_transitionSequence == _lastSequence) return;
            int elapsedMilliseconds = Networking.GetServerTimeInMilliseconds() - _transitionStartServerTime;
            bool playSound = _concertMode && elapsedMilliseconds >= -500 && elapsedMilliseconds <= 5000;
            BeginTransition(playSound);
        }

        private void Update()
        {
            UpdateGeometry();
            if (!_transitionActive) return;

            float duration = Mathf.Max(0.1f, transitionDuration);
            float elapsed = (Networking.GetServerTimeInMilliseconds() - _transitionStartServerTime) * 0.001f;
            float progress = Mathf.Clamp01(elapsed / duration);
            float targetFactor = _concertMode ? 1f : 0f;
            _currentFactor = Mathf.Lerp(_transitionStartFactor, targetFactor, progress);
            ApplyVisualFactor(_currentFactor);
            if (progress >= 1f)
            {
                _transitionActive = false;
                _currentFactor = targetFactor;
                ApplyVisualFactor(_currentFactor);
                UpdateStatus();
            }
        }

        private void BeginTransition(bool playSound)
        {
            _lastSequence = _transitionSequence;
            int elapsedMilliseconds = Networking.GetServerTimeInMilliseconds() - _transitionStartServerTime;
            float duration = Mathf.Max(0.1f, transitionDuration);
            float progress = Mathf.Clamp01(elapsedMilliseconds * 0.001f / duration);
            float targetFactor = _concertMode ? 1f : 0f;
            _currentFactor = Mathf.Lerp(_transitionStartFactor, targetFactor, progress);
            ApplyFactor(_currentFactor);
            _transitionActive = progress < 1f;
            if (playSound && startAudioSource != null && startAudioSource.clip != null)
                startAudioSource.Play();
            UpdateStatus();
        }

        private float GetCurrentFactor()
        {
            if (!_transitionActive) return _concertMode ? 1f : 0f;
            float duration = Mathf.Max(0.1f, transitionDuration);
            float elapsed = (Networking.GetServerTimeInMilliseconds() - _transitionStartServerTime) * 0.001f;
            float progress = Mathf.Clamp01(elapsed / duration);
            return Mathf.Lerp(_transitionStartFactor, _concertMode ? 1f : 0f, progress);
        }

        private void ApplyFactor(float factor)
        {
            UpdateGeometry();
            ApplyVisualFactor(factor);
        }

        private void ApplyVisualFactor(float factor)
        {
            float clamped = Mathf.Clamp01(factor);
            if (darknessMaterial != null)
                darknessMaterial.SetFloat("_DimFactor", Mathf.Lerp(1f, audienceBrightness, clamped));
            if (beamMaterial != null)
                beamMaterial.SetFloat("_Opacity", beamOpacity * clamped);
            if (stageSpotLight != null)
            {
                stageSpotLight.color = stageLightColor;
                stageSpotLight.intensity = Mathf.Max(0f, stageBrightIntensity * clamped);
                stageSpotLight.enabled = clamped > 0.001f;
            }
        }

        private void UpdateGeometry()
        {
            if (ceilingLightPoint == null || stageTargetPoint == null) return;
            Vector3 origin = ceilingLightPoint.position;
            Vector3 offset = stageTargetPoint.position - origin;
            float distance = offset.magnitude;
            if (distance < 0.01f) return;
            Vector3 direction = offset / distance;
            float range = Mathf.Max(0.1f, distance + rangePadding);
            float angle = Mathf.Clamp(coneAngle, 5f, 100f);
            Vector3 rotationUp = Mathf.Abs(Vector3.Dot(direction, Vector3.up)) > 0.98f
                ? Vector3.forward
                : Vector3.up;
            Quaternion coneRotation = Quaternion.LookRotation(direction, rotationUp);

            if (stageSpotLight != null)
            {
                stageSpotLight.transform.position = origin;
                stageSpotLight.transform.rotation = coneRotation;
                stageSpotLight.type = LightType.Spot;
                stageSpotLight.spotAngle = angle;
                stageSpotLight.range = range;
            }

            if (beamTransform != null)
            {
                float radius = Mathf.Tan(angle * 0.5f * Mathf.Deg2Rad) * range;
                beamTransform.position = origin;
                beamTransform.rotation = coneRotation;
                beamTransform.localScale = new Vector3(radius, radius, range);
            }

            if (darknessMaterial != null)
            {
                darknessMaterial.SetVector("_ConeOrigin", new Vector4(origin.x, origin.y, origin.z, 1f));
                darknessMaterial.SetVector("_ConeDirection",
                    new Vector4(direction.x, direction.y, direction.z, 0f));
                darknessMaterial.SetFloat("_ConeLength", range);
                darknessMaterial.SetFloat("_ConeTanHalfAngle",
                    Mathf.Tan(angle * 0.5f * Mathf.Deg2Rad));
                darknessMaterial.SetFloat("_ConeEdgeSoftness", Mathf.Max(0.01f, coneEdgeSoftness));
            }
        }

        private void UpdateStatus()
        {
            if (statusText == null) return;
            if (_transitionActive)
                statusText.text = _concertMode ? "開演照明へ移行中" : "通常照明へ復帰中";
            else
                statusText.text = _concertMode ? "開演照明" : "通常照明";
        }
    }
}
