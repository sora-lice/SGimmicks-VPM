using UdonSharp;
using UnityEngine;
using UnityEngine.UI;
using VRC.SDKBase;

namespace SGimmicks
{
    [AddComponentMenu("SGimmicks/Force Teleport Controller")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.Manual)]
    public class SGForceTeleportController : UdonSharpBehaviour
    {
        [Header("テレポート先")]
        public Transform[] destinations;
        public string[] destinationLabels;

        [Header("操作権限")]
        [Tooltip("0: 全員 / 1: インスタンスマスター / 2: 許可した表示名")]
        [Range(0, 2)] public int accessMode = 1;
        public string[] authorizedDisplayNames;

        [Header("視界ぼかし（ローカル）")]
        [Range(0.5f, 5f)] public float blurDuration = 1.6f;
        public Renderer blurOverlayRenderer;

        [Header("操作パネル")]
        [Range(1, 8)] public int playersPerPage = 8;
        [Range(1, 8)] public int destinationsPerPage = 8;
        public Text[] playerRowTexts;
        public GameObject[] playerSelectionIndicators;
        public Text[] destinationButtonTexts;
        public GameObject[] destinationSelectionIndicators;
        public Text playerPageText;
        public Text destinationPageText;
        public Text focusedPlayerText;
        public Text selectionSummaryText;
        public Text blurOptionText;
        public Text statusText;

        [UdonSynced] private int _commandSequence;
        [UdonSynced] private int _commandServerTime;
        [UdonSynced] private int _commandExecuteAtServerTime;
        [UdonSynced] private int[] _commandPlayerIds;
        [UdonSynced] private int[] _commandDestinationIndices;
        [UdonSynced] private bool _commandUseBlur;

        private VRCPlayerApi[] _displayPlayers;
        private int _displayPlayerCount;
        private int _playerPage;
        private int _destinationPage;

        private int[] _selectedPlayerIds;
        private string[] _selectedPlayerNames;
        private int[] _selectedDestinationIndices;
        private int _selectedPlayerCount;
        private int _focusedPlayerId = -1;
        private bool _useBlur = true;

        private int _lastProcessedSequence;
        private int _pendingDestinationIndex = -1;
        private int _pendingExecuteAtServerTime;
        private bool _pendingUseBlur;
        private bool _blurActive;
        private float _blurStartedAt;

        private void Start()
        {
            _selectedPlayerIds = new int[80];
            _selectedPlayerNames = new string[80];
            _selectedDestinationIndices = new int[80];
            for (int i = 0; i < _selectedDestinationIndices.Length; i++)
                _selectedDestinationIndices[i] = -1;

            _lastProcessedSequence = _commandSequence;
            if (blurOverlayRenderer != null)
                blurOverlayRenderer.gameObject.SetActive(false);
            RefreshPlayers();
            DrawDestinationPage();
            DrawAllStatus();
        }

        public override void OnPlayerJoined(VRCPlayerApi player)
        {
            SendCustomEventDelayedFrames(nameof(RefreshPlayers), 1);
        }

        public override void OnPlayerLeft(VRCPlayerApi player)
        {
            if (Utilities.IsValid(player))
            {
                int index = FindSelectedPlayerId(player.playerId);
                if (index >= 0) RemoveSelectedAt(index);
            }
            SendCustomEventDelayedFrames(nameof(RefreshPlayers), 1);
        }

        public override void OnDeserialization()
        {
            ProcessNetworkCommand();
        }

        public void RefreshPlayers()
        {
            int playerCount = VRCPlayerApi.GetPlayerCount();
            VRCPlayerApi[] allPlayers = new VRCPlayerApi[playerCount];
            VRCPlayerApi.GetPlayers(allPlayers);

            _displayPlayers = new VRCPlayerApi[playerCount];
            _displayPlayerCount = 0;
            for (int i = 0; i < allPlayers.Length; i++)
            {
                VRCPlayerApi player = allPlayers[i];
                if (!Utilities.IsValid(player)) continue;
                _displayPlayers[_displayPlayerCount] = player;
                _displayPlayerCount++;
            }

            RemoveInvalidSelections();
            int pageCount = GetPlayerPageCount();
            if (_playerPage >= pageCount) _playerPage = pageCount - 1;
            if (_playerPage < 0) _playerPage = 0;
            DrawPlayerPage();
            DrawAllStatus();
        }

        public void PreviousPlayerPage()
        {
            int pageCount = GetPlayerPageCount();
            if (pageCount <= 1) return;
            _playerPage--;
            if (_playerPage < 0) _playerPage = pageCount - 1;
            DrawPlayerPage();
        }

        public void NextPlayerPage()
        {
            int pageCount = GetPlayerPageCount();
            if (pageCount <= 1) return;
            _playerPage++;
            if (_playerPage >= pageCount) _playerPage = 0;
            DrawPlayerPage();
        }

        public void PreviousDestinationPage()
        {
            int pageCount = GetDestinationPageCount();
            if (pageCount <= 1) return;
            _destinationPage--;
            if (_destinationPage < 0) _destinationPage = pageCount - 1;
            DrawDestinationPage();
        }

        public void NextDestinationPage()
        {
            int pageCount = GetDestinationPageCount();
            if (pageCount <= 1) return;
            _destinationPage++;
            if (_destinationPage >= pageCount) _destinationPage = 0;
            DrawDestinationPage();
        }

        public void TogglePlayerSlot0() { TogglePlayerSlot(0); }
        public void TogglePlayerSlot1() { TogglePlayerSlot(1); }
        public void TogglePlayerSlot2() { TogglePlayerSlot(2); }
        public void TogglePlayerSlot3() { TogglePlayerSlot(3); }
        public void TogglePlayerSlot4() { TogglePlayerSlot(4); }
        public void TogglePlayerSlot5() { TogglePlayerSlot(5); }
        public void TogglePlayerSlot6() { TogglePlayerSlot(6); }
        public void TogglePlayerSlot7() { TogglePlayerSlot(7); }

        public void AssignDestinationSlot0() { AssignDestinationSlot(0); }
        public void AssignDestinationSlot1() { AssignDestinationSlot(1); }
        public void AssignDestinationSlot2() { AssignDestinationSlot(2); }
        public void AssignDestinationSlot3() { AssignDestinationSlot(3); }
        public void AssignDestinationSlot4() { AssignDestinationSlot(4); }
        public void AssignDestinationSlot5() { AssignDestinationSlot(5); }
        public void AssignDestinationSlot6() { AssignDestinationSlot(6); }
        public void AssignDestinationSlot7() { AssignDestinationSlot(7); }

        public void ClearSelection()
        {
            for (int i = 0; i < _selectedPlayerCount; i++)
            {
                _selectedPlayerIds[i] = 0;
                _selectedPlayerNames[i] = null;
                _selectedDestinationIndices[i] = -1;
            }
            _selectedPlayerCount = 0;
            _focusedPlayerId = -1;
            SetStatus("選択を解除しました");
            DrawPlayerPage();
            DrawDestinationPage();
            DrawAllStatus();
        }

        public void ToggleBlurOption()
        {
            _useBlur = !_useBlur;
            DrawAllStatus();
        }

        public void ExecuteTeleport()
        {
            if (!CanOperate())
            {
                SetStatus("この操作盤を実行する権限がありません");
                return;
            }

            RemoveInvalidSelections();
            if (_selectedPlayerCount <= 0)
            {
                SetStatus("プレイヤーを1人以上選択してください");
                return;
            }

            for (int i = 0; i < _selectedPlayerCount; i++)
            {
                int destinationIndex = _selectedDestinationIndices[i];
                if (!HasDestination(destinationIndex))
                {
                    SetStatus(_selectedPlayerNames[i] + " の移動先が未設定です");
                    return;
                }
            }

            _commandPlayerIds = new int[_selectedPlayerCount];
            _commandDestinationIndices = new int[_selectedPlayerCount];
            for (int i = 0; i < _selectedPlayerCount; i++)
            {
                _commandPlayerIds[i] = _selectedPlayerIds[i];
                _commandDestinationIndices[i] = _selectedDestinationIndices[i];
            }

            _commandUseBlur = _useBlur;
            _commandServerTime = Networking.GetServerTimeInMilliseconds();
            _commandExecuteAtServerTime = _commandServerTime + 1200;
            _commandSequence++;
            if (_commandSequence <= 0) _commandSequence = 1;

            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (Utilities.IsValid(localPlayer) && !Networking.IsOwner(gameObject))
                Networking.SetOwner(localPlayer, gameObject);
            RequestSerialization();
            ProcessNetworkCommand();
            SetStatus(_selectedPlayerCount + "人へ同時テレポートを送信しました");
        }

        public override void PostLateUpdate()
        {
            if (_pendingDestinationIndex >= 0 &&
                Networking.GetServerTimeInMilliseconds() - _pendingExecuteAtServerTime >= 0)
                ExecutePendingTeleport();

            if (!_blurActive || blurOverlayRenderer == null) return;
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(localPlayer)) return;

            float duration = Mathf.Max(0.1f, blurDuration);
            float fade = 1f - Mathf.Clamp01((Time.time - _blurStartedAt) / duration);
            if (fade <= 0f)
            {
                _blurActive = false;
                blurOverlayRenderer.material.SetFloat("_Fade", 0f);
                blurOverlayRenderer.gameObject.SetActive(false);
                return;
            }

            VRCPlayerApi.TrackingData head =
                localPlayer.GetTrackingData(VRCPlayerApi.TrackingDataType.Head);
            Transform overlay = blurOverlayRenderer.transform;
            overlay.position = head.position + head.rotation * Vector3.forward * 0.08f;
            overlay.rotation = head.rotation;
            blurOverlayRenderer.material.SetFloat("_Fade", fade);
        }

        private void TogglePlayerSlot(int slot)
        {
            int playerIndex = _playerPage * Mathf.Max(1, playersPerPage) + slot;
            if (playerIndex < 0 || playerIndex >= _displayPlayerCount) return;
            VRCPlayerApi player = _displayPlayers[playerIndex];
            if (!Utilities.IsValid(player)) return;

            int selectedIndex = FindSelectedPlayerId(player.playerId);
            if (selectedIndex >= 0)
            {
                if (_focusedPlayerId != player.playerId)
                {
                    _focusedPlayerId = player.playerId;
                    SetStatus(player.displayName + " の移動先を再設定できます");
                }
                else
                {
                    RemoveSelectedAt(selectedIndex);
                    SetStatus(player.displayName + " を実行対象から外しました");
                }
            }
            else
            {
                if (_selectedPlayerCount >= _selectedPlayerIds.Length)
                {
                    SetStatus("選択できる人数の上限に達しました");
                    return;
                }
                _selectedPlayerIds[_selectedPlayerCount] = player.playerId;
                _selectedPlayerNames[_selectedPlayerCount] = player.displayName;
                _selectedDestinationIndices[_selectedPlayerCount] = -1;
                _selectedPlayerCount++;
                _focusedPlayerId = player.playerId;
                SetStatus(player.displayName + " を選択しました。右側で移動先を指定してください");
            }
            DrawPlayerPage();
            DrawDestinationPage();
            DrawAllStatus();
        }

        private void AssignDestinationSlot(int slot)
        {
            int destinationIndex = _destinationPage * Mathf.Max(1, destinationsPerPage) + slot;
            if (!HasDestination(destinationIndex)) return;
            int selectedIndex = FindSelectedPlayerId(_focusedPlayerId);
            if (selectedIndex < 0)
            {
                SetStatus("先に左側で移動先を設定するプレイヤーを選択してください");
                return;
            }

            _selectedDestinationIndices[selectedIndex] = destinationIndex;
            SetStatus(_selectedPlayerNames[selectedIndex] + " → " + GetDestinationLabel(destinationIndex));
            DrawPlayerPage();
            DrawDestinationPage();
            DrawAllStatus();
        }

        private void ProcessNetworkCommand()
        {
            if (_commandSequence == 0 || _commandSequence == _lastProcessedSequence) return;
            _lastProcessedSequence = _commandSequence;

            int age = Networking.GetServerTimeInMilliseconds() - _commandServerTime;
            if (_commandServerTime != 0 && (age < -2000 || age > 12000)) return;
            if (_commandPlayerIds == null || _commandDestinationIndices == null) return;

            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(localPlayer)) return;
            int commandCount = Mathf.Min(_commandPlayerIds.Length, _commandDestinationIndices.Length);
            for (int i = 0; i < commandCount; i++)
            {
                if (_commandPlayerIds[i] != localPlayer.playerId) continue;
                int destinationIndex = _commandDestinationIndices[i];
                if (!HasDestination(destinationIndex)) return;
                _pendingDestinationIndex = destinationIndex;
                _pendingExecuteAtServerTime = _commandExecuteAtServerTime;
                _pendingUseBlur = _commandUseBlur;
                if (Networking.GetServerTimeInMilliseconds() - _pendingExecuteAtServerTime >= 0)
                    ExecutePendingTeleport();
                return;
            }
        }

        private void ExecutePendingTeleport()
        {
            int destinationIndex = _pendingDestinationIndex;
            bool useBlur = _pendingUseBlur;
            _pendingDestinationIndex = -1;
            if (!HasDestination(destinationIndex)) return;
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(localPlayer)) return;
            Transform destination = destinations[destinationIndex];
            localPlayer.TeleportTo(destination.position, destination.rotation);
            if (useBlur) StartBlur();
        }

        private void StartBlur()
        {
            if (blurOverlayRenderer == null) return;
            _blurStartedAt = Time.time;
            _blurActive = true;
            blurOverlayRenderer.gameObject.SetActive(true);
            blurOverlayRenderer.material.SetFloat("_Fade", 1f);
        }

        private bool CanOperate()
        {
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(localPlayer)) return false;
            if (accessMode == 0) return true;
            if (accessMode == 1) return localPlayer.isMaster;
            if (authorizedDisplayNames == null) return false;
            for (int i = 0; i < authorizedDisplayNames.Length; i++)
            {
                if (localPlayer.displayName == authorizedDisplayNames[i]) return true;
            }
            return false;
        }

        private void RemoveInvalidSelections()
        {
            if (_selectedPlayerIds == null) return;
            for (int i = _selectedPlayerCount - 1; i >= 0; i--)
            {
                VRCPlayerApi player = VRCPlayerApi.GetPlayerById(_selectedPlayerIds[i]);
                if (!Utilities.IsValid(player)) RemoveSelectedAt(i);
            }
        }

        private void RemoveSelectedAt(int index)
        {
            if (index < 0 || index >= _selectedPlayerCount) return;
            int removedId = _selectedPlayerIds[index];
            for (int i = index; i < _selectedPlayerCount - 1; i++)
            {
                _selectedPlayerIds[i] = _selectedPlayerIds[i + 1];
                _selectedPlayerNames[i] = _selectedPlayerNames[i + 1];
                _selectedDestinationIndices[i] = _selectedDestinationIndices[i + 1];
            }
            _selectedPlayerCount--;
            _selectedPlayerIds[_selectedPlayerCount] = 0;
            _selectedPlayerNames[_selectedPlayerCount] = null;
            _selectedDestinationIndices[_selectedPlayerCount] = -1;
            if (_focusedPlayerId == removedId) _focusedPlayerId = -1;
        }

        private int FindSelectedPlayerId(int playerId)
        {
            if (_selectedPlayerIds == null || playerId < 0) return -1;
            for (int i = 0; i < _selectedPlayerCount; i++)
            {
                if (_selectedPlayerIds[i] == playerId) return i;
            }
            return -1;
        }

        private bool HasDestination(int index)
        {
            return destinations != null && index >= 0 && index < destinations.Length &&
                   destinations[index] != null;
        }

        private string GetDestinationLabel(int index)
        {
            if (destinationLabels != null && index >= 0 && index < destinationLabels.Length &&
                destinationLabels[index] != null && destinationLabels[index] != "")
                return destinationLabels[index];
            return "移動先 " + (index + 1).ToString("00");
        }

        private int GetPlayerPageCount()
        {
            return Mathf.Max(1, Mathf.CeilToInt((float)_displayPlayerCount /
                                               Mathf.Max(1, playersPerPage)));
        }

        private int GetDestinationPageCount()
        {
            int count = destinations == null ? 0 : destinations.Length;
            return Mathf.Max(1, Mathf.CeilToInt((float)count /
                                               Mathf.Max(1, destinationsPerPage)));
        }

        private void DrawPlayerPage()
        {
            if (playerRowTexts == null || _displayPlayers == null) return;
            int countPerPage = Mathf.Max(1, playersPerPage);
            for (int slot = 0; slot < playerRowTexts.Length; slot++)
            {
                int playerIndex = _playerPage * countPerPage + slot;
                bool hasPlayer = playerIndex >= 0 && playerIndex < _displayPlayerCount &&
                                 Utilities.IsValid(_displayPlayers[playerIndex]);
                if (!hasPlayer)
                {
                    if (playerRowTexts[slot] != null) playerRowTexts[slot].text = "---";
                    if (playerSelectionIndicators != null && slot < playerSelectionIndicators.Length &&
                        playerSelectionIndicators[slot] != null)
                        playerSelectionIndicators[slot].SetActive(false);
                    continue;
                }

                VRCPlayerApi player = _displayPlayers[playerIndex];
                int selectedIndex = FindSelectedPlayerId(player.playerId);
                string suffix = "";
                if (selectedIndex >= 0)
                {
                    int destinationIndex = _selectedDestinationIndices[selectedIndex];
                    suffix = HasDestination(destinationIndex)
                        ? "  →  " + GetDestinationLabel(destinationIndex)
                        : "  →  移動先未設定";
                }
                string self = player.isLocal ? "（自分）" : "";
                string prefix = selectedIndex < 0
                    ? ""
                    : (player.playerId == _focusedPlayerId ? "▶ " : "✓ ");
                if (playerRowTexts[slot] != null)
                    playerRowTexts[slot].text = prefix + player.displayName + self + suffix;
                if (playerSelectionIndicators != null && slot < playerSelectionIndicators.Length &&
                    playerSelectionIndicators[slot] != null)
                    playerSelectionIndicators[slot].SetActive(selectedIndex >= 0);
            }
            if (playerPageText != null)
                playerPageText.text = (_playerPage + 1) + " / " + GetPlayerPageCount();
        }

        private void DrawDestinationPage()
        {
            if (destinationButtonTexts == null) return;
            int focusedIndex = FindSelectedPlayerId(_focusedPlayerId);
            int focusedDestination = focusedIndex >= 0 ? _selectedDestinationIndices[focusedIndex] : -1;
            int countPerPage = Mathf.Max(1, destinationsPerPage);
            for (int slot = 0; slot < destinationButtonTexts.Length; slot++)
            {
                int destinationIndex = _destinationPage * countPerPage + slot;
                bool available = HasDestination(destinationIndex);
                if (destinationButtonTexts[slot] != null)
                    destinationButtonTexts[slot].text = available ? GetDestinationLabel(destinationIndex) : "---";
                if (destinationSelectionIndicators != null &&
                    slot < destinationSelectionIndicators.Length &&
                    destinationSelectionIndicators[slot] != null)
                    destinationSelectionIndicators[slot].SetActive(
                        available && destinationIndex == focusedDestination);
            }
            if (destinationPageText != null)
                destinationPageText.text = (_destinationPage + 1) + " / " + GetDestinationPageCount();
        }

        private void DrawAllStatus()
        {
            int assignedCount = 0;
            for (int i = 0; i < _selectedPlayerCount; i++)
            {
                if (HasDestination(_selectedDestinationIndices[i])) assignedCount++;
            }
            if (selectionSummaryText != null)
                selectionSummaryText.text = "実行対象 " + _selectedPlayerCount + "人 ／ 移動先設定済 " +
                                            assignedCount + "人";
            if (focusedPlayerText != null)
            {
                int focusedIndex = FindSelectedPlayerId(_focusedPlayerId);
                focusedPlayerText.text = focusedIndex >= 0
                    ? "移動先を設定中：" + _selectedPlayerNames[focusedIndex]
                    : "左側でプレイヤーを選択してください";
            }
            if (blurOptionText != null)
                blurOptionText.text = _useBlur ? "ぼかし演出：ON" : "ぼかし演出：OFF";
        }

        private void SetStatus(string value)
        {
            if (statusText != null) statusText.text = value;
        }
    }
}
