using UdonSharp;
using UnityEngine;
using UnityEngine.UI;
using VRC.SDKBase;

namespace SGimmicks
{
    [AddComponentMenu("SGimmicks/Theater Light Controller")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.Manual)]
    public class SGTheaterLightController : UdonSharpBehaviour
    {
        [Header("対象ライト")]
        public Light[] targetLights;
        public float[] brightIntensities;
        [Range(0f, 1f)] public float dimmedIntensityMultiplier = 0.05f;
        [Range(0.1f, 20f)] public float transitionDuration = 3f;

        [Header("消灯時の音")]
        public AudioSource dimmingAudioSource;

        [Header("表示")]
        public Text statusText;

        [UdonSynced] private bool _isDimmed;
        [UdonSynced] private int _transitionSequence;
        [UdonSynced] private int _transitionStartServerTime;
        [UdonSynced] private float _transitionStartFactor = 1f;

        private int _lastSequence;
        private float _currentFactor = 1f;
        private bool _transitionActive;

        private void Start()
        {
            _lastSequence = _transitionSequence;
            _currentFactor = _isDimmed ? dimmedIntensityMultiplier : 1f;
            ApplyFactor(_currentFactor);
            UpdateStatus();
        }

        public override void Interact()
        {
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(localPlayer)) return;
            if (!Networking.IsOwner(gameObject)) Networking.SetOwner(localPlayer, gameObject);

            _transitionStartFactor = GetCurrentFactor();
            _isDimmed = !_isDimmed;
            _transitionStartServerTime = Networking.GetServerTimeInMilliseconds();
            _transitionSequence++;
            if (_transitionSequence <= 0) _transitionSequence = 1;
            RequestSerialization();
            BeginSyncedTransition(_isDimmed);
        }

        public override void OnDeserialization()
        {
            if (_transitionSequence == _lastSequence) return;
            int elapsedMilliseconds = Networking.GetServerTimeInMilliseconds() - _transitionStartServerTime;
            bool playSound = _isDimmed && elapsedMilliseconds >= -500 && elapsedMilliseconds <= 5000;
            BeginSyncedTransition(playSound);
        }

        private void Update()
        {
            if (!_transitionActive) return;
            float duration = Mathf.Max(0.1f, transitionDuration);
            float elapsed = (Networking.GetServerTimeInMilliseconds() -
                             _transitionStartServerTime) * 0.001f;
            float progress = Mathf.Clamp01(elapsed / duration);
            float targetFactor = _isDimmed ? dimmedIntensityMultiplier : 1f;
            _currentFactor = Mathf.Lerp(_transitionStartFactor, targetFactor, progress);
            ApplyFactor(_currentFactor);
            if (progress >= 1f)
            {
                _transitionActive = false;
                _currentFactor = targetFactor;
                ApplyFactor(_currentFactor);
                UpdateStatus();
            }
        }

        private void BeginSyncedTransition(bool playSound)
        {
            _lastSequence = _transitionSequence;
            int elapsedMilliseconds = Networking.GetServerTimeInMilliseconds() - _transitionStartServerTime;
            float duration = Mathf.Max(0.1f, transitionDuration);
            float progress = Mathf.Clamp01(elapsedMilliseconds * 0.001f / duration);
            float targetFactor = _isDimmed ? dimmedIntensityMultiplier : 1f;
            _currentFactor = Mathf.Lerp(_transitionStartFactor, targetFactor, progress);
            ApplyFactor(_currentFactor);
            _transitionActive = progress < 1f;
            if (playSound && dimmingAudioSource != null && dimmingAudioSource.clip != null)
                dimmingAudioSource.Play();
            UpdateStatus();
        }

        private float GetCurrentFactor()
        {
            if (!_transitionActive) return _isDimmed ? dimmedIntensityMultiplier : 1f;
            float duration = Mathf.Max(0.1f, transitionDuration);
            float elapsed = (Networking.GetServerTimeInMilliseconds() -
                             _transitionStartServerTime) * 0.001f;
            float progress = Mathf.Clamp01(elapsed / duration);
            float targetFactor = _isDimmed ? dimmedIntensityMultiplier : 1f;
            return Mathf.Lerp(_transitionStartFactor, targetFactor, progress);
        }

        private void ApplyFactor(float factor)
        {
            if (targetLights == null) return;
            for (int i = 0; i < targetLights.Length; i++)
            {
                Light target = targetLights[i];
                if (target == null) continue;
                float bright = brightIntensities != null && i < brightIntensities.Length
                    ? brightIntensities[i]
                    : target.intensity;
                target.intensity = Mathf.Max(0f, bright * factor);
            }
        }

        private void UpdateStatus()
        {
            if (statusText == null) return;
            if (_transitionActive)
                statusText.text = _isDimmed ? "上映照明へ移行中" : "通常照明へ復帰中";
            else
                statusText.text = _isDimmed ? "上映照明" : "通常照明";
        }
    }
}
