using UdonSharp;
using UnityEngine;
using UnityEngine.UI;
using VRC.SDKBase;
using VRC.Udon.Common;

namespace SGimmicks
{
    [AddComponentMenu("SGimmicks/Intercom Controller")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class SGIntercomController : UdonSharpBehaviour
    {
        [Header("同期スロット")]
        public SGIntercomSlot[] slots;

        [Header("右トリガー")]
        [Range(0.2f, 0.8f)] public float doubleTapWindow = 0.45f;

        [Header("内線音声距離")]
        public float intercomVoiceNear = 1000000f;
        public float intercomVoiceFar = 1000000f;
        public float isolatedVoiceNear = 0f;
        public float isolatedVoiceFar = 0f;
        public float normalVoiceNear = 0f;
        public float normalVoiceFar = 25f;

        [Header("操作パネル")]
        public Text membershipButtonText;
        public Text participantCountText;
        public Text statusText;
        public GameObject transmitIndicator;

        private SGIntercomSlot _localSlot;
        private bool _localJoined;
        private bool _intercomConnected;
        private bool _rightTriggerHeld;
        private float _lastUnconnectedTriggerDown = -10f;

        private void Start()
        {
            RefreshVoiceRouting();
            SendCustomEventDelayedSeconds(nameof(Maintenance), 2f);
        }

        private void OnDisable()
        {
            RestoreAllVoices();
        }

        public override void OnPlayerJoined(VRCPlayerApi player)
        {
            SendCustomEventDelayedFrames(nameof(RefreshVoiceRouting), 2);
        }

        public override void OnPlayerLeft(VRCPlayerApi player)
        {
            SendCustomEventDelayedFrames(nameof(Maintenance), 2);
        }

        public override void InputUse(bool value, UdonInputEventArgs args)
        {
            if (args.handType != HandType.RIGHT) return;
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(localPlayer) || !localPlayer.IsUserInVR()) return;

            _rightTriggerHeld = value;
            if (!_localJoined || _localSlot == null) return;

            if (value)
            {
                if (!_intercomConnected)
                {
                    float now = Time.time;
                    if (now - _lastUnconnectedTriggerDown <= doubleTapWindow)
                    {
                        _intercomConnected = true;
                        _lastUnconnectedTriggerDown = -10f;
                        _localSlot.SetLocalTransmitting(true);
                        SetStatus("内線接続中・送話中");
                    }
                    else
                    {
                        _lastUnconnectedTriggerDown = now;
                        SetStatus("もう一度右トリガーを押すと内線へ接続します");
                    }
                }
                else
                {
                    _localSlot.SetLocalTransmitting(true);
                    SetStatus("送話中：参加者だけに聞こえています");
                }
            }
            else if (_intercomConnected)
            {
                _localSlot.SetLocalTransmitting(false);
                SetStatus("内線接続中：右トリガー長押しで送話");
            }
            UpdatePanel();
        }

        public void ToggleParticipation()
        {
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            if (!Utilities.IsValid(localPlayer)) return;
            if (!localPlayer.IsUserInVR())
            {
                SetStatus("この内線はPCVR専用です");
                return;
            }

            FindLocalSlot();
            if (_localJoined && _localSlot != null)
            {
                _localSlot.SetLocalTransmitting(false);
                _localSlot.LeaveLocalPlayer();
                _localJoined = false;
                _intercomConnected = false;
                _rightTriggerHeld = false;
                _localSlot = null;
                SetStatus("内線から退出しました");
                RefreshVoiceRouting();
                return;
            }

            SGIntercomSlot freeSlot = FindAvailableSlot();
            if (freeSlot == null)
            {
                SetStatus("内線の参加枠が満員です");
                return;
            }

            Networking.SetOwner(localPlayer, freeSlot.gameObject);
            freeSlot.ClaimForLocalPlayer();
            _localSlot = freeSlot;
            _localJoined = true;
            _intercomConnected = false;
            _rightTriggerHeld = false;
            _lastUnconnectedTriggerDown = -10f;
            SetStatus("参加しました。右トリガーを素早く2回押してください");
            RefreshVoiceRouting();
        }

        public void RefreshVoiceRouting()
        {
            FindLocalSlot();
            int participantCount = 0;
            if (slots != null)
            {
                for (int i = 0; i < slots.Length; i++)
                {
                    SGIntercomSlot slot = slots[i];
                    if (slot == null || !slot.joined) continue;
                    VRCPlayerApi speaker = VRCPlayerApi.GetPlayerById(slot.playerId);
                    if (!Utilities.IsValid(speaker)) continue;
                    participantCount++;
                    if (speaker.isLocal) continue;

                    if (slot.transmitting)
                    {
                        if (_localJoined)
                            ApplyVoiceDistance(speaker, intercomVoiceNear, intercomVoiceFar);
                        else
                            ApplyVoiceDistance(speaker, isolatedVoiceNear, isolatedVoiceFar);
                    }
                    else
                    {
                        ApplyVoiceDistance(speaker, normalVoiceNear, normalVoiceFar);
                    }
                }
            }
            if (participantCountText != null)
                participantCountText.text = "参加者：" + participantCount + "人";
            UpdatePanel();
        }

        public void Maintenance()
        {
            if (slots != null)
            {
                for (int i = 0; i < slots.Length; i++)
                {
                    if (slots[i] != null) slots[i].ClearIfOwnedAndInvalid();
                }
            }
            RefreshVoiceRouting();
            SendCustomEventDelayedSeconds(nameof(Maintenance), 2f);
        }

        private void FindLocalSlot()
        {
            VRCPlayerApi localPlayer = Networking.LocalPlayer;
            _localSlot = null;
            _localJoined = false;
            if (!Utilities.IsValid(localPlayer) || slots == null) return;
            for (int i = 0; i < slots.Length; i++)
            {
                SGIntercomSlot slot = slots[i];
                if (slot == null || !slot.joined || slot.playerId != localPlayer.playerId) continue;
                _localSlot = slot;
                _localJoined = true;
                return;
            }
        }

        private SGIntercomSlot FindAvailableSlot()
        {
            if (slots == null) return null;
            for (int i = 0; i < slots.Length; i++)
            {
                SGIntercomSlot slot = slots[i];
                if (slot == null) continue;
                VRCPlayerApi occupant = VRCPlayerApi.GetPlayerById(slot.playerId);
                if (!slot.joined || !Utilities.IsValid(occupant)) return slot;
            }
            return null;
        }

        private void ApplyVoiceDistance(VRCPlayerApi player, float nearDistance, float farDistance)
        {
            if (!Utilities.IsValid(player) || player.isLocal) return;
            player.SetVoiceDistanceNear(nearDistance);
            player.SetVoiceDistanceFar(farDistance);
        }

        private void RestoreAllVoices()
        {
            if (slots == null) return;
            for (int i = 0; i < slots.Length; i++)
            {
                SGIntercomSlot slot = slots[i];
                if (slot == null) continue;
                VRCPlayerApi player = VRCPlayerApi.GetPlayerById(slot.playerId);
                ApplyVoiceDistance(player, normalVoiceNear, normalVoiceFar);
            }
        }

        private void UpdatePanel()
        {
            if (membershipButtonText != null)
                membershipButtonText.text = _localJoined ? "内線から退出" : "内線に参加";
            if (transmitIndicator != null)
                transmitIndicator.SetActive(_localJoined && _intercomConnected && _rightTriggerHeld);
        }

        private void SetStatus(string value)
        {
            if (statusText != null) statusText.text = value;
        }
    }
}
