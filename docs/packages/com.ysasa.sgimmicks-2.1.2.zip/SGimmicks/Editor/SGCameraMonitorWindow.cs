using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace SGimmicks.Editor
{
    public class SGCameraMonitorWindow : EditorWindow
    {
        private SGSurveillanceController[] _controllers = new SGSurveillanceController[0];
        private string[] _controllerNames = new string[0];
        private int _controllerIndex;
        private int _cameraIndex;
        private RenderTexture _previewTexture;
        private double _nextRefresh;

        [MenuItem("SGimmicks/監視カメラモニター", priority = 2)]
        public static void Open()
        {
            SGCameraMonitorWindow window = GetWindow<SGCameraMonitorWindow>();
            window.titleContent = new GUIContent("SG 監視モニター");
            window.minSize = new Vector2(480f, 360f);
            window.Show();
        }

        private void OnEnable()
        {
            RefreshControllerList();
            EditorApplication.update += EditorUpdate;
        }

        private void OnDisable()
        {
            EditorApplication.update -= EditorUpdate;
            ReleasePreviewTexture();
        }

        private void EditorUpdate()
        {
            if (EditorApplication.timeSinceStartup < _nextRefresh) return;
            _nextRefresh = EditorApplication.timeSinceStartup + 0.1d;
            Repaint();
        }

        private void OnGUI()
        {
            EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
            if (GUILayout.Button("更新", EditorStyles.toolbarButton, GUILayout.Width(65f)))
                RefreshControllerList();
            GUILayout.FlexibleSpace();
            EditorGUILayout.LabelField("このウィンドウを開いている間だけプレビューします", EditorStyles.miniLabel,
                GUILayout.Width(260f));
            EditorGUILayout.EndHorizontal();

            if (_controllers.Length == 0)
            {
                EditorGUILayout.HelpBox("開いているSceneに監視カメラシステムがありません。", MessageType.Info);
                if (GUILayout.Button("ギミック設定を開く")) SGimmicksWindow.Open();
                return;
            }

            _controllerIndex = Mathf.Clamp(_controllerIndex, 0, _controllers.Length - 1);
            _controllerIndex = EditorGUILayout.Popup("システム", _controllerIndex, _controllerNames);
            SGSurveillanceController controller = _controllers[_controllerIndex];
            Camera[] cameras = controller == null ? null : controller.surveillanceCameras;
            if (cameras == null || cameras.Length == 0)
            {
                EditorGUILayout.HelpBox("このシステムにはカメラが登録されていません。", MessageType.Warning);
                return;
            }

            string[] cameraNames = BuildCameraNames(controller, cameras);
            _cameraIndex = Mathf.Clamp(_cameraIndex, 0, cameras.Length - 1);
            _cameraIndex = EditorGUILayout.Popup("カメラ", _cameraIndex, cameraNames);
            Camera selectedCamera = cameras[_cameraIndex];

            EditorGUILayout.BeginHorizontal();
            EditorGUI.BeginDisabledGroup(selectedCamera == null);
            if (GUILayout.Button("カメラを選択")) Selection.activeGameObject = selectedCamera.gameObject;
            if (GUILayout.Button("Sceneビューを合わせる")) AlignSceneView(selectedCamera);
            EditorGUI.EndDisabledGroup();
            EditorGUILayout.EndHorizontal();

            Rect previewRect = GUILayoutUtility.GetAspectRect(16f / 9f, GUILayout.ExpandWidth(true));
            EditorGUI.DrawRect(previewRect, Color.black);
            if (selectedCamera == null)
            {
                GUI.Label(previewRect, "カメラが見つかりません", CenteredLabelStyle());
                return;
            }

            if (Event.current.type == EventType.Repaint)
            {
                RenderCameraPreview(selectedCamera, Mathf.RoundToInt(previewRect.width),
                    Mathf.RoundToInt(previewRect.height));
            }
            if (_previewTexture != null)
            {
                GUI.DrawTexture(previewRect, _previewTexture, ScaleMode.ScaleToFit, false);
            }
        }

        private void RefreshControllerList()
        {
            SGSurveillanceController[] found = Resources.FindObjectsOfTypeAll<SGSurveillanceController>();
            List<SGSurveillanceController> valid = new List<SGSurveillanceController>();
            foreach (SGSurveillanceController controller in found)
            {
                if (controller == null || !controller.gameObject.scene.IsValid()) continue;
                if ((controller.hideFlags & HideFlags.HideAndDontSave) != 0) continue;
                valid.Add(controller);
            }
            _controllers = valid.ToArray();
            _controllerNames = new string[_controllers.Length];
            for (int i = 0; i < _controllers.Length; i++)
                _controllerNames[i] = _controllers[i].gameObject.name;
            _controllerIndex = Mathf.Clamp(_controllerIndex, 0, Mathf.Max(0, _controllers.Length - 1));
            _cameraIndex = 0;
        }

        private static string[] BuildCameraNames(SGSurveillanceController controller, Camera[] cameras)
        {
            string[] names = new string[cameras.Length];
            for (int i = 0; i < cameras.Length; i++)
            {
                names[i] = cameras[i] == null ? "未設定カメラ " + (i + 1) : cameras[i].name;
                if (controller.cameraLabels != null && i < controller.cameraLabels.Length &&
                    !string.IsNullOrWhiteSpace(controller.cameraLabels[i]))
                    names[i] = controller.cameraLabels[i];
            }
            return names;
        }

        private void RenderCameraPreview(Camera cameraComponent, int width, int height)
        {
            width = Mathf.Clamp(width, 160, 1920);
            height = Mathf.Clamp(height, 90, 1080);
            if (_previewTexture == null || _previewTexture.width != width || _previewTexture.height != height)
            {
                ReleasePreviewTexture();
                _previewTexture = new RenderTexture(width, height, 16, RenderTextureFormat.ARGB32)
                {
                    name = "SGimmicks Editor Camera Preview",
                    hideFlags = HideFlags.HideAndDontSave
                };
                _previewTexture.Create();
            }

            RenderTexture previousTarget = cameraComponent.targetTexture;
            bool previousEnabled = cameraComponent.enabled;
            try
            {
                cameraComponent.enabled = false;
                cameraComponent.targetTexture = _previewTexture;
                cameraComponent.Render();
            }
            finally
            {
                cameraComponent.targetTexture = previousTarget;
                cameraComponent.enabled = previousEnabled;
            }
        }

        private void ReleasePreviewTexture()
        {
            if (_previewTexture == null) return;
            _previewTexture.Release();
            DestroyImmediate(_previewTexture);
            _previewTexture = null;
        }

        private static void AlignSceneView(Camera cameraComponent)
        {
            if (cameraComponent == null || SceneView.lastActiveSceneView == null) return;
            SceneView view = SceneView.lastActiveSceneView;
            view.AlignViewToObject(cameraComponent.transform);
            view.Repaint();
        }

        private static GUIStyle CenteredLabelStyle()
        {
            GUIStyle style = new GUIStyle(EditorStyles.boldLabel)
            {
                alignment = TextAnchor.MiddleCenter,
                normal = { textColor = Color.white }
            };
            return style;
        }
    }
}
