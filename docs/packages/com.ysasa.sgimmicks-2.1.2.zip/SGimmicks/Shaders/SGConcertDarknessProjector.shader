Shader "SGimmicks/ConcertDarknessProjector"
{
    Properties
    {
        _DimFactor ("Audience Brightness", Range(0,1)) = 1
        _ConeOrigin ("Cone Origin", Vector) = (0,5,0,1)
        _ConeDirection ("Cone Direction", Vector) = (0,-1,0,0)
        _ConeLength ("Cone Length", Float) = 6
        _ConeTanHalfAngle ("Cone Tan Half Angle", Float) = 0.35
        _ConeEdgeSoftness ("Cone Edge Softness", Range(0.01,1)) = 0.18
        _VolumeCenter ("Volume Center", Vector) = (0,2.5,4,1)
        _VolumeAxisX ("Volume Axis X", Vector) = (1,0,0,0)
        _VolumeAxisY ("Volume Axis Y", Vector) = (0,1,0,0)
        _VolumeAxisZ ("Volume Axis Z", Vector) = (0,0,1,0)
        _VolumeHalfSize ("Volume Half Size", Vector) = (6.5,3,6.5,0)
    }

    SubShader
    {
        Tags { "Queue"="Overlay-100" "IgnoreProjector"="True" }
        Pass
        {
            ZWrite Off
            ZTest LEqual
            Cull Off
            ColorMask RGB
            Blend DstColor Zero
            Offset -1, -1

            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma target 3.0
            #include "UnityCG.cginc"

            float _DimFactor;
            float4 _ConeOrigin;
            float4 _ConeDirection;
            float _ConeLength;
            float _ConeTanHalfAngle;
            float _ConeEdgeSoftness;
            float4 _VolumeCenter;
            float4 _VolumeAxisX;
            float4 _VolumeAxisY;
            float4 _VolumeAxisZ;
            float4 _VolumeHalfSize;

            struct appdata
            {
                float4 vertex : POSITION;
            };

            struct v2f
            {
                float4 position : SV_POSITION;
                float3 worldPosition : TEXCOORD0;
            };

            v2f vert(appdata input)
            {
                v2f output;
                output.position = UnityObjectToClipPos(input.vertex);
                output.worldPosition = mul(unity_ObjectToWorld, input.vertex).xyz;
                return output;
            }

            fixed4 frag(v2f input) : SV_Target
            {
                // Projector UV/depth varies with the graphics API and can clip the
                // room edges. Test the fragment only against the configured oriented
                // BoxCollider, so every pixel inside it is covered consistently.
                float3 fromVolumeCenter = input.worldPosition - _VolumeCenter.xyz;
                float3 volumeDistance = abs(float3(
                    dot(fromVolumeCenter, normalize(_VolumeAxisX.xyz)),
                    dot(fromVolumeCenter, normalize(_VolumeAxisY.xyz)),
                    dot(fromVolumeCenter, normalize(_VolumeAxisZ.xyz))));
                float3 volumeRemaining = _VolumeHalfSize.xyz - volumeDistance;
                clip(min(volumeRemaining.x, min(volumeRemaining.y, volumeRemaining.z)));

                float3 coneDirection = normalize(_ConeDirection.xyz);
                float3 fromOrigin = input.worldPosition - _ConeOrigin.xyz;
                float axialDistance = dot(fromOrigin, coneDirection);
                float3 radialVector = fromOrigin - coneDirection * axialDistance;
                float radialDistance = length(radialVector);
                float coneRadius = max(0.001, axialDistance * _ConeTanHalfAngle);
                float edgeWidth = max(0.01, coneRadius * _ConeEdgeSoftness);
                float insideRadial = 1.0 - smoothstep(coneRadius - edgeWidth, coneRadius, radialDistance);
                float insideLength = step(0.0, axialDistance) * step(axialDistance, _ConeLength);
                float coneMask = insideRadial * insideLength;
                float multiplier = lerp(saturate(_DimFactor), 1.0, coneMask);
                return fixed4(multiplier, multiplier, multiplier, 1.0);
            }
            ENDCG
        }
    }
}
