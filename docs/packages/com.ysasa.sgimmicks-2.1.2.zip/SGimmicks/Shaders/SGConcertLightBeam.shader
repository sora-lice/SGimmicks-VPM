Shader "SGimmicks/ConcertLightBeam"
{
    Properties
    {
        [HDR] _Color ("Beam Color", Color) = (1.0,0.82,0.58,1.0)
        _Opacity ("Opacity", Range(0,1)) = 0
        _EdgePower ("Edge Power", Range(0.25,8)) = 2
    }

    SubShader
    {
        Tags { "Queue"="Transparent+20" "RenderType"="Transparent" "IgnoreProjector"="True" }
        Pass
        {
            Blend SrcAlpha One
            ZWrite Off
            Cull Off

            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma target 3.0
            #include "UnityCG.cginc"

            fixed4 _Color;
            float _Opacity;
            float _EdgePower;

            struct appdata
            {
                float4 vertex : POSITION;
                float3 normal : NORMAL;
                float2 uv : TEXCOORD0;
            };

            struct v2f
            {
                float4 position : SV_POSITION;
                float3 worldNormal : TEXCOORD0;
                float3 viewDirection : TEXCOORD1;
                float2 uv : TEXCOORD2;
            };

            v2f vert(appdata input)
            {
                v2f output;
                output.position = UnityObjectToClipPos(input.vertex);
                float3 worldPosition = mul(unity_ObjectToWorld, input.vertex).xyz;
                output.worldNormal = UnityObjectToWorldNormal(input.normal);
                output.viewDirection = _WorldSpaceCameraPos.xyz - worldPosition;
                output.uv = input.uv;
                return output;
            }

            fixed4 frag(v2f input) : SV_Target
            {
                float3 normal = normalize(input.worldNormal);
                float3 viewDirection = normalize(input.viewDirection);
                float rim = pow(saturate(1.0 - abs(dot(normal, viewDirection))), _EdgePower);
                float lengthFade = smoothstep(0.0, 0.12, input.uv.y) *
                                   (1.0 - smoothstep(0.82, 1.0, input.uv.y));
                float alpha = saturate(_Opacity * (0.25 + rim * 0.75) * lengthFade);
                return fixed4(_Color.rgb, alpha);
            }
            ENDCG
        }
    }
}
