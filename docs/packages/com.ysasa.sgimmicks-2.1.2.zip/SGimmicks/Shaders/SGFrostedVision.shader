Shader "SGimmicks/FrostedVision"
{
    Properties
    {
        _BlurSize ("Blur Size", Range(0, 10)) = 5
        _Fade ("Fade", Range(0, 1)) = 0
        _Tint ("Tint", Color) = (0.72, 0.84, 0.95, 0.16)
    }

    SubShader
    {
        Tags { "Queue"="Overlay+100" "RenderType"="Transparent" "IgnoreProjector"="True" }
        GrabPass { "_SGForceTeleportGrab" }

        Pass
        {
            ZTest Always
            ZWrite Off
            Cull Off
            Blend SrcAlpha OneMinusSrcAlpha

            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "UnityCG.cginc"

            struct appdata
            {
                float4 vertex : POSITION;
            };

            struct v2f
            {
                float4 vertex : SV_POSITION;
                float4 grabPos : TEXCOORD0;
            };

            sampler2D _SGForceTeleportGrab;
            float4 _SGForceTeleportGrab_TexelSize;
            float _BlurSize;
            float _Fade;
            float4 _Tint;

            v2f vert(appdata value)
            {
                v2f output;
                output.vertex = UnityObjectToClipPos(value.vertex);
                output.grabPos = ComputeGrabScreenPos(output.vertex);
                return output;
            }

            fixed4 SampleGrab(float4 grabPos, float2 direction)
            {
                grabPos.xy += direction * _SGForceTeleportGrab_TexelSize.xy * _BlurSize * grabPos.w;
                return tex2Dproj(_SGForceTeleportGrab, UNITY_PROJ_COORD(grabPos));
            }

            fixed4 frag(v2f input) : SV_Target
            {
                fixed4 color = SampleGrab(input.grabPos, float2(-1, -1));
                color += SampleGrab(input.grabPos, float2(0, -1)) * 2;
                color += SampleGrab(input.grabPos, float2(1, -1));
                color += SampleGrab(input.grabPos, float2(-1, 0)) * 2;
                color += SampleGrab(input.grabPos, float2(0, 0)) * 4;
                color += SampleGrab(input.grabPos, float2(1, 0)) * 2;
                color += SampleGrab(input.grabPos, float2(-1, 1));
                color += SampleGrab(input.grabPos, float2(0, 1)) * 2;
                color += SampleGrab(input.grabPos, float2(1, 1));
                color *= 0.0625;
                color.rgb = lerp(color.rgb, _Tint.rgb, _Tint.a);
                color.a = saturate(_Fade);
                return color;
            }
            ENDCG
        }
    }
}
