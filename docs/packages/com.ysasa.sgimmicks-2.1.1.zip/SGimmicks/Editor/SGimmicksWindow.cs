using System.Collections.Generic;
using CastTimerGimmick;
using TMPro;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace SGimmicks.Editor
{
    public class SGimmicksWindow : EditorWindow
    {
        private static readonly string[] Tabs =
            { "テレポート", "VIPスポーン", "監視カメラ", "部屋番号／RTab", "強制テレポート", "内線", "映画館照明", "コンサート照明", "キャストタイマー", "お題表示", "囁き声判定" };

        [SerializeField] private int _selectedTab;
        [SerializeField] private Vector2 _scroll;

        [SerializeField] private GameObject _teleportUseObject;
        [SerializeField] private Transform _teleportDestination;
        [SerializeField] private string _teleportPrompt = "テレポート";
        [SerializeField] private float _teleportProximity = 2f;

        [SerializeField] private SGVipSpawnController _vipController;
        [SerializeField] private Transform _vipSpawnPoint;
        [SerializeField] private List<string> _vipDisplayNames = new List<string> { "表示名" };
        [SerializeField] private bool _vipOnRespawn = true;

        [SerializeField] private SGSurveillanceController _surveillanceController;
        [SerializeField] private Renderer _monitorRenderer;
        [SerializeField] private List<Camera> _surveillanceCameras = new List<Camera>();
        [SerializeField] private List<string> _cameraLabels = new List<string>();
        [SerializeField] private int _operationPanelFontSize = 40;

        [SerializeField] private SGRoomTeleportController _roomTeleportController;
        [SerializeField] private Transform _rtabAppsRoot;
        [SerializeField] private List<string> _roomCodes = new List<string> { "0001" };
        [SerializeField] private List<Transform> _roomDestinations = new List<Transform> { null };
        [SerializeField] private GameObject _globalToggleObject;
        [SerializeField] private string _globalShowCode = "9001";
        [SerializeField] private string _globalHideCode = "9000";
        [SerializeField] private bool _globalObjectInitiallyVisible = true;

        [SerializeField] private SGForceTeleportController _forceTeleportController;
        [SerializeField] private List<Transform> _forceDestinations = new List<Transform> { null };
        [SerializeField] private List<string> _forceDestinationLabels = new List<string> { "移動先 01" };
        [SerializeField] private int _forceAccessMode = 1;
        [SerializeField] private List<string> _forceAuthorizedDisplayNames = new List<string>();
        [SerializeField] private float _forceBlurDuration = 1.6f;

        [SerializeField] private SGIntercomController _intercomController;
        [SerializeField] private int _intercomSlotCount = 80;
        [SerializeField] private float _intercomDoubleTapWindow = 0.45f;

        [SerializeField] private SGTheaterLightController _theaterLightController;
        [SerializeField] private GameObject _theaterLightBoard;
        [SerializeField] private List<Light> _theaterLights = new List<Light> { null };
        [SerializeField] private float _theaterDimmedMultiplier = 0.05f;
        [SerializeField] private float _theaterTransitionDuration = 3f;
        [SerializeField] private AudioClip _theaterDimmingClip;
        [SerializeField] private float _theaterAudioVolume = 1f;
        [SerializeField] private float _theaterAudioMaxDistance = 20f;

        [SerializeField] private SGConcertLightingController _concertLightingController;
        [SerializeField] private GameObject _concertLightingBoard;
        [SerializeField] private Transform _concertCeilingPoint;
        [SerializeField] private Transform _concertStageTarget;
        [SerializeField] private BoxCollider _concertDarknessVolume;
        [SerializeField] private float _concertDarknessBoundsPadding = 0.5f;
        [SerializeField] private float _concertConeAngle = 38f;
        [SerializeField] private float _concertAudienceBrightness = 0.08f;
        [SerializeField] private float _concertEdgeSoftness = 0.18f;
        [SerializeField] private float _concertTransitionDuration = 3f;
        [SerializeField] private Color _concertLightColor = new Color(1f, 0.88f, 0.68f, 1f);
        [SerializeField] private float _concertLightIntensity = 4f;
        [SerializeField] private float _concertBeamOpacity = 0.16f;
        [SerializeField] private AudioClip _concertStartClip;
        [SerializeField] private float _concertAudioVolume = 1f;
        [SerializeField] private float _concertAudioMaxDistance = 25f;
        private bool _concertAutoLoadAttempted;

        [SerializeField] private CastTimerManager _castTimerManager;

        [SerializeField] private SGMessageBoardController _messageBoardController;
        [SerializeField] private GameObject _messageBoardUseObject;
        [SerializeField] private List<TMP_Text> _messageBoardOutputs = new List<TMP_Text> { null };
        [SerializeField] private float _messageBoardFontSize = 52f;
        [SerializeField] private AudioClip _messageBoardSubmitClip;
        [SerializeField] private float _messageBoardAudioVolume = 1f;
        [SerializeField] private float _messageBoardAudioMaxDistance = 25f;

        [SerializeField] private SGWhisperAudienceManager _whisperAudienceManager;
        [SerializeField] private int _whisperSeatCount = 8;
        [SerializeField] private float _whisperDefaultThreshold = 0.65f;
        [SerializeField] private float _whisperHoldDuration = 0.25f;
        [SerializeField] private float _whisperFixedEyeHeight = 1.45f;
        [SerializeField] private List<string> _whisperCastDisplayNames = new List<string>();
        [SerializeField] private List<string> _whisperOperatorDisplayNames = new List<string>();

        [MenuItem("SGimmicks/ギミック設定", priority = 1)]
        public static void Open()
        {
            SGimmicksWindow window = GetWindow<SGimmicksWindow>();
            window.titleContent = new GUIContent("SGimmicks 設定");
            window.minSize = new Vector2(680f, 560f);
            window.Show();
        }

        [MenuItem("SGimmicks/RTab部屋番号アプリを設定", priority = 4)]
        public static void OpenRoomTeleport()
        {
            SGimmicksWindow window = GetWindow<SGimmicksWindow>();
            window.titleContent = new GUIContent("SGimmicks 設定");
            window.minSize = new Vector2(680f, 560f);
            window._selectedTab = 3;
            window.Show();
        }

        [MenuItem("SGimmicks/強制テレポートを設定", priority = 6)]
        public static void OpenForceTeleport()
        {
            SGimmicksWindow window = GetWindow<SGimmicksWindow>();
            window.titleContent = new GUIContent("SGimmicks 設定");
            window.minSize = new Vector2(680f, 560f);
            window._selectedTab = 4;
            window.Show();
        }

        [MenuItem("SGimmicks/内線を設定", priority = 7)]
        public static void OpenIntercom()
        {
            SGimmicksWindow window = GetWindow<SGimmicksWindow>();
            window.titleContent = new GUIContent("SGimmicks 設定");
            window.minSize = new Vector2(680f, 560f);
            window._selectedTab = 5;
            window.Show();
        }

        [MenuItem("SGimmicks/映画館照明を設定", priority = 8)]
        public static void OpenTheaterLights()
        {
            SGimmicksWindow window = GetWindow<SGimmicksWindow>();
            window.titleContent = new GUIContent("SGimmicks 設定");
            window.minSize = new Vector2(800f, 560f);
            window._selectedTab = 6;
            window.Show();
        }

        [MenuItem("SGimmicks/お題・メッセージ表示を設定", priority = 9)]
        public static void OpenMessageBoard()
        {
            SGimmicksWindow window = GetWindow<SGimmicksWindow>();
            window.titleContent = new GUIContent("SGimmicks 設定");
            window.minSize = new Vector2(860f, 600f);
            window._selectedTab = 9;
            window.Show();
        }

        [MenuItem("SGimmicks/コンサート照明を設定", priority = 9)]
        public static void OpenConcertLighting()
        {
            SGimmicksWindow window = GetWindow<SGimmicksWindow>();
            window.titleContent = new GUIContent("SGimmicks 設定");
            window.minSize = new Vector2(900f, 620f);
            window._selectedTab = 7;
            window._concertAutoLoadAttempted = false;
            window.Show();
        }

        [MenuItem("SGimmicks/キャストタイマーを配置", priority = 10)]
        public static void OpenCastTimer()
        {
            SGimmicksWindow window = GetWindow<SGimmicksWindow>();
            window.titleContent = new GUIContent("SGimmicks 設定");
            window.minSize = new Vector2(780f, 580f);
            window._selectedTab = 8;
            window.Show();
        }

        [MenuItem("SGimmicks/囁き声判定を設定", priority = 11)]
        public static void OpenWhisperAudience()
        {
            SGimmicksWindow window = GetWindow<SGimmicksWindow>();
            window.titleContent = new GUIContent("SGimmicks 設定");
            window.minSize = new Vector2(900f, 620f);
            window._selectedTab = 10;
            window.Show();
        }

        [MenuItem("SGimmicks/RTab部屋番号アプリを修復", priority = 5)]
        public static void RepairRoomTeleportApps()
        {
            SGRoomTeleportController[] controllers =
                Resources.FindObjectsOfTypeAll<SGRoomTeleportController>();
            int repairedCount = 0;
            int skippedCount = 0;
            foreach (SGRoomTeleportController controller in controllers)
            {
                if (controller == null || EditorUtility.IsPersistent(controller) ||
                    !controller.gameObject.scene.IsValid())
                {
                    continue;
                }

                if (controller.roomCodes == null || controller.roomDestinations == null ||
                    controller.roomCodes.Length == 0 ||
                    controller.roomCodes.Length != controller.roomDestinations.Length)
                {
                    skippedCount++;
                    continue;
                }

                try
                {
                    Transform appsRoot = controller.transform.parent;
                    if (appsRoot == null || appsRoot.name != "Apps")
                        appsRoot = SGEditorFactory.FindRTabAppsRoot();
                    SGEditorFactory.ConfigureRoomTeleportRTab(appsRoot, controller,
                        controller.roomCodes, controller.roomDestinations);
                    repairedCount++;
                }
                catch (System.Exception exception)
                {
                    skippedCount++;
                    Debug.LogException(exception);
                }
            }

            EditorUtility.DisplayDialog("SGimmicks",
                repairedCount > 0
                    ? repairedCount + "個のRTab部屋番号アプリを修復しました。Sceneを保存してから再アップロードしてください。" +
                      (skippedCount > 0 ? "\n修復できなかったアプリ: " + skippedCount + "個" : "")
                    : "修復できるRTab部屋番号アプリが現在のSceneに見つかりませんでした。",
                "OK");
        }

        [MenuItem("SGimmicks/既存操作パネルを更新", priority = 2)]
        public static void RefreshExistingOperationPanels()
        {
            SGSurveillanceController[] controllers =
                Resources.FindObjectsOfTypeAll<SGSurveillanceController>();
            int updatedCount = 0;
            foreach (SGSurveillanceController controller in controllers)
            {
                if (controller == null || EditorUtility.IsPersistent(controller) ||
                    !controller.gameObject.scene.IsValid())
                {
                    continue;
                }

                int fontSize = controller.operationPanelFontSize;
                if (fontSize < 28 || fontSize > 52) fontSize = 40;
                SGEditorFactory.RefreshOperationPanel(controller, fontSize);
                EditorSceneManager.MarkSceneDirty(controller.gameObject.scene);
                updatedCount++;
            }

            EditorUtility.DisplayDialog("SGimmicks",
                updatedCount > 0
                    ? updatedCount + "個の操作パネルを日本語版へ更新しました。"
                    : "現在開いているSceneに監視カメラの操作パネルが見つかりませんでした。",
                "OK");
        }

        [MenuItem("SGimmicks/既存監視システムをモニター壁へ更新", priority = 3)]
        public static void UpgradeExistingSurveillanceSystems()
        {
            SGSurveillanceController[] controllers =
                Resources.FindObjectsOfTypeAll<SGSurveillanceController>();
            int updatedCount = 0;
            foreach (SGSurveillanceController controller in controllers)
            {
                if (controller == null || EditorUtility.IsPersistent(controller) ||
                    !controller.gameObject.scene.IsValid() || controller.surveillanceCameras == null ||
                    controller.surveillanceCameras.Length == 0)
                {
                    continue;
                }

                int fontSize = controller.operationPanelFontSize;
                if (fontSize < 28 || fontSize > 52) fontSize = 40;
                SGEditorFactory.ConfigureSurveillance(controller.gameObject, controller.monitorRenderer,
                    controller.surveillanceCameras, controller.cameraLabels, null, fontSize);
                EditorSceneManager.MarkSceneDirty(controller.gameObject.scene);
                updatedCount++;
            }

            EditorUtility.DisplayDialog("SGimmicks",
                updatedCount > 0
                    ? updatedCount + "個の監視システムをモニター壁・ローカル拡大表示対応へ更新しました。"
                    : "更新できる監視カメラシステムが現在のSceneに見つかりませんでした。",
                "OK");
        }

        [MenuItem("SGimmicks/日本語READMEを開く", priority = 50)]
        public static void OpenReadme()
        {
            TextAsset readme = AssetDatabase.LoadAssetAtPath<TextAsset>(
                SGEditorFactory.RootFolder + "/README_JP.md");
            if (readme == null)
            {
                EditorUtility.DisplayDialog("SGimmicks", "README_JP.mdが見つかりません。", "OK");
                return;
            }
            AssetDatabase.OpenAsset(readme);
        }

        private void OnGUI()
        {
            DrawHeader();
            _selectedTab = GUILayout.Toolbar(_selectedTab, Tabs, GUILayout.Height(30f));
            EditorGUILayout.Space(8f);

            _scroll = EditorGUILayout.BeginScrollView(_scroll);
            switch (_selectedTab)
            {
                case 0:
                    DrawTeleportTab();
                    break;
                case 1:
                    DrawVipTab();
                    break;
                case 2:
                    DrawSurveillanceTab();
                    break;
                case 3:
                    DrawRoomTeleportTab();
                    break;
                case 4:
                    DrawForceTeleportTab();
                    break;
                case 5:
                    DrawIntercomTab();
                    break;
                case 6:
                    DrawTheaterLightTab();
                    break;
                case 7:
                    DrawConcertLightingTab();
                    break;
                case 8:
                    DrawCastTimerTab();
                    break;
                case 9:
                    DrawMessageBoardTab();
                    break;
                default:
                    DrawWhisperAudienceTab();
                    break;
            }
            EditorGUILayout.EndScrollView();
        }

        private static void DrawHeader()
        {
            EditorGUILayout.LabelField("SGimmicks", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "PC向けVRChat Worlds SDK／UdonSharp用です。Hierarchyから下の欄へオブジェクトをドラッグし、ギミックを作成または更新してください。",
                MessageType.Info);
        }

        private void DrawTeleportTab()
        {
            EditorGUILayout.LabelField("Use式テレポート", EditorStyles.boldLabel);
            _teleportUseObject = (GameObject)EditorGUILayout.ObjectField(
                new GUIContent("Useするオブジェクト", "VRChatのUse操作を受け取るオブジェクトです。"),
                _teleportUseObject, typeof(GameObject), true);
            _teleportDestination = (Transform)EditorGUILayout.ObjectField(
                new GUIContent("テレポート先", "このTransformの位置と向きを使用します。"),
                _teleportDestination, typeof(Transform), true);
            _teleportPrompt = EditorGUILayout.TextField("Use時の表示文", _teleportPrompt);
            _teleportProximity = EditorGUILayout.FloatField("Use可能距離", _teleportProximity);

            EditorGUILayout.Space(10f);
            EditorGUI.BeginDisabledGroup(_teleportUseObject == null || _teleportDestination == null);
            if (GUILayout.Button("テレポートを作成／更新", GUILayout.Height(38f)))
            {
                try
                {
                    SGEditorFactory.ConfigureTeleport(_teleportUseObject, _teleportDestination,
                        _teleportPrompt, _teleportProximity);
                    ShowNotification(new GUIContent("テレポートを設定しました"));
                }
                catch (System.Exception exception)
                {
                    Debug.LogException(exception);
                    EditorUtility.DisplayDialog("SGimmicks", exception.Message, "OK");
                }
            }
            EditorGUI.EndDisabledGroup();

            EditorGUILayout.HelpBox(
                "Use対象にColliderがない場合だけBoxColliderを自動追加します。ローカルプレイヤーをテレポート先の位置と向きへ移動します。",
                MessageType.None);
        }

        private void DrawVipTab()
        {
            EditorGUILayout.LabelField("VIPスポーン", EditorStyles.boldLabel);
            _vipController = (SGVipSpawnController)EditorGUILayout.ObjectField(
                new GUIContent("既存コントローラー", "新規作成する場合は空欄にします。"),
                _vipController, typeof(SGVipSpawnController), true);
            _vipSpawnPoint = (Transform)EditorGUILayout.ObjectField("VIPスポーン地点", _vipSpawnPoint,
                typeof(Transform), true);
            _vipOnRespawn = EditorGUILayout.Toggle("Respawn時もVIP地点", _vipOnRespawn);

            EditorGUILayout.Space(6f);
            EditorGUILayout.LabelField("正確な表示名（大文字・小文字を区別）", EditorStyles.boldLabel);
            if (_vipDisplayNames == null) _vipDisplayNames = new List<string>();
            for (int i = 0; i < _vipDisplayNames.Count; i++)
            {
                EditorGUILayout.BeginHorizontal();
                _vipDisplayNames[i] = EditorGUILayout.TextField("VIP " + (i + 1), _vipDisplayNames[i]);
                if (GUILayout.Button("-", GUILayout.Width(28f)))
                {
                    _vipDisplayNames.RemoveAt(i);
                    GUIUtility.ExitGUI();
                }
                EditorGUILayout.EndHorizontal();
            }
            if (GUILayout.Button("＋ 表示名を追加")) _vipDisplayNames.Add(string.Empty);

            EditorGUILayout.Space(10f);
            EditorGUI.BeginDisabledGroup(_vipSpawnPoint == null);
            if (GUILayout.Button("VIPスポーンを作成／更新", GUILayout.Height(38f)))
            {
                try
                {
                    _vipController = SGEditorFactory.ConfigureVipSpawn(_vipController, _vipSpawnPoint,
                        _vipDisplayNames, _vipOnRespawn);
                    ShowNotification(new GUIContent("VIPスポーンを設定しました"));
                }
                catch (System.Exception exception)
                {
                    Debug.LogException(exception);
                    EditorUtility.DisplayDialog("SGimmicks", exception.Message, "OK");
                }
            }
            EditorGUI.EndDisabledGroup();

            EditorGUILayout.HelpBox(
                "Udonで取得できるのはログイン名ではなく表示名です。完全一致し、大文字・小文字も区別します。VIPは入室後およびRespawnの1フレーム後にローカル移動します。",
                MessageType.Warning);
        }

        private void DrawSurveillanceTab()
        {
            EditorGUILayout.LabelField("監視カメラシステム", EditorStyles.boldLabel);
            _operationPanelFontSize = EditorGUILayout.IntSlider(
                new GUIContent("操作パネル文字サイズ", "操作盤を生成・更新するときの基本文字サイズです。"),
                _operationPanelFontSize, 28, 52);
            EditorGUILayout.HelpBox(
                "推奨値は40です。変更後に作成／更新、または下の再生成ボタンを押すと反映されます。",
                MessageType.None);
            if (GUILayout.Button("監視システム一式を自動作成", GUILayout.Height(40f)))
            {
                try
                {
                    _surveillanceController = SGEditorFactory.CreateDefaultSurveillanceSystem(
                        true, _operationPanelFontSize);
                    _monitorRenderer = _surveillanceController.monitorRenderer;
                    _surveillanceCameras = new List<Camera>(_surveillanceController.surveillanceCameras);
                    _cameraLabels = new List<string>(_surveillanceController.cameraLabels);
                    ShowNotification(new GUIContent("監視システムを作成しました"));
                }
                catch (System.Exception exception)
                {
                    Debug.LogException(exception);
                    EditorUtility.DisplayDialog("SGimmicks", exception.Message, "OK");
                }
            }

            EditorGUILayout.Space(10f);
            EditorGUILayout.LabelField("既存のSceneオブジェクトを設定", EditorStyles.boldLabel);
            _surveillanceController = (SGSurveillanceController)EditorGUILayout.ObjectField(
                new GUIContent("既存コントローラー", "新しいルートを作る場合は空欄にします。"),
                _surveillanceController, typeof(SGSurveillanceController), true);
            _monitorRenderer = (Renderer)EditorGUILayout.ObjectField(
                new GUIContent("配置基準Renderer（任意）", "指定したRendererの位置・向きをモニター壁の基準にします。"),
                _monitorRenderer, typeof(Renderer), true);
            EditorGUILayout.HelpBox(
                "未指定の場合はControllerの正面へモニター壁を作成します。登録カメラ数に合わせて自動整列します。",
                MessageType.None);

            EditorGUI.BeginDisabledGroup(_surveillanceController == null);
            if (GUILayout.Button("この既存操作パネルを再生成", GUILayout.Height(32f)))
            {
                try
                {
                    SGEditorFactory.RefreshOperationPanel(_surveillanceController, _operationPanelFontSize);
                    EditorSceneManager.MarkSceneDirty(_surveillanceController.gameObject.scene);
                    ShowNotification(new GUIContent("操作パネルを更新しました"));
                }
                catch (System.Exception exception)
                {
                    Debug.LogException(exception);
                    EditorUtility.DisplayDialog("SGimmicks", exception.Message, "OK");
                }
            }
            EditorGUI.EndDisabledGroup();

            DrawCameraList();

            EditorGUILayout.Space(10f);
            bool missingCamera = _surveillanceCameras == null || _surveillanceCameras.Count == 0;
            EditorGUI.BeginDisabledGroup(missingCamera);
            if (GUILayout.Button("監視システムを作成／更新", GUILayout.Height(38f)))
            {
                try
                {
                    GameObject root = _surveillanceController == null ? null : _surveillanceController.gameObject;
                    _surveillanceController = SGEditorFactory.ConfigureSurveillance(root, _monitorRenderer,
                        _surveillanceCameras.ToArray(), _cameraLabels.ToArray(), null,
                        _operationPanelFontSize);
                    _monitorRenderer = _surveillanceController.monitorRenderer;
                    Selection.activeGameObject = _surveillanceController.gameObject;
                    ShowNotification(new GUIContent("監視システムを設定しました"));
                }
                catch (System.Exception exception)
                {
                    Debug.LogException(exception);
                    EditorUtility.DisplayDialog("SGimmicks", exception.Message, "OK");
                }
            }
            EditorGUI.EndDisabledGroup();

            EditorGUILayout.HelpBox(
                "全カメラを個別の画面へ同時表示します。拡大表示タブで選んだ大型画面、カメラの向き・ズーム、遠隔音声の選択はユーザーごとのローカル動作です。未選択プレイヤーの音声設定は変更しません。",
                MessageType.Info);
        }

        private void DrawCameraList()
        {
            if (_surveillanceCameras == null) _surveillanceCameras = new List<Camera>();
            if (_cameraLabels == null) _cameraLabels = new List<string>();
            while (_cameraLabels.Count < _surveillanceCameras.Count) _cameraLabels.Add(string.Empty);

            EditorGUILayout.Space(6f);
            EditorGUILayout.LabelField("カメラ一覧", EditorStyles.boldLabel);
            for (int i = 0; i < _surveillanceCameras.Count; i++)
            {
                EditorGUILayout.BeginVertical(EditorStyles.helpBox);
                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField("カメラ " + (i + 1), EditorStyles.boldLabel);
                if (GUILayout.Button("削除", GUILayout.Width(70f)))
                {
                    _surveillanceCameras.RemoveAt(i);
                    _cameraLabels.RemoveAt(i);
                    GUIUtility.ExitGUI();
                }
                EditorGUILayout.EndHorizontal();
                _surveillanceCameras[i] = (Camera)EditorGUILayout.ObjectField("カメラ", _surveillanceCameras[i],
                    typeof(Camera), true);
                _cameraLabels[i] = EditorGUILayout.TextField("操作盤の表示名", _cameraLabels[i]);
                EditorGUILayout.EndVertical();
            }
            if (GUILayout.Button("＋ カメラを追加"))
            {
                _surveillanceCameras.Add(null);
                _cameraLabels.Add(string.Empty);
            }
        }

        private void DrawRoomTeleportTab()
        {
            TryRecoverRoomTeleportSettingsFromScene(false);
            EditorGUILayout.LabelField("RTab 部屋番号テレポート", EditorStyles.boldLabel);
            bool rtabInstalled = SGEditorFactory.IsRTabInstalled();
            EditorGUILayout.HelpBox(
                rtabInstalled
                    ? "RTabを検出しました。1台のタブレットを共有し、入力した本人だけをローカルで移動します。"
                    : "RTabが見つかりません。RTabを先にインポートしてから設定してください。",
                rtabInstalled ? MessageType.Info : MessageType.Warning);

            EditorGUILayout.BeginHorizontal();
            _rtabAppsRoot = (Transform)EditorGUILayout.ObjectField(
                new GUIContent("RTab/Apps", "RTab直下にあるAppsをHierarchyから指定します。"),
                _rtabAppsRoot, typeof(Transform), true);
            if (GUILayout.Button("自動検出", GUILayout.Width(82f)))
                _rtabAppsRoot = SGEditorFactory.FindRTabAppsRoot();
            EditorGUILayout.EndHorizontal();

            _roomTeleportController = (SGRoomTeleportController)EditorGUILayout.ObjectField(
                new GUIContent("既存アプリ", "新規作成する場合は空欄にします。"),
                _roomTeleportController, typeof(SGRoomTeleportController), true);
            if (GUILayout.Button("Scene内の既存アプリから設定を再読み込み"))
                TryRecoverRoomTeleportSettingsFromScene(true);

            if (_roomCodes == null) _roomCodes = new List<string>();
            if (_roomDestinations == null) _roomDestinations = new List<Transform>();
            while (_roomDestinations.Count < _roomCodes.Count) _roomDestinations.Add(null);
            while (_roomCodes.Count < _roomDestinations.Count) _roomCodes.Add("0000");

            EditorGUILayout.Space(8f);
            EditorGUILayout.LabelField("部屋番号とテレポート先", EditorStyles.boldLabel);
            for (int i = 0; i < _roomCodes.Count; i++)
            {
                EditorGUILayout.BeginVertical(EditorStyles.helpBox);
                EditorGUILayout.BeginHorizontal();
                _roomCodes[i] = EditorGUILayout.TextField("4桁番号", _roomCodes[i], GUILayout.Width(190f));
                _roomDestinations[i] = (Transform)EditorGUILayout.ObjectField(
                    "移動先", _roomDestinations[i], typeof(Transform), true);
                if (GUILayout.Button("削除", GUILayout.Width(54f)))
                {
                    _roomCodes.RemoveAt(i);
                    _roomDestinations.RemoveAt(i);
                    GUIUtility.ExitGUI();
                }
                EditorGUILayout.EndHorizontal();
                EditorGUILayout.EndVertical();
            }
            if (GUILayout.Button("＋ 部屋を追加"))
            {
                _roomCodes.Add("0000");
                _roomDestinations.Add(null);
            }

            EditorGUILayout.Space(12f);
            EditorGUILayout.LabelField("グローバル表示切替", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "指定した4桁をEで確定すると、対象オブジェクトの表示状態をインスタンス内の全員へ同期します。途中参加者にも現在の状態が反映されます。",
                MessageType.Info);
            _globalToggleObject = (GameObject)EditorGUILayout.ObjectField(
                new GUIContent("表示切替オブジェクト", "Hierarchy上のパネルまたはオブジェクトを指定します。"),
                _globalToggleObject, typeof(GameObject), true);
            _globalShowCode = EditorGUILayout.TextField("表示する4桁番号", _globalShowCode);
            _globalHideCode = EditorGUILayout.TextField("非表示にする4桁番号", _globalHideCode);
            _globalObjectInitiallyVisible = EditorGUILayout.Toggle(
                "ワールド開始時に表示", _globalObjectInitiallyVisible);

            EditorGUILayout.Space(10f);
            bool canCreate = rtabInstalled && _roomCodes.Count > 0;
            EditorGUI.BeginDisabledGroup(!canCreate);
            if (GUILayout.Button("RTabアプリとして作成／更新", GUILayout.Height(42f)))
            {
                try
                {
                    _roomTeleportController = SGEditorFactory.ConfigureRoomTeleportRTab(
                        _rtabAppsRoot, _roomTeleportController, _roomCodes, _roomDestinations,
                        _globalToggleObject, _globalShowCode, _globalHideCode,
                        _globalObjectInitiallyVisible);
                    _rtabAppsRoot = _roomTeleportController.transform.parent;
                    ShowNotification(new GUIContent("RTabへ部屋番号アプリを追加しました"));
                }
                catch (System.Exception exception)
                {
                    Debug.LogException(exception);
                    EditorUtility.DisplayDialog("SGimmicks", exception.Message, "OK");
                }
            }
            EditorGUI.EndDisabledGroup();

            EditorGUILayout.HelpBox(
                "「利用開始／ユーザー切替」で前の入力を消去します。数字を4桁入力し、Eで決定、Cで消去します。テレポートは入力した本人だけ、表示切替だけはインスタンス内の全員へ同期されます。RTabがPickupならテレポート前に自動で手放します。",
                MessageType.None);
        }

        private void TryRecoverRoomTeleportSettingsFromScene(bool showResult)
        {
            if (!showResult && _roomTeleportController != null) return;

            SGRoomTeleportController[] controllers =
                Resources.FindObjectsOfTypeAll<SGRoomTeleportController>();
            foreach (SGRoomTeleportController controller in controllers)
            {
                if (controller == null || EditorUtility.IsPersistent(controller) ||
                    !controller.gameObject.scene.IsValid())
                {
                    continue;
                }

                _roomTeleportController = controller;
                _rtabAppsRoot = controller.transform.parent;
                _roomCodes = controller.roomCodes == null
                    ? new List<string>()
                    : new List<string>(controller.roomCodes);
                _roomDestinations = controller.roomDestinations == null
                    ? new List<Transform>()
                    : new List<Transform>(controller.roomDestinations);
                _globalToggleObject = controller.globalToggleObject;
                _globalShowCode = string.IsNullOrEmpty(controller.globalShowCode)
                    ? "9001"
                    : controller.globalShowCode;
                _globalHideCode = string.IsNullOrEmpty(controller.globalHideCode)
                    ? "9000"
                    : controller.globalHideCode;
                _globalObjectInitiallyVisible = _globalToggleObject == null ||
                                                _globalToggleObject.activeSelf;
                if (showResult) ShowNotification(new GUIContent("Sceneから設定を再読み込みしました"));
                Repaint();
                return;
            }

            if (showResult)
                ShowNotification(new GUIContent("Scene内に既存アプリが見つかりません"));
        }

        private void DrawForceTeleportTab()
        {
            TryRecoverForceTeleportSettingsFromScene(false);
            EditorGUILayout.LabelField("強制テレポート操作盤", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "参加者一覧から複数人を選び、各プレイヤーへ別々の移動先を割り当てて一斉に移動できます。実行命令は同期され、対象者本人のクライアントが自分自身をテレポートします。",
                MessageType.Info);

            _forceTeleportController = (SGForceTeleportController)EditorGUILayout.ObjectField(
                new GUIContent("既存コントローラー", "新規作成する場合は空欄にします。"),
                _forceTeleportController, typeof(SGForceTeleportController), true);
            if (GUILayout.Button("Scene内の既存設定を再読み込み"))
                TryRecoverForceTeleportSettingsFromScene(true);

            if (_forceDestinations == null) _forceDestinations = new List<Transform>();
            if (_forceDestinationLabels == null) _forceDestinationLabels = new List<string>();
            while (_forceDestinationLabels.Count < _forceDestinations.Count)
                _forceDestinationLabels.Add("移動先 " + (_forceDestinationLabels.Count + 1).ToString("00"));
            while (_forceDestinations.Count < _forceDestinationLabels.Count)
                _forceDestinations.Add(null);

            EditorGUILayout.Space(8f);
            EditorGUILayout.LabelField("移動先一覧", EditorStyles.boldLabel);
            for (int i = 0; i < _forceDestinations.Count; i++)
            {
                EditorGUILayout.BeginVertical(EditorStyles.helpBox);
                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField("移動先 " + (i + 1), EditorStyles.boldLabel);
                if (GUILayout.Button("削除", GUILayout.Width(60f)))
                {
                    _forceDestinations.RemoveAt(i);
                    _forceDestinationLabels.RemoveAt(i);
                    GUIUtility.ExitGUI();
                }
                EditorGUILayout.EndHorizontal();
                _forceDestinations[i] = (Transform)EditorGUILayout.ObjectField(
                    "Hierarchy上の場所", _forceDestinations[i], typeof(Transform), true);
                _forceDestinationLabels[i] = EditorGUILayout.TextField(
                    "操作盤の表示名", _forceDestinationLabels[i]);
                EditorGUILayout.EndVertical();
            }
            if (GUILayout.Button("＋ 移動先を追加"))
            {
                _forceDestinations.Add(null);
                _forceDestinationLabels.Add("移動先 " + _forceDestinations.Count.ToString("00"));
            }

            EditorGUILayout.Space(10f);
            EditorGUILayout.LabelField("安全設定", EditorStyles.boldLabel);
            string[] accessLabels = { "全員", "インスタンスマスターのみ", "許可した表示名のみ" };
            _forceAccessMode = EditorGUILayout.Popup("操作できる人", _forceAccessMode, accessLabels);
            if (_forceAccessMode == 2)
            {
                if (_forceAuthorizedDisplayNames == null)
                    _forceAuthorizedDisplayNames = new List<string>();
                EditorGUILayout.HelpBox("VRChatの表示名で完全一致し、大文字・小文字を区別します。", MessageType.None);
                for (int i = 0; i < _forceAuthorizedDisplayNames.Count; i++)
                {
                    EditorGUILayout.BeginHorizontal();
                    _forceAuthorizedDisplayNames[i] = EditorGUILayout.TextField(
                        "許可する表示名 " + (i + 1), _forceAuthorizedDisplayNames[i]);
                    if (GUILayout.Button("削除", GUILayout.Width(60f)))
                    {
                        _forceAuthorizedDisplayNames.RemoveAt(i);
                        GUIUtility.ExitGUI();
                    }
                    EditorGUILayout.EndHorizontal();
                }
                if (GUILayout.Button("＋ 許可する表示名を追加"))
                    _forceAuthorizedDisplayNames.Add("表示名");
            }

            _forceBlurDuration = EditorGUILayout.Slider(
                new GUIContent("ぼかしから戻る時間", "テレポート直後に最大までぼかし、指定秒数で透明に戻します。"),
                _forceBlurDuration, 0.5f, 5f);

            EditorGUILayout.Space(12f);
            bool canCreate = _forceDestinations.Count > 0;
            EditorGUI.BeginDisabledGroup(!canCreate);
            if (GUILayout.Button("強制テレポート操作盤を作成／更新", GUILayout.Height(42f)))
            {
                try
                {
                    _forceTeleportController = SGEditorFactory.ConfigureForceTeleport(
                        _forceTeleportController, _forceDestinations, _forceDestinationLabels,
                        _forceAccessMode, _forceAuthorizedDisplayNames, _forceBlurDuration);
                    ShowNotification(new GUIContent("強制テレポート操作盤を設定しました"));
                }
                catch (System.Exception exception)
                {
                    Debug.LogException(exception);
                    EditorUtility.DisplayDialog("SGimmicks", exception.Message, "OK");
                }
            }
            EditorGUI.EndDisabledGroup();

            EditorGUILayout.HelpBox(
                "ワールド内では、プレイヤー行を押して実行対象へ追加します。最後に押したプレイヤーへ右側の移動先を割り当てます。人数分設定後に「同時テレポート」を押してください。ぼかし演出は操作盤上でON／OFFできます。",
                MessageType.None);
        }

        private void TryRecoverForceTeleportSettingsFromScene(bool showResult)
        {
            if (!showResult && _forceTeleportController != null) return;
            SGForceTeleportController[] controllers =
                Resources.FindObjectsOfTypeAll<SGForceTeleportController>();
            foreach (SGForceTeleportController controller in controllers)
            {
                if (controller == null || EditorUtility.IsPersistent(controller) ||
                    !controller.gameObject.scene.IsValid()) continue;
                _forceTeleportController = controller;
                _forceDestinations = controller.destinations == null
                    ? new List<Transform>()
                    : new List<Transform>(controller.destinations);
                _forceDestinationLabels = controller.destinationLabels == null
                    ? new List<string>()
                    : new List<string>(controller.destinationLabels);
                _forceAccessMode = controller.accessMode;
                _forceAuthorizedDisplayNames = controller.authorizedDisplayNames == null
                    ? new List<string>()
                    : new List<string>(controller.authorizedDisplayNames);
                _forceBlurDuration = controller.blurDuration;
                if (showResult) ShowNotification(new GUIContent("Sceneから設定を再読み込みしました"));
                Repaint();
                return;
            }
            if (showResult)
                ShowNotification(new GUIContent("Scene内に既存の強制テレポートが見つかりません"));
        }

        private void DrawIntercomTab()
        {
            TryRecoverIntercomSettingsFromScene(false);
            EditorGUILayout.LabelField("PCVR 共通内線", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "参加ボタンを押したユーザー全員を一つの内線グループにします。右トリガーを素早く2回押して接続し、以後は右トリガー長押し中だけ参加者全員へ送話します。",
                MessageType.Info);
            _intercomController = (SGIntercomController)EditorGUILayout.ObjectField(
                new GUIContent("既存コントローラー", "新規作成する場合は空欄にします。"),
                _intercomController, typeof(SGIntercomController), true);
            if (GUILayout.Button("Scene内の既存設定を再読み込み"))
                TryRecoverIntercomSettingsFromScene(true);

            _intercomSlotCount = EditorGUILayout.IntSlider(
                new GUIContent("最大参加人数", "同期スロット数です。ワールドの最大人数に合わせてください。"),
                _intercomSlotCount, 2, 80);
            _intercomDoubleTapWindow = EditorGUILayout.Slider(
                new GUIContent("2回押し判定時間", "1回目から2回目までに許可する秒数です。"),
                _intercomDoubleTapWindow, 0.2f, 0.8f);

            EditorGUILayout.Space(12f);
            if (GUILayout.Button("内線操作盤を作成／更新", GUILayout.Height(42f)))
            {
                try
                {
                    _intercomController = SGEditorFactory.ConfigureIntercom(
                        _intercomController, _intercomSlotCount, _intercomDoubleTapWindow);
                    ShowNotification(new GUIContent("内線操作盤を設定しました"));
                }
                catch (System.Exception exception)
                {
                    Debug.LogException(exception);
                    EditorUtility.DisplayDialog("SGimmicks", exception.Message, "OK");
                }
            }

            EditorGUILayout.HelpBox(
                "送話開始／終了はManual Syncされます。送話中は参加者側で発信者のVoice距離を最大化し、未参加者側では0mへ切り替えます。VRChatの通信遅延により、押し始め・離した直後の短時間だけ切替が遅れる場合があります。デスクトップモードでは参加できません。",
                MessageType.Warning);
        }

        private void TryRecoverIntercomSettingsFromScene(bool showResult)
        {
            if (!showResult && _intercomController != null) return;
            SGIntercomController[] controllers = Resources.FindObjectsOfTypeAll<SGIntercomController>();
            foreach (SGIntercomController controller in controllers)
            {
                if (controller == null || EditorUtility.IsPersistent(controller) ||
                    !controller.gameObject.scene.IsValid()) continue;
                _intercomController = controller;
                _intercomSlotCount = controller.slots == null ? 80 : controller.slots.Length;
                _intercomDoubleTapWindow = controller.doubleTapWindow;
                if (showResult) ShowNotification(new GUIContent("Sceneから内線設定を再読み込みしました"));
                Repaint();
                return;
            }
            if (showResult)
                ShowNotification(new GUIContent("Scene内に既存の内線が見つかりません"));
        }

        private void DrawTheaterLightTab()
        {
            EditorGUILayout.LabelField("映画館の館内照明", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "スタッフルームのボードをUseすると、登録したライトを徐々に暗くしてインスタンス全体へ同期します。もう一度Useすると元の光量へ戻ります。",
                MessageType.Info);
            _theaterLightBoard = (GameObject)EditorGUILayout.ObjectField(
                new GUIContent("操作ボード", "Use操作を受け取るスタッフルーム内のGameObjectです。"),
                _theaterLightBoard, typeof(GameObject), true);
            _theaterLightController = (SGTheaterLightController)EditorGUILayout.ObjectField(
                new GUIContent("既存コントローラー", "既存設定を更新する場合に指定します。"),
                _theaterLightController, typeof(SGTheaterLightController), true);

            if (_theaterLights == null) _theaterLights = new List<Light>();
            EditorGUILayout.Space(8f);
            EditorGUILayout.LabelField("暗くするライト", EditorStyles.boldLabel);
            bool containsBakedLight = false;
            for (int i = 0; i < _theaterLights.Count; i++)
            {
                EditorGUILayout.BeginHorizontal();
                _theaterLights[i] = (Light)EditorGUILayout.ObjectField(
                    "ライト " + (i + 1), _theaterLights[i], typeof(Light), true);
                if (_theaterLights[i] != null &&
                    _theaterLights[i].lightmapBakeType == LightmapBakeType.Baked)
                    containsBakedLight = true;
                if (GUILayout.Button("削除", GUILayout.Width(60f)))
                {
                    _theaterLights.RemoveAt(i);
                    GUIUtility.ExitGUI();
                }
                EditorGUILayout.EndHorizontal();
            }
            if (GUILayout.Button("＋ ライトを追加")) _theaterLights.Add(null);
            if (containsBakedLight)
                EditorGUILayout.HelpBox(
                    "Bakedライトが含まれています。ベイク済みの明るさは実行中に変化しません。RealtimeまたはMixed（推奨: Baked Indirect）へ変更し、暗い状態を基準に再ベイクしてください。",
                    MessageType.Error);

            _theaterDimmedMultiplier = EditorGUILayout.Slider(
                new GUIContent("暗転後の光量", "元のIntensityに掛ける割合です。0で消灯、0.05で5%です。"),
                _theaterDimmedMultiplier, 0f, 1f);
            _theaterTransitionDuration = EditorGUILayout.Slider("変化時間（秒）",
                _theaterTransitionDuration, 0.1f, 20f);

            EditorGUILayout.Space(8f);
            EditorGUILayout.LabelField("暗くするときの音", EditorStyles.boldLabel);
            _theaterDimmingClip = (AudioClip)EditorGUILayout.ObjectField(
                "AudioClip", _theaterDimmingClip, typeof(AudioClip), false);
            if (_theaterDimmingClip == null)
                EditorGUILayout.HelpBox(
                    "暗転時に鳴らすAudioClipを指定してください。",
                    MessageType.Warning);
            _theaterAudioVolume = EditorGUILayout.Slider("音量", _theaterAudioVolume, 0f, 1f);
            _theaterAudioMaxDistance = EditorGUILayout.FloatField(
                "最大到達距離", Mathf.Max(1f, _theaterAudioMaxDistance));

            EditorGUILayout.Space(12f);
            bool hasLight = _theaterLights.Exists(light => light != null);
            bool canCreate = _theaterLightBoard != null && hasLight && _theaterDimmingClip != null;
            EditorGUI.BeginDisabledGroup(!canCreate);
            if (GUILayout.Button("映画館照明ギミックを作成／更新", GUILayout.Height(42f)))
            {
                try
                {
                    _theaterLightController = SGEditorFactory.ConfigureTheaterLights(
                        _theaterLightBoard, _theaterLightController, _theaterLights,
                        _theaterDimmedMultiplier, _theaterTransitionDuration,
                        _theaterDimmingClip, _theaterAudioVolume, _theaterAudioMaxDistance);
                    _theaterLightBoard = _theaterLightController.gameObject;
                    ShowNotification(new GUIContent("映画館照明を設定しました"));
                }
                catch (System.Exception exception)
                {
                    Debug.LogException(exception);
                    EditorUtility.DisplayDialog("SGimmicks", exception.Message, "OK");
                }
            }
            EditorGUI.EndDisabledGroup();
            EditorGUILayout.HelpBox(
                "暗転状態、開始時刻、変化開始時の光量をManual Syncします。途中参加者には現在の暗転状態が反映されますが、過去の暗転音は再生しません。",
                MessageType.None);
        }

        private void DrawConcertLightingTab()
        {
            TryAutoLoadConcertLighting();
            EditorGUILayout.LabelField("ピアノコンサート照明", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "会場全体を乗算Projectorで暗くし、天井からステージへ伸びる円錐内だけを暗転から除外します。実際のSpot Lightと半透明の光柱も同じ円錐へ自動配置します。lilToonアバター向け・PC専用です。",
                MessageType.Info);

            if (GUILayout.Button("コンサート照明一式を自動生成", GUILayout.Height(48f)))
            {
                try
                {
                    _concertLightingController = SGEditorFactory.CreateDefaultConcertLighting();
                    _concertLightingBoard = _concertLightingController.gameObject;
                    _concertCeilingPoint = _concertLightingController.ceilingLightPoint;
                    _concertStageTarget = _concertLightingController.stageTargetPoint;
                    _concertDarknessVolume = _concertLightingController.transform
                        .Find("DarknessVolume")?.GetComponent<BoxCollider>();
                    ShowNotification(new GUIContent("コンサート照明を自動生成しました"));
                }
                catch (System.Exception exception)
                {
                    Debug.LogException(exception);
                    EditorUtility.DisplayDialog("SGimmicks", exception.Message, "OK");
                }
            }

            EditorGUILayout.Space(10f);
            EditorGUILayout.LabelField("配置", EditorStyles.boldLabel);
            if (GUILayout.Button("シーンの既存設定を読み込む", GUILayout.Height(30f)))
            {
                _concertAutoLoadAttempted = false;
                if (!TryAutoLoadConcertLighting())
                    ShowNotification(new GUIContent("シーン内にコンサート照明がありません"));
            }
            _concertLightingBoard = (GameObject)EditorGUILayout.ObjectField(
                new GUIContent("操作UIの設置先", "World Space UIのボタンを自動生成する親GameObjectです。"),
                _concertLightingBoard, typeof(GameObject), true);
            EditorGUI.BeginChangeCheck();
            SGConcertLightingController selectedController =
                (SGConcertLightingController)EditorGUILayout.ObjectField(
                "既存コントローラー", _concertLightingController,
                typeof(SGConcertLightingController), true);
            if (EditorGUI.EndChangeCheck())
            {
                _concertLightingController = selectedController;
                if (_concertLightingController != null)
                    LoadConcertLightingSettings(_concertLightingController);
            }
            _concertCeilingPoint = (Transform)EditorGUILayout.ObjectField(
                new GUIContent("天井ライト位置", "円錐の頂点になるTransformです。"),
                _concertCeilingPoint, typeof(Transform), true);
            _concertStageTarget = (Transform)EditorGUILayout.ObjectField(
                new GUIContent("ピアノ／演奏位置", "円錐ライトの中心を向けるTransformです。"),
                _concertStageTarget, typeof(Transform), true);
            _concertDarknessVolume = (BoxCollider)EditorGUILayout.ObjectField(
                new GUIContent("暗転させる会場範囲", "このBox Collider内へ暗転Projectorを自動配置します。Trigger推奨です。"),
                _concertDarknessVolume, typeof(BoxCollider), true);
            _concertDarknessBoundsPadding = EditorGUILayout.Slider(
                new GUIContent("暗転範囲の余白（m）",
                    "Colliderの各面より外側まで暗転Projectorを広げます。上端が欠ける場合は大きくしてください。"),
                _concertDarknessBoundsPadding, 0f, 5f);

            EditorGUILayout.Space(8f);
            EditorGUILayout.LabelField("円錐ライト", EditorStyles.boldLabel);
            _concertConeAngle = EditorGUILayout.Slider("円錐の角度", _concertConeAngle, 5f, 100f);
            _concertLightColor = EditorGUILayout.ColorField("ライト色", _concertLightColor);
            _concertLightIntensity = EditorGUILayout.Slider("ステージ光量", _concertLightIntensity, 0f, 12f);
            _concertBeamOpacity = EditorGUILayout.Slider(
                new GUIContent("光の筋の濃さ", "半透明の円錐メッシュです。上げすぎるとVRで眩しく見えます。"),
                _concertBeamOpacity, 0f, 0.5f);
            _concertAudienceBrightness = EditorGUILayout.Slider(
                new GUIContent("客席側の明るさ", "0で黒、0.08で元映像の8%です。"),
                _concertAudienceBrightness, 0f, 1f);
            _concertEdgeSoftness = EditorGUILayout.Slider("円錐境界のぼかし",
                _concertEdgeSoftness, 0.01f, 1f);
            _concertTransitionDuration = EditorGUILayout.Slider("切替時間（秒）",
                _concertTransitionDuration, 0.1f, 20f);

            EditorGUILayout.Space(8f);
            EditorGUILayout.LabelField("開演時の音", EditorStyles.boldLabel);
            _concertStartClip = (AudioClip)EditorGUILayout.ObjectField(
                "AudioClip（任意）", _concertStartClip, typeof(AudioClip), false);
            _concertAudioVolume = EditorGUILayout.Slider("音量", _concertAudioVolume, 0f, 1f);
            _concertAudioMaxDistance = EditorGUILayout.FloatField(
                "最大到達距離", Mathf.Max(1f, _concertAudioMaxDistance));

            EditorGUILayout.Space(12f);
            bool canCreate = _concertLightingBoard != null && _concertCeilingPoint != null &&
                             _concertStageTarget != null && _concertDarknessVolume != null;
            EditorGUI.BeginDisabledGroup(!canCreate);
            if (GUILayout.Button("コンサート照明ギミックを作成／更新", GUILayout.Height(44f)))
            {
                try
                {
                    _concertLightingController = SGEditorFactory.ConfigureConcertLighting(
                        _concertLightingBoard, _concertLightingController, _concertCeilingPoint,
                        _concertStageTarget, _concertDarknessVolume,
                        _concertDarknessBoundsPadding, _concertConeAngle,
                        _concertAudienceBrightness, _concertEdgeSoftness,
                        _concertTransitionDuration, _concertLightColor,
                        _concertLightIntensity, _concertBeamOpacity, _concertStartClip,
                        _concertAudioVolume, _concertAudioMaxDistance);
                    ShowNotification(new GUIContent("コンサート照明を設定しました"));
                }
                catch (System.Exception exception)
                {
                    Debug.LogException(exception);
                    EditorUtility.DisplayDialog("SGimmicks", exception.Message, "OK");
                }
            }
            EditorGUI.EndDisabledGroup();

            EditorGUILayout.HelpBox(
                "円錐内に入ったプレイヤーは全員明るく見えます。lilToonのOpaque／Cutoutは安定して暗転できますが、強いEmission、特殊Transparent、GrabPass、極端に遅いRender Queueのパーツは暗転が弱くなる場合があります。",
                MessageType.Warning);
            EditorGUILayout.HelpBox(
                "World Space UIの「照明を切り替える」をポインタで押して操作します。暗転状態と開始時刻はManual Syncされ、途中参加者にも現在状態が反映されます。ProjectorはPlayer／PlayerLocalを除外しない設定で生成されます。",
                MessageType.None);
        }

        private bool TryAutoLoadConcertLighting()
        {
            if (_concertLightingController != null)
            {
                _concertAutoLoadAttempted = true;
                return true;
            }
            if (_concertAutoLoadAttempted) return false;
            _concertAutoLoadAttempted = true;

            SGConcertLightingController[] controllers =
                Resources.FindObjectsOfTypeAll<SGConcertLightingController>();
            foreach (SGConcertLightingController controller in controllers)
            {
                if (controller == null || EditorUtility.IsPersistent(controller) ||
                    !controller.gameObject.scene.IsValid())
                    continue;
                LoadConcertLightingSettings(controller);
                return true;
            }
            return false;
        }

        private void LoadConcertLightingSettings(SGConcertLightingController controller)
        {
            if (controller == null) return;
            _concertLightingController = controller;
            _concertLightingBoard = controller.gameObject;
            _concertCeilingPoint = controller.ceilingLightPoint;
            _concertStageTarget = controller.stageTargetPoint;
            _concertDarknessVolume = controller.darknessVolume;
            if (_concertDarknessVolume == null)
                _concertDarknessVolume = controller.transform.Find("DarknessVolume")
                    ?.GetComponent<BoxCollider>();
            _concertConeAngle = controller.coneAngle;
            _concertDarknessBoundsPadding = controller.darknessBoundsPadding;
            _concertAudienceBrightness = controller.audienceBrightness;
            _concertEdgeSoftness = controller.coneEdgeSoftness;
            _concertTransitionDuration = controller.transitionDuration;
            _concertLightColor = controller.stageLightColor;
            _concertLightIntensity = controller.stageBrightIntensity;
            _concertBeamOpacity = controller.beamOpacity;
            if (controller.startAudioSource != null)
            {
                _concertStartClip = controller.startAudioSource.clip;
                _concertAudioVolume = controller.startAudioSource.volume;
                _concertAudioMaxDistance = controller.startAudioSource.maxDistance;
            }
            Repaint();
        }

        private void DrawCastTimerTab()
        {
            if (_castTimerManager == null)
            {
                CastTimerManager[] managers = Resources.FindObjectsOfTypeAll<CastTimerManager>();
                foreach (CastTimerManager manager in managers)
                {
                    if (manager == null || EditorUtility.IsPersistent(manager) ||
                        !manager.gameObject.scene.IsValid())
                        continue;
                    _castTimerManager = manager;
                    break;
                }
            }

            EditorGUILayout.LabelField("キャスト共通タイマー", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "キャスト登録パネル、スタッフ操作盤、左手首タイマー、同期タイマー、登録者だけに聞こえるベルを一式で配置します。PCVR専用です。",
                MessageType.Info);

            if (GUILayout.Button("キャストタイマー一式をシーンへ配置", GUILayout.Height(48f)))
            {
                try
                {
                    _castTimerManager = SGEditorFactory.CreateCastTimerGimmick();
                    ShowNotification(new GUIContent("キャストタイマーを配置しました"));
                }
                catch (System.Exception exception)
                {
                    Debug.LogException(exception);
                    EditorUtility.DisplayDialog("SGimmicks", exception.Message, "OK");
                }
            }

            EditorGUILayout.Space(10f);
            _castTimerManager = (CastTimerManager)EditorGUILayout.ObjectField(
                "配置済みタイマー", _castTimerManager, typeof(CastTimerManager), true);

            if (_castTimerManager != null)
            {
                Transform registration = _castTimerManager.transform.Find("CastRegistrationStation");
                Transform staff = _castTimerManager.transform.Find("StaffControlPanel");
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button("キャスト登録パネルを選択", GUILayout.Height(34f)) &&
                    registration != null)
                    Selection.activeGameObject = registration.gameObject;
                if (GUILayout.Button("スタッフ操作盤を選択", GUILayout.Height(34f)) &&
                    staff != null)
                    Selection.activeGameObject = staff.gameObject;
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.HelpBox(
                    "Prefabルートは残したまま、CastRegistrationStationを登録場所へ、StaffControlPanelをスタッフルームへ移動してください。参照は設定済みです。",
                    MessageType.None);
            }

            if (GUILayout.Button("キャストタイマー説明書を開く", GUILayout.Height(30f)))
            {
                TextAsset readme = AssetDatabase.LoadAssetAtPath<TextAsset>(
                    SGEditorFactory.CastTimerRootFolder + "/README_JA.md");
                if (readme != null) AssetDatabase.OpenAsset(readme);
            }

            EditorGUILayout.Space(8f);
            EditorGUILayout.HelpBox(
                "登録した本人が左トリガーを0.5秒以内に2回押すと手首タイマーを表示します。スタッフ操作盤では時間設定、開始、一時停止／再開、リセット、全キャストへのベル送信ができます。",
                MessageType.None);
        }

        private void DrawMessageBoardTab()
        {
            EditorGUILayout.LabelField("お題・メッセージ表示", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "入力パネルをUseするとローカル入力欄が開きます。プレビュー後にOKを押すと、100文字までの改行可能な日本語を全員へ同期し、登録した全画面へ表示します。",
                MessageType.Info);
            if (GUILayout.Button("入力操作盤＋表示画面を一式自動生成", GUILayout.Height(48f)))
            {
                try
                {
                    _messageBoardController = SGEditorFactory.CreateCompleteMessageBoard();
                    _messageBoardUseObject = _messageBoardController.gameObject;
                    _messageBoardOutputs = new List<TMP_Text>(_messageBoardController.outputTexts);
                    ShowNotification(new GUIContent("操作盤と表示画面を自動生成しました"));
                }
                catch (System.Exception exception)
                {
                    Debug.LogException(exception);
                    EditorUtility.DisplayDialog("SGimmicks", exception.Message, "OK");
                }
            }
            EditorGUILayout.HelpBox(
                "初めて作る場合は上のボタンだけで作成できます。操作画面と実表示画面はどちらもWorld Space UIとして生成されます。生成後、MessageInputPanelとMessageDisplayCanvasを配置してください。",
                MessageType.None);
            EditorGUILayout.Space(10f);
            EditorGUILayout.LabelField("既存構成の更新／画面追加", EditorStyles.boldLabel);
            _messageBoardUseObject = (GameObject)EditorGUILayout.ObjectField(
                new GUIContent("入力パネル設置先", "Use操作を受け取り、入力Canvasを子として作成するGameObjectです。"),
                _messageBoardUseObject, typeof(GameObject), true);
            _messageBoardController = (SGMessageBoardController)EditorGUILayout.ObjectField(
                "既存コントローラー", _messageBoardController, typeof(SGMessageBoardController), true);

            EditorGUILayout.Space(8f);
            EditorGUILayout.LabelField("表示画面（TextMeshPro）", EditorStyles.boldLabel);
            if (_messageBoardOutputs == null) _messageBoardOutputs = new List<TMP_Text>();
            for (int i = 0; i < _messageBoardOutputs.Count; i++)
            {
                EditorGUILayout.BeginHorizontal();
                _messageBoardOutputs[i] = (TMP_Text)EditorGUILayout.ObjectField(
                    "画面 " + (i + 1), _messageBoardOutputs[i], typeof(TMP_Text), true);
                if (GUILayout.Button("削除", GUILayout.Width(60f)))
                {
                    _messageBoardOutputs.RemoveAt(i);
                    GUIUtility.ExitGUI();
                }
                EditorGUILayout.EndHorizontal();
            }
            if (GUILayout.Button("＋ 表示画面を追加（更新時に自動生成）")) _messageBoardOutputs.Add(null);
            EditorGUILayout.HelpBox(
                "追加した画面欄は空欄のままで更新できます。空欄の分はWorld Space UI表示パネルとTextMeshProUGUIを自動生成し、同じ音源の3D AudioSourceも設定します。既存のTextMeshProを指定することもできます。",
                MessageType.None);
            _messageBoardFontSize = EditorGUILayout.Slider(
                new GUIContent("投稿本文の文字サイズ", "確定後に実表示画面へ出る文章だけのサイズです。操作説明やボタン文字には影響しません。"),
                _messageBoardFontSize, 12f, 200f);

            EditorGUILayout.Space(8f);
            EditorGUILayout.LabelField("確定時の効果音（任意）", EditorStyles.boldLabel);
            _messageBoardSubmitClip = (AudioClip)EditorGUILayout.ObjectField(
                "AudioClip", _messageBoardSubmitClip, typeof(AudioClip), false);
            _messageBoardAudioVolume = EditorGUILayout.Slider("音量", _messageBoardAudioVolume, 0f, 1f);
            _messageBoardAudioMaxDistance = EditorGUILayout.FloatField(
                "最大到達距離", Mathf.Max(1f, _messageBoardAudioMaxDistance));

            bool canCreate = _messageBoardUseObject != null && _messageBoardOutputs.Count > 0;
            EditorGUILayout.Space(12f);
            EditorGUI.BeginDisabledGroup(!canCreate);
            if (GUILayout.Button("お題・メッセージ表示ギミックを作成／更新", GUILayout.Height(42f)))
            {
                try
                {
                    _messageBoardController = SGEditorFactory.ConfigureMessageBoard(
                        _messageBoardUseObject, _messageBoardController, _messageBoardOutputs,
                        _messageBoardFontSize, _messageBoardSubmitClip,
                        _messageBoardAudioVolume, _messageBoardAudioMaxDistance);
                    _messageBoardUseObject = _messageBoardController.gameObject;
                    _messageBoardOutputs = new List<TMP_Text>(_messageBoardController.outputTexts);
                    ShowNotification(new GUIContent("お題・メッセージ表示を設定しました"));
                }
                catch (System.Exception exception)
                {
                    Debug.LogException(exception);
                    EditorUtility.DisplayDialog("SGimmicks", exception.Message, "OK");
                }
            }
            EditorGUI.EndDisabledGroup();
        }

        private void DrawWhisperAudienceTab()
        {
            EditorGUILayout.LabelField("囁き声限定・固定観客席", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "観客が固定座席へ座ると身長を揃え、Station AnimatorのVoice値を左足の微小移動へ変換して声量を判定します。閾値を一定時間超えると、その本人だけの視界前方へOUTを表示します。",
                MessageType.Info);

            _whisperAudienceManager = (SGWhisperAudienceManager)EditorGUILayout.ObjectField(
                new GUIContent("既存コントローラー", "新規作成する場合は空欄にします。更新時も座席と操作盤の配置を保持します。"),
                _whisperAudienceManager, typeof(SGWhisperAudienceManager), true);
            _whisperSeatCount = EditorGUILayout.IntSlider("観客席数", _whisperSeatCount, 1, 40);
            _whisperDefaultThreshold = EditorGUILayout.Slider(
                new GUIContent("初期声量閾値", "Voiceの0～1に対応します。スタッフ操作盤で座席ごとに変更できます。"),
                _whisperDefaultThreshold, 0.05f, 0.95f);
            _whisperHoldDuration = EditorGUILayout.Slider("超過判定時間（秒）",
                _whisperHoldDuration, 0.05f, 2f);
            _whisperFixedEyeHeight = EditorGUILayout.Slider(
                new GUIContent("着席中の目線高（m）", "観客だけに適用し、退席時に元の身長へ戻します。"),
                _whisperFixedEyeHeight, 0.5f, 3f);

            EditorGUILayout.Space(10f);
            EditorGUILayout.LabelField("キャスト（判定対象外）", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "表示名の完全一致・大文字小文字を区別します。登録キャストは普通に話せて、座席付近を移動しても判定されません。",
                MessageType.None);
            DrawStringList(_whisperCastDisplayNames, "キャスト", "＋ キャストを追加");

            EditorGUILayout.Space(10f);
            EditorGUILayout.LabelField("操作を許可するスタッフ", EditorStyles.boldLabel);
            DrawStringList(_whisperOperatorDisplayNames, "スタッフ", "＋ スタッフを追加");
            EditorGUILayout.HelpBox(
                "インスタンスマスター、登録キャスト、登録スタッフが操作盤を使えます。座席を選び、個別閾値の増減とOUT解除ができます。",
                MessageType.None);

            EditorGUILayout.Space(12f);
            if (GUILayout.Button("囁き声判定ギミックを作成／更新", GUILayout.Height(48f)))
            {
                try
                {
                    _whisperAudienceManager = SGEditorFactory.ConfigureWhisperAudience(
                        _whisperAudienceManager, _whisperSeatCount, _whisperDefaultThreshold,
                        _whisperHoldDuration, _whisperFixedEyeHeight,
                        _whisperCastDisplayNames, _whisperOperatorDisplayNames);
                    ShowNotification(new GUIContent("囁き声判定ギミックを設定しました"));
                }
                catch (System.Exception exception)
                {
                    Debug.LogException(exception);
                    EditorUtility.DisplayDialog("SGimmicks", exception.Message, "OK");
                }
            }

            EditorGUILayout.HelpBox(
                "生成後はAudienceSeats配下の各Seatを客席へ、WhisperStaffPanelをスタッフルームへ移動してください。座席の位置・回転と操作盤の配置は更新後も保持されます。実機では各マイク差があるため、最初に閾値0.65付近から調整してください。",
                MessageType.Warning);
        }

        private static void DrawStringList(List<string> values, string rowLabel, string addLabel)
        {
            if (values == null) return;
            for (int i = 0; i < values.Count; i++)
            {
                EditorGUILayout.BeginHorizontal();
                values[i] = EditorGUILayout.TextField(rowLabel + " " + (i + 1), values[i]);
                if (GUILayout.Button("削除", GUILayout.Width(60f)))
                {
                    values.RemoveAt(i);
                    GUIUtility.ExitGUI();
                }
                EditorGUILayout.EndHorizontal();
            }
            if (GUILayout.Button(addLabel)) values.Add(string.Empty);
        }
    }
}
